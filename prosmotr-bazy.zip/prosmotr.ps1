﻿# Поиск абонента в базе FoxPro (таблицы .dbf) - ТОЛЬКО ЧТЕНИЕ.
# Таблицы открываются только на чтение, в базу ничего не записывается.
# Запуск: zapusk.vbs (без чёрного окна) или zapusk.bat.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$refs = @([System.Windows.Forms.Form].Assembly.Location, [System.Drawing.Point].Assembly.Location, [System.Xml.XmlDocument].Assembly.Location)

$code = @'
using System.Xml;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

// ==== ОБЩИЙ БЛОК ВЫГРУЗОК (исходник - razrabotka/shared/vygruzka.cs; здесь не править - вставляется скриптом inject.py) ====
// Источник данных для «Поиска» и «Договора»: база по-старому (O:\BASAFOX, индексы FoxPro) или Excel-выгрузки (быт, юр, наряды).
// Настройки - общие для меню и программ: %APPDATA%\Programmy-Energosbyt\istochnik.txt (меню в папки программ не пишет).
// Выгрузка быта один раз переводится в свою быструю копию (таблица DBF + справочник улиц) - это «свои индексы»:
// %LOCALAPPDATA%\Programmy-Energosbyt\vygruzka\. Заменили файл выгрузки - «Обновить индексы» в настройках меню.
// Только чтение выгрузок: сами файлы Excel не меняются.

public delegate void VygProgress(string text);

public static class Istochnik {
    public const string Base = "база", ExcelMode = "excel";

    static string Profile(Environment.SpecialFolder f) {
        string p = "";
        try { p = Environment.GetFolderPath(f); } catch { }
        if (p == null || p.Length == 0) p = Path.GetTempPath();
        return Path.Combine(p, "Programmy-Energosbyt");
    }

    public static string SettingsFile { get { return Path.Combine(Profile(Environment.SpecialFolder.ApplicationData), "istochnik.txt"); } }
    public static string CacheFolder { get { return Path.Combine(Profile(Environment.SpecialFolder.LocalApplicationData), "vygruzka"); } }
    public static string BytTable { get { return Path.Combine(CacheFolder, "byt.dbf"); } }
    public static string BytStreets { get { return Path.Combine(CacheFolder, "byt_ulicy.txt"); } }
    public static string BytInfo { get { return Path.Combine(CacheFolder, "byt_info.txt"); } }

    // настройки: Режим=база|excel, Быт=, Юр=, Наряды=
    public static Dictionary<string, string> Read() {
        Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try {
            if (File.Exists(SettingsFile))
                foreach (string line in File.ReadAllLines(SettingsFile, Encoding.UTF8)) {
                    int eq = line.IndexOf('=');
                    if (eq > 0 && !line.StartsWith("#")) d[line.Substring(0, eq).Trim()] = line.Substring(eq + 1).Trim();
                }
        } catch { }
        return d;
    }

    static string Get(Dictionary<string, string> d, string k) {
        string v;
        return d.TryGetValue(k, out v) && v != null ? v : "";
    }

    public static bool UseExcel { get { return Get(Read(), "Режим") == ExcelMode; } }
    public static string BytPath { get { return Get(Read(), "Быт"); } }
    public static string JurPath { get { return Get(Read(), "Юр"); } }
    public static string NaryadyPath { get { return Get(Read(), "Наряды"); } }

    public static void Save(bool excel, string byt, string jur, string naryady) {
        Directory.CreateDirectory(Path.GetDirectoryName(SettingsFile));
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("# Откуда «Поиск» и «Договор» берут данные. Меняется в меню программ: «Настройки…»");
        sb.AppendLine("Режим=" + (excel ? ExcelMode : Base));
        sb.AppendLine("Быт=" + byt.Trim());
        sb.AppendLine("Юр=" + jur.Trim());
        sb.AppendLine("Наряды=" + naryady.Trim());
        string tmp = SettingsFile + ".tmp";
        File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(true));
        if (File.Exists(SettingsFile)) File.Delete(SettingsFile);
        File.Move(tmp, SettingsFile);
    }

    // какой выгрузки не хватает: null - всё в порядке, иначе - что сказать пользователю
    public static string Missing(string kind, string path) {
        if (path == null || path.Trim().Length == 0)
            return "Не указан путь к выгрузке " + kind + ". Укажите его в меню программ: «Настройки…».";
        if (!File.Exists(path.Trim()))
            return "Нет файла выгрузки " + kind + ": " + path.Trim() + ". Проверьте путь в меню программ: «Настройки…».";
        return null;
    }

    // своя копия выгрузки быта: null - готова и свежая; иначе - что не так
    public static string BytCacheProblem() {
        string path = BytPath;
        string miss = Missing("быта", path);
        if (miss != null) return miss;
        if (!File.Exists(BytTable) || !File.Exists(BytStreets) || !File.Exists(BytInfo))
            return "Индексы выгрузки быта ещё не созданы. Меню программ: «Настройки…» -> «Обновить индексы».";
        Dictionary<string, string> info = ReadInfo(BytInfo);
        if (string.Compare(Get(info, "Файл"), Path.GetFullPath(path.Trim()), StringComparison.OrdinalIgnoreCase) != 0)
            return "Индексы созданы по другому файлу выгрузки быта. Меню программ: «Настройки…» -> «Обновить индексы».";
        if (Get(info, "Версия") != VygruzkaByt.Version)
            return "Индексы выгрузки быта созданы прежней версией программы. Меню программ: «Настройки…» -> «Обновить индексы».";
        try {
            FileInfo fi = new FileInfo(path.Trim());
            if (Get(info, "Размер") != fi.Length.ToString() || Get(info, "Изменён") != fi.LastWriteTimeUtc.Ticks.ToString())
                return "Файл выгрузки быта заменён после создания индексов. Меню программ: «Настройки…» -> «Обновить индексы».";
        } catch (Exception ex) { return "Выгрузка быта недоступна: " + ex.Message; }
        return null;
    }

    public static Dictionary<string, string> ReadInfo(string file) {
        Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try {
            foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
                int eq = line.IndexOf('=');
                if (eq > 0) d[line.Substring(0, eq).Trim()] = line.Substring(eq + 1);
            }
        } catch { }
        return d;
    }

    // «от 14.01.2026 10:02 (152 340 абонентов)» - для надписей в окнах
    public static string BytAbout() {
        Dictionary<string, string> info = ReadInfo(BytInfo);
        string when = Get(info, "ФайлДата"), rows = Get(info, "Строк");
        return "выгрузка быта" + (when.Length > 0 ? " от " + when : "") + (rows.Length > 0 ? " (" + rows + " записей)" : "");
    }
}

// Чтение .xlsx без Excel и сторонних программ: zip (свой разбор + DeflateStream из .NET 2.0) и XML листа потоком
public class XlsxBook : IDisposable {
    class Entry { public string Name; public int Method; public long Offset, Packed, Size; }
    readonly FileStream fs;
    readonly List<Entry> entries = new List<Entry>();
    public string[] Shared = new string[0];

    public XlsxBook(string path) {
        fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16);
        try { ReadDirectory(); }
        catch { fs.Close(); throw; }
    }

    public void Dispose() { fs.Close(); }

    static int U16(byte[] b, int p) { return b[p] | (b[p + 1] << 8); }
    static long U32(byte[] b, int p) { return (uint)(b[p] | (b[p + 1] << 8) | (b[p + 2] << 16) | (b[p + 3] << 24)); }

    void ReadDirectory() {
        long len = fs.Length;
        int tail = (int)Math.Min(len, 66000);
        byte[] t = new byte[tail];
        fs.Seek(len - tail, SeekOrigin.Begin);
        ReadFull(fs, t, tail);
        int eocd = -1;
        for (int i = tail - 22; i >= 0; i--)
            if (t[i] == 0x50 && t[i + 1] == 0x4B && t[i + 2] == 5 && t[i + 3] == 6) { eocd = i; break; }
        if (eocd < 0) throw new InvalidDataException("Это не файл Excel .xlsx (не zip). Сохраните выгрузку в Excel как «Книга Excel (*.xlsx)».");
        int count = U16(t, eocd + 10);
        long dirSize = U32(t, eocd + 12), dirOffset = U32(t, eocd + 16);
        byte[] d = new byte[dirSize];
        fs.Seek(dirOffset, SeekOrigin.Begin);
        ReadFull(fs, d, (int)dirSize);
        int p = 0;
        for (int i = 0; i < count && p + 46 <= d.Length; i++) {
            if (U32(d, p) != 0x02014b50) break;
            Entry e = new Entry();
            e.Method = U16(d, p + 10);
            e.Packed = U32(d, p + 20);
            e.Size = U32(d, p + 24);
            int nl = U16(d, p + 28), xl = U16(d, p + 30), cl = U16(d, p + 32);
            e.Offset = U32(d, p + 42);
            e.Name = Encoding.UTF8.GetString(d, p + 46, nl).Replace('\\', '/');
            entries.Add(e);
            p += 46 + nl + xl + cl;
        }
    }

    static void ReadFull(Stream s, byte[] b, int n) {
        int got = 0;
        while (got < n) {
            int r = s.Read(b, got, n - got);
            if (r <= 0) throw new EndOfStreamException();
            got += r;
        }
    }

    public bool Has(string name) { return Find(name) != null; }

    Entry Find(string name) {
        foreach (Entry e in entries) if (string.Compare(e.Name, name, StringComparison.OrdinalIgnoreCase) == 0) return e;
        return null;
    }

    // содержимое файла внутри книги - потоком (распаковка на лету)
    public Stream Open(string name) {
        Entry e = Find(name);
        if (e == null) throw new FileNotFoundException("В книге нет " + name);
        byte[] h = new byte[30];
        fs.Seek(e.Offset, SeekOrigin.Begin);
        ReadFull(fs, h, 30);
        long start = e.Offset + 30 + U16(h, 26) + U16(h, 28);
        byte[] packed = new byte[e.Packed];
        fs.Seek(start, SeekOrigin.Begin);
        ReadFull(fs, packed, (int)e.Packed);
        Stream raw = new MemoryStream(packed);
        if (e.Method == 0) return raw;
        if (e.Method == 8) return new System.IO.Compression.DeflateStream(raw, System.IO.Compression.CompressionMode.Decompress);
        throw new InvalidDataException("Неизвестное сжатие в книге (" + e.Method + ")");
    }

    static XmlReader Xml(Stream s) {
        XmlReaderSettings st = new XmlReaderSettings();
        st.IgnoreWhitespace = false;
        return XmlReader.Create(s, st);
    }

    // первый лист книги (как его открывает Excel): workbook.xml -> rels -> путь
    public string FirstSheet() {
        string rid = null;
        if (Has("xl/workbook.xml"))
            using (XmlReader r = Xml(Open("xl/workbook.xml")))
                while (r.Read())
                    if (r.NodeType == XmlNodeType.Element && r.LocalName == "sheet") {
                        for (int i = 0; i < r.AttributeCount; i++) {
                            r.MoveToAttribute(i);
                            if (r.LocalName == "id") rid = r.Value;
                        }
                        break;
                    }
        if (rid != null && Has("xl/_rels/workbook.xml.rels"))
            using (XmlReader r = Xml(Open("xl/_rels/workbook.xml.rels")))
                while (r.Read())
                    if (r.NodeType == XmlNodeType.Element && r.LocalName == "Relationship" && r.GetAttribute("Id") == rid) {
                        string target = r.GetAttribute("Target") ?? "";
                        if (target.StartsWith("/")) return target.Substring(1);
                        return "xl/" + target;
                    }
        foreach (Entry e in entries) if (e.Name.StartsWith("xl/worksheets/", StringComparison.OrdinalIgnoreCase) && e.Name.EndsWith(".xml")) return e.Name;
        throw new InvalidDataException("В книге нет листов.");
    }

    public void LoadShared() {
        if (!Has("xl/sharedStrings.xml")) return;
        List<string> list = new List<string>();
        using (XmlReader r = Xml(Open("xl/sharedStrings.xml"))) {
            StringBuilder cur = null;
            int phonetic = 0;
            bool moved = false;     // ReadElementContentAsString уже передвинул на следующий узел
            while (moved || r.Read()) {
                moved = false;
                if (r.NodeType == XmlNodeType.Element) {
                    if (r.LocalName == "si") { cur = new StringBuilder(); if (r.IsEmptyElement) { list.Add(""); cur = null; } }
                    else if (r.LocalName == "rPh") { if (!r.IsEmptyElement) phonetic++; }
                    else if (r.LocalName == "t" && cur != null && phonetic == 0 && !r.IsEmptyElement) { cur.Append(r.ReadElementContentAsString()); moved = true; }
                } else if (r.NodeType == XmlNodeType.EndElement) {
                    if (r.LocalName == "si" && cur != null) { list.Add(cur.ToString()); cur = null; }
                    else if (r.LocalName == "rPh") phonetic--;
                }
            }
        }
        Shared = list.ToArray();
    }

    public delegate void Row(int number, string[] cells, bool[] numeric);

    // строки листа по порядку: ячейки - текстом как записаны (числа - как в файле, даты - числом Excel); пустые строки пропускаются
    public void ReadRows(string sheet, int width, Row onRow) {
        using (XmlReader r = Xml(Open(sheet))) {
            string[] cells = null;
            bool[] num = null;
            int rowNo = 0, col = -1;
            bool any = false;
            while (r.Read()) {
                if (r.NodeType == XmlNodeType.Element && r.LocalName == "row") {
                    string rn = r.GetAttribute("r");
                    int n;
                    rowNo = rn != null && int.TryParse(rn, out n) ? n : rowNo + 1;
                    cells = new string[width];
                    num = new bool[width];
                    col = -1;
                    any = false;
                    if (r.IsEmptyElement) cells = null;
                } else if (r.NodeType == XmlNodeType.Element && r.LocalName == "c" && cells != null) {
                    string refName = r.GetAttribute("r"), type = r.GetAttribute("t") ?? "";
                    col = refName != null ? ColumnOf(refName) : col + 1;
                    if (r.IsEmptyElement) continue;
                    string value = null;
                    int depth = r.Depth;
                    StringBuilder inline = null;
                    bool moved = false;     // ReadElementContentAsString уже передвинул на следующий узел
                    while (moved || r.Read()) {
                        moved = false;
                        if (r.NodeType == XmlNodeType.EndElement && r.Depth == depth) break;    // </c>
                        if (r.NodeType != XmlNodeType.Element || r.IsEmptyElement) continue;
                        if (r.LocalName == "v") { value = r.ReadElementContentAsString(); moved = true; }
                        else if (r.LocalName == "t" && type == "inlineStr") {
                            if (inline == null) inline = new StringBuilder();
                            inline.Append(r.ReadElementContentAsString());
                            moved = true;
                        }
                    }
                    if (inline != null) value = inline.ToString();
                    if (value == null || col < 0 || col >= width) continue;
                    bool isNum = false;
                    if (type == "s") {
                        int i;
                        value = int.TryParse(value, out i) && i >= 0 && i < Shared.Length ? Shared[i] : "";
                    } else if (type == "b") value = value == "1" ? "1" : "0";
                    else if (type == "e") value = "";
                    else if (type == "" || type == "n") isNum = true;
                    value = value.Trim();
                    if (value.Length == 0) continue;
                    cells[col] = value;
                    num[col] = isNum;
                    any = true;
                } else if (r.NodeType == XmlNodeType.EndElement && r.LocalName == "row") {
                    if (cells != null && any) onRow(rowNo, cells, num);
                    cells = null;
                }
            }
        }
    }

    // «AB12» -> 27 (с нуля)
    public static int ColumnOf(string cellRef) {
        int c = 0;
        foreach (char ch in cellRef) {
            char u = char.ToUpperInvariant(ch);
            if (u < 'A' || u > 'Z') break;
            c = c * 26 + (u - 'A' + 1);
        }
        return c - 1;
    }

    // ширина листа по строке заголовка: сколько столбцов (первая непустая строка)
    public string[] Header(string sheet, out int headerRow) {
        string[] found = null;
        int hr = 0;
        try {
            ReadRows(sheet, 400, delegate(int n, string[] cells, bool[] numeric) {
                if (found != null) throw new StopReading();
                int last = -1;
                for (int i = 0; i < cells.Length; i++) if (cells[i] != null) last = i;
                found = new string[last + 1];
                Array.Copy(cells, found, last + 1);
                hr = n;
                throw new StopReading();
            });
        } catch (StopReading) { }
        headerRow = hr;
        return found ?? new string[0];
    }

    public class StopReading : Exception { }
}

// Выгрузка быта -> своя копия: byt.dbf (поля как в таблице абонентов базы) + byt_ulicy.txt (код улицы -> н.п., улица, сельсовет)
public static class VygruzkaByt {
    public const string Version = "1";

    // столбец выгрузки -> поле копии (как в ABONENT.DBF, чтобы «Поиск» и «Договор» понимали их как раньше); D - дата
    static readonly string[] Known = {
        "НОМЕР", "NAB", "ФИО", "FIO", "NNP", "NP", "EXP_4", "EXP_4", "УЛИЦА", "ULICA", "ДОМ", "DOM", "КОР", "KOR", "КВ", "KV",
        "ТЕЛ", "TEL", "КОД_ЛГ", "KOD_LG", "GIL", "GIL", "LGI", "LGI", "СК", "SKID", "ТАРИФ", "KTAR", "КНИГА", "KNIGA",
        "ТИП_СЧ", "TIPCH", "РАЗР", "RAS", "N_СЧЕТЧИКА", "NCH", "KVP", "KVP", "ГОД", "GODPR", "НАЧ_ПОК", "NPOK", "ДАТА_ПР", "DPR:D",
        "ПОК", "POK", "ОПЛ_ПОК", "OPOK", "ДАТА_ЗАМ", "DZA:D", "ПОК_СН_СЧ", "PZS", "N_ЗАМ_СЧ", "NSC", "ТИП_ЗАМ_СЧ", "TSC",
        "IDSS", "IDSS", "N_F", "N_F", "ПР_ДИФ", "PR_DIF", "ПР_ВОДА_ГА", "PR_VODA", "КОМ_КВ", "KOM_KV", "СОБСТВ", "SOBSTV",
        "АСКУЭ", "ASKUE", "МЕСТО_ПУ", "MESTO_PU", "ГОД_ЗАМ_ПУ", "GOD_ZPU", "КВАР_ЗАМ_П", "KV_ZPU", "М_ТЕЛ", "M_TEL",
        "СОГЛ_СМС", "SOGL_SMS", "СЕЛЬСОВЕТ", "SELSOVET", "U", "U", "ЭЛ_ПУ", "EL_PU", "МП_ИНТ", "MP_INT", "ДАТА_НЗ", "DATA_NZ:D",
        "РАБОТА", "RABOTA", "ДАТА_ИЗВ", "DATA_IZV:D", "ВИД_ИЗВ", "VID_IZV", "ДАТА_ДОГ", "DATA_DOG:D", "Д_ПЕРЕОФ", "D_PEREOF:D",
        "КАТ_ГР", "KAT_GR", "ПР_ПЛ", "PR_PL" };

    public class Column {
        public int Source;           // номер столбца в выгрузке
        public string Header;        // как подписан в выгрузке
        public string Field;         // поле копии
        public bool Date;
        public int Length = 1;
    }

    static string Norm(string h) { return (h ?? "").Trim().ToUpperInvariant().Replace('Ё', 'Е').Replace(' ', '_'); }

    static string Translit(string h) {
        string ru = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
        string[] la = { "A", "B", "V", "G", "D", "E", "ZH", "Z", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "F", "H", "C", "CH", "SH", "SC", "", "Y", "", "E", "JU", "JA" };
        StringBuilder sb = new StringBuilder();
        foreach (char c in Norm(h)) {
            int i = ru.IndexOf(c);
            if (i >= 0) sb.Append(la[i]);
            else if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') sb.Append(c);
        }
        string s = sb.ToString();
        if (s.Length == 0 || char.IsDigit(s[0])) s = "F" + s;
        return s.Length > 10 ? s.Substring(0, 10) : s;
    }

    public static List<Column> MapColumns(string[] header) {
        List<Column> cols = new List<Column>();
        Dictionary<string, bool> used = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        // служебные поля копии - чтобы незнакомый столбец их не занял
        used["UL"] = true;
        for (int i = 0; i < header.Length; i++) {
            string h = Norm(header[i]);
            if (h.Length == 0) continue;
            string field = null;
            for (int k = 0; k + 1 < Known.Length; k += 2) if (Known[k] == h) { field = Known[k + 1]; break; }
            bool date = false;
            if (field != null && field.EndsWith(":D")) { date = true; field = field.Substring(0, field.Length - 2); }
            if (field == null) {
                field = Translit(h);
                date = h.StartsWith("ДАТА") || h.StartsWith("Д_");
            }
            string f = field;
            for (int n = 2; used.ContainsKey(f); n++) f = (field.Length > 8 ? field.Substring(0, 8) : field) + n;
            used[f] = true;
            Column c = new Column();
            c.Source = i;
            c.Header = (header[i] ?? "").Trim();
            c.Field = f;
            c.Date = date;
            cols.Add(c);
        }
        return cols;
    }

    // число из файла: «45678123» / «4.5E-2» -> текст без лишнего (целые - без «.0»)
    public static string Number(string v) {
        double d;
        if (!double.TryParse(v, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d)) return v;
        if (Math.Abs(d) < 1e15 && Math.Abs(d - Math.Round(d)) < 1e-9) return ((long)Math.Round(d)).ToString();
        return d.ToString("0.##########", System.Globalization.CultureInfo.InvariantCulture);
    }

    // дата Excel (число дней от 30.12.1899) или текст «14.01.2026» -> «20260114» (как дата в DBF); не дата - пусто
    public static string Date(string v, bool numeric) {
        double d;
        if (numeric && double.TryParse(v, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d) && d > 1 && d < 2958466)
            return new DateTime(1899, 12, 30).AddDays(Math.Floor(d)).ToString("yyyyMMdd");
        DateTime dt;
        string[] formats = { "dd.MM.yyyy", "d.M.yyyy", "yyyy-MM-dd", "dd.MM.yyyy H:mm:ss", "yyyy-MM-ddTHH:mm:ss", "dd.MM.yy" };
        if (DateTime.TryParseExact(v.Trim(), formats, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out dt))
            return dt.ToString("yyyyMMdd");
        return "";
    }

    // значение ячейки для копии
    public static string Value(Column c, string v, bool numeric) {
        if (v == null) return "";
        if (c.Date) return Date(v, numeric);
        if (numeric) v = Number(v);
        if (c.Field == "NAB") {
            string digits = "";
            foreach (char ch in v) if (ch >= '0' && ch <= '9') digits += ch;
            if (digits.Length > 0 && digits.Length < 9) return digits.PadLeft(9, '0');
            return digits.Length > 0 ? digits : v;
        }
        return v.Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
    }

    static string Key(string ss, string np, string ul) {
        return (ss + "|" + np + "|" + ul).ToLowerInvariant().Replace('ё', 'е');
    }

    // Пересоздать копию выгрузки быта. Пишется во временные файлы, готовое заменяет старое (прервалось - старое цело).
    // Возвращает итог для окна.
    public static string Build(string xlsx, VygProgress progress) {
        DateTime t0 = DateTime.Now;
        string folder = Istochnik.CacheFolder;
        Directory.CreateDirectory(folder);
        FileInfo src = new FileInfo(xlsx);
        Encoding enc = Encoding.GetEncoding(1251);
        List<Column> cols;
        int headerRow, rows = 0, skipped = 0;
        int ss = -1, np = -1, ul = -1;
        Dictionary<string, int> streetCodes = new Dictionary<string, int>();
        List<string[]> streets = new List<string[]>();
        using (XlsxBook book = new XlsxBook(xlsx)) {
            if (progress != null) progress("Читаю выгрузку быта: тексты...");
            book.LoadShared();
            string sheet = book.FirstSheet();
            string[] header = book.Header(sheet, out headerRow);
            cols = MapColumns(header);
            Column nab = null;
            foreach (Column c in cols) {
                if (c.Field == "NAB") nab = c;
                if (c.Field == "SELSOVET") ss = c.Source;
                if (c.Field == "NP") np = c.Source;
                if (c.Field == "ULICA") ul = c.Source;
            }
            if (nab == null)
                throw new InvalidDataException("В первой строке выгрузки нет столбца «НОМЕР» (лицевой). Заголовки: " + string.Join(", ", header));
            int width = header.Length;
            // проход 1: длины полей, коды улиц
            int seen = 0;
            book.ReadRows(sheet, width, delegate(int n, string[] cells, bool[] num) {
                if (n <= headerRow) return;
                if (cells[nab.Source] == null) { skipped++; return; }
                foreach (Column c in cols) {
                    string v = Value(c, cells[c.Source], num[c.Source]);
                    int len = enc.GetByteCount(v);
                    if (len > c.Length) c.Length = Math.Min(254, len);
                }
                string k = Key(ss >= 0 ? cells[ss] ?? "" : "", np >= 0 ? cells[np] ?? "" : "", ul >= 0 ? cells[ul] ?? "" : "");
                if (k != "||" && !streetCodes.ContainsKey(k)) {
                    streetCodes[k] = streets.Count + 1;
                    streets.Add(new string[] { (streets.Count + 1).ToString(), np >= 0 ? cells[np] ?? "" : "", ul >= 0 ? cells[ul] ?? "" : "", ss >= 0 ? cells[ss] ?? "" : "" });
                }
                if (++seen % 20000 == 0 && progress != null) progress("Читаю выгрузку быта: " + seen.ToString("#,0") + " записей...");
            });
            foreach (Column c in cols) if (c.Date) c.Length = 8;
            // проход 2: запись копии
            string tmpTable = Istochnik.BytTable + ".tmp";
            int ulLen = Math.Max(1, streets.Count.ToString().Length);
            using (FileStream fs = new FileStream(tmpTable, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 16)) {
                List<string> names = new List<string>();
                List<char> types = new List<char>();
                List<int> lens = new List<int>();
                names.Add("UL"); types.Add('C'); lens.Add(ulLen);
                foreach (Column c in cols) { names.Add(c.Field); types.Add(c.Date ? 'D' : 'C'); lens.Add(c.Length); }
                int recLen = 1;
                foreach (int l in lens) recLen += l;
                WriteHeader(fs, names, types, lens, 0, recLen);
                byte[] rec = new byte[recLen];
                int written = 0;
                book.ReadRows(sheet, width, delegate(int n, string[] cells, bool[] num) {
                    if (n <= headerRow || cells[nab.Source] == null) return;
                    for (int i = 0; i < rec.Length; i++) rec[i] = 0x20;
                    int p = 1;
                    string k = Key(ss >= 0 ? cells[ss] ?? "" : "", np >= 0 ? cells[np] ?? "" : "", ul >= 0 ? cells[ul] ?? "" : "");
                    int code;
                    if (streetCodes.TryGetValue(k, out code)) Put(rec, p, ulLen, enc, code.ToString().PadLeft(ulLen));
                    p += ulLen;
                    foreach (Column c in cols) {
                        Put(rec, p, c.Length, enc, Value(c, cells[c.Source], num[c.Source]));
                        p += c.Length;
                    }
                    fs.Write(rec, 0, rec.Length);
                    written++;
                    if (written % 20000 == 0 && progress != null) progress("Создаю индексы выгрузки быта: " + written.ToString("#,0") + " из " + seen.ToString("#,0") + "...");
                });
                fs.WriteByte(0x1A);
                rows = written;
                fs.Seek(0, SeekOrigin.Begin);
                WriteHeader(fs, names, types, lens, rows, recLen);
            }
            // справочник улиц
            string tmpStreets = Istochnik.BytStreets + ".tmp";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# код\tнаселённый пункт\tулица\tсельсовет");
            foreach (string[] s in streets) sb.AppendLine(string.Join("\t", s));
            File.WriteAllText(tmpStreets, sb.ToString(), new UTF8Encoding(true));
            // сведения о копии (без данных абонентов)
            StringBuilder info = new StringBuilder();
            info.AppendLine("Версия=" + Version);
            info.AppendLine("Файл=" + src.FullName);
            info.AppendLine("Размер=" + src.Length);
            info.AppendLine("Изменён=" + src.LastWriteTimeUtc.Ticks);
            info.AppendLine("ФайлДата=" + src.LastWriteTime.ToString("dd.MM.yyyy HH:mm"));
            info.AppendLine("Создана=" + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            info.AppendLine("Строк=" + rows);
            info.AppendLine("Улиц=" + streets.Count);
            List<string> map = new List<string>();
            foreach (Column c in cols) map.Add(c.Field + ":" + c.Header);
            info.AppendLine("Столбцы=" + string.Join(";", map.ToArray()));
            string tmpInfo = Istochnik.BytInfo + ".tmp";
            File.WriteAllText(tmpInfo, info.ToString(), new UTF8Encoding(true));
            Replace(tmpTable, Istochnik.BytTable);
            Replace(tmpStreets, Istochnik.BytStreets);
            Replace(tmpInfo, Istochnik.BytInfo);
        }
        return "Индексы выгрузки быта созданы: " + rows.ToString("#,0") + " записей, улиц " + streets.Count.ToString("#,0")
            + (skipped > 0 ? ", строк без лицевого пропущено " + skipped.ToString("#,0") : "") + ", "
            + (DateTime.Now - t0).TotalSeconds.ToString("0") + " с.";
    }

    static void Replace(string tmp, string target) {
        if (File.Exists(target)) File.Delete(target);
        File.Move(tmp, target);
    }

    static void Put(byte[] rec, int pos, int len, Encoding enc, string v) {
        byte[] b = enc.GetBytes(v);
        Buffer.BlockCopy(b, 0, rec, pos, Math.Min(len, b.Length));
    }

    // заголовок DBF (FoxPro, кодировка 1251 - метка 0xC9)
    static void WriteHeader(Stream s, List<string> names, List<char> types, List<int> lens, int count, int recLen) {
        int headerLen = 32 + 32 * names.Count + 1;
        byte[] h = new byte[headerLen];
        DateTime now = DateTime.Now;
        h[0] = 0x03;
        h[1] = (byte)(now.Year % 100);
        h[2] = (byte)now.Month;
        h[3] = (byte)now.Day;
        BitConverter.GetBytes(count).CopyTo(h, 4);
        BitConverter.GetBytes((ushort)headerLen).CopyTo(h, 8);
        BitConverter.GetBytes((ushort)recLen).CopyTo(h, 10);
        h[29] = 0xC9;
        int offset = 1;
        for (int i = 0; i < names.Count; i++) {
            int p = 32 + 32 * i;
            byte[] n = Encoding.ASCII.GetBytes(names[i]);
            Buffer.BlockCopy(n, 0, h, p, Math.Min(10, n.Length));
            h[p + 11] = (byte)types[i];
            BitConverter.GetBytes(offset).CopyTo(h, p + 12);
            h[p + 16] = (byte)lens[i];
            offset += lens[i];
        }
        h[headerLen - 1] = 0x0D;
        s.Write(h, 0, h.Length);
    }

    // справочник улиц копии: код -> {н.п., улица, сельсовет}
    public static Dictionary<string, string[]> ReadStreets(string file) {
        Dictionary<string, string[]> d = new Dictionary<string, string[]>();
        foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
            if (line.StartsWith("#")) continue;
            string[] p = line.Split('\t');
            if (p.Length >= 4) d[p[0].Trim()] = new string[] { p[1], p[2], p[3] };
        }
        return d;
    }

    // подписи полей копии: поле -> заголовок выгрузки
    public static Dictionary<string, string> Labels() {
        Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        string cols;
        Istochnik.ReadInfo(Istochnik.BytInfo).TryGetValue("Столбцы", out cols);
        if (cols != null)
            foreach (string pair in cols.Split(';')) {
                int c = pair.IndexOf(':');
                if (c > 0) d[pair.Substring(0, c)] = pair.Substring(c + 1);
            }
        return d;
    }
}
// ==== КОНЕЦ ОБЩЕГО БЛОКА ВЫГРУЗОК ====

// Код написан на C# 2.0, чтобы собираться и в старом PowerShell 2.0 (Windows 7).

public class DbfField {
    public string Name;
    public char Type;
    public int Offset;
    public int Length;
    public int Decimals;   // знаков после запятой у числовых полей
}

// Сообщает, сколько записей уже прочитано (чтобы окно не "зависало" на больших таблицах)
public delegate void LoadProgress(int done, int expected);

// Решает по записи как она есть в файле, оставлять ли её (например, только улицы своих сельсоветов)
public delegate bool RecordFilter(byte[] record, int start);

// Слово поиска, переведённое в байты кодировки таблицы
public class SearchWord {
    public byte[] Bytes;
    public byte[] Trimmed;      // то же число без нулей впереди, или null
    public bool WholeNumber;    // короткое число (дом, квартира) - ищется только целиком
}

// Примечания (memo) читаются из файла .FPT только когда нужны - для карточки и выгрузки
public class MemoReader : IDisposable {
    readonly FileStream fs;
    readonly int blockSize;
    readonly Encoding enc;

    MemoReader(FileStream fs, int blockSize, Encoding enc) {
        this.fs = fs;
        this.blockSize = blockSize;
        this.enc = enc;
    }

    public static MemoReader Open(string dbfPath, Encoding enc) {
        string path = Path.ChangeExtension(dbfPath, ".FPT");
        if (!File.Exists(path)) path = Path.ChangeExtension(dbfPath, ".fpt");
        if (!File.Exists(path)) return null;
        FileStream fs = null;
        try {
            fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            byte[] h = new byte[8];
            if (DbfTable.ReadUpTo(fs, h, 8) < 8) { fs.Close(); return null; }
            int size = (h[6] << 8) | h[7];
            return new MemoReader(fs, size > 0 ? size : 64, enc);
        } catch (IOException) {
            if (fs != null) fs.Close();
            return null;
        }
    }

    public string Read(int block) {
        long pos = (long)block * blockSize;
        if (pos + 8 > fs.Length) return "";
        fs.Seek(pos, SeekOrigin.Begin);
        byte[] h = new byte[8];
        if (DbfTable.ReadUpTo(fs, h, 8) < 8) return "";
        int type = (h[0] << 24) | (h[1] << 16) | (h[2] << 8) | h[3];
        long len = (uint)((h[4] << 24) | (h[5] << 16) | (h[6] << 8) | h[7]);
        if (type != 1) return "(объект)";
        len = Math.Min(len, Math.Min(fs.Length - pos - 8, 1 << 20));   // не больше 1 МБ на одно примечание
        if (len <= 0) return "";
        byte[] b = new byte[len];
        int got = DbfTable.ReadUpTo(fs, b, b.Length);
        return enc.GetString(b, 0, got).TrimEnd('\0', ' ', '\r', '\n');
    }

    public void Dispose() {
        fs.Close();
    }
}

// Таблица DBF (FoxPro / dBase). Файл открывается только на чтение.
// Записи хранятся в памяти как есть, байтами, и разбираются на поля только для показа -
// так таблица на 100 000 абонентов читается быстро и занимает в памяти немного.
public class DbfTable {
    public string FilePath;
    public List<DbfField> Fields = new List<DbfField>();
    public Encoding Enc;
    public int Count;     // сколько записей в памяти
    public int Total;     // сколько неудалённых записей в файле
    public int Deleted;
    public int Expected;  // сколько записей написано в заголовке файла
    public long BytesRead;
    public double Seconds;
    public List<int> RecNos = new List<int>();   // номер каждой записи в файле (с 1)
    public bool Truncated;                       // подходящих записей было больше, прочитана часть
    byte[] headerBytes;
    int headerLength;

    const int BlockRecords = 4096;   // записи хранятся кусками, без одного огромного массива
    int recordLength;
    int lowerLength;      // запись в поисковой копии: поля через разделитель, чтобы "18" и "12" не слились в "1812"
    int[] lowerOffsets;
    readonly List<byte[]> data = new List<byte[]>();    // записи как в файле
    readonly List<byte[]> lower = new List<byte[]>();   // они же маленькими буквами, только текст - для поиска
    readonly byte[] lowerMap = new byte[256];

    public static DbfTable Load(string path, bool otherEncoding) {
        return Load(path, otherEncoding, null, null);
    }

    // query - если задан, в памяти остаются только подходящие записи (поиск во всех таблицах)
    public static DbfTable Load(string path, bool otherEncoding, string query, LoadProgress progress) {
        return LoadCore(path, otherEncoding, query, progress, false, null, 0, 0);
    }

    // maxKeep - больше стольких подходящих записей не набирать (перебор с очень общим запросом)
    public static DbfTable Load(string path, string query, RecordFilter keep, LoadProgress progress, int maxKeep) {
        return LoadCore(path, false, query, progress, false, keep, 0, maxKeep);
    }

    // keep - какие записи оставлять; maxRecords > 0 - прочитать только начало файла
    public static DbfTable Load(string path, RecordFilter keep, LoadProgress progress, int maxRecords) {
        return LoadCore(path, false, null, progress, false, keep, maxRecords, 0);
    }

    // Только заголовок: список полей и число записей, без чтения самих записей
    public static DbfTable LoadHeader(string path) {
        return LoadCore(path, false, null, null, true, null, 0, 0);
    }

    static DbfTable LoadCore(string path, bool otherEncoding, string query, LoadProgress progress, bool headerOnly,
                             RecordFilter keep, int maxRecords, int maxKeep) {
        DateTime started = DateTime.Now;
        DbfTable t = new DbfTable();
        t.FilePath = path;
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16)) {
            byte[] head = ReadBytes(fs, 32);
            int count = BitConverter.ToInt32(head, 4);
            int headerLen = BitConverter.ToUInt16(head, 8);
            int recordLen = BitConverter.ToUInt16(head, 10);
            if (headerLen < 33 || recordLen < 1 || count < 0)
                throw new InvalidDataException("Это не таблица DBF.");

            // базы FoxPro для DOS хранят текст в кодировке 866, отмеченные как Windows - в 1251
            bool windows = head[29] == 0xC9;
            if (otherEncoding) windows = !windows;
            t.Enc = Encoding.GetEncoding(windows ? 1251 : 866);
            t.recordLength = recordLen;
            t.BuildLowerMap();

            byte[] desc = ReadBytes(fs, headerLen - 32);
            int offset = 1;
            for (int p = 0; p + 32 <= desc.Length && desc[p] != 0x0D; p += 32) {
                DbfField f = new DbfField();
                int n = 0;
                while (n < 11 && desc[p + n] != 0) n++;
                f.Name = Encoding.ASCII.GetString(desc, p, n).Trim();
                f.Type = char.ToUpperInvariant((char)desc[p + 11]);
                f.Length = desc[p + 16];
                if (f.Type == 'C') f.Length += desc[p + 17] << 8;   // длинные текстовые поля (Clipper)
                else f.Decimals = desc[p + 17];
                f.Offset = offset;
                offset += f.Length;
                if (f.Type != '0') t.Fields.Add(f);                  // '0' - служебное поле VFP
            }
            if (offset > recordLen)
                throw new InvalidDataException("Не удалось разобрать структуру таблицы.");
            t.Expected = count;
            t.headerLength = headerLen;
            t.headerBytes = new byte[headerLen];
            Buffer.BlockCopy(head, 0, t.headerBytes, 0, 32);
            Buffer.BlockCopy(desc, 0, t.headerBytes, 32, desc.Length);
            if (headerOnly) return t;

            t.PrepareLower();
            SearchWord[] filter = query == null ? null : t.PrepareWords(query);

            fs.Seek(headerLen, SeekOrigin.Begin);
            const int chunkRecords = 2048;
            byte[] chunk = new byte[chunkRecords * recordLen];
            byte[] low = new byte[t.lowerLength];
            int index = 0;
            int limit = maxRecords > 0 ? Math.Min(count, maxRecords) : count;
            bool end = false;
            while (index < limit && !end) {
                int want = Math.Min(chunkRecords, limit - index);
                int got = ReadUpTo(fs, chunk, want * recordLen) / recordLen;
                t.BytesRead += (long)got * recordLen;
                for (int r = 0; r < got; r++) {
                    int start = r * recordLen;
                    byte flag = chunk[start];
                    if (flag == 0x1A) { end = true; break; }          // конец файла
                    if (flag == (byte)'*') { t.Deleted++; continue; }  // удалённая запись
                    t.Total++;
                    if (keep != null && !keep(chunk, start)) continue;
                    t.MakeLower(chunk, start, low);
                    if (filter == null || MatchesAll(low, 0, t.lowerLength, filter)) t.Append(chunk, start, low, index + r + 1);
                    if (maxKeep > 0 && t.Count >= maxKeep) { t.Truncated = true; end = true; break; }
                }
                index += got;
                if (got < want) break;   // файл короче, чем написано в его заголовке
                if (progress != null) progress(index, limit);
            }
        }
        t.Seconds = (DateTime.Now - started).TotalSeconds;
        return t;
    }

    void BuildLowerMap() {
        byte[] one = new byte[1];
        for (int b = 0; b < 256; b++) {
            lowerMap[b] = (byte)b;
            one[0] = (byte)b;
            string s = Enc.GetString(one);
            string l = s.ToLowerInvariant();
            if (l == s) continue;
            byte[] lb = Enc.GetBytes(l);
            if (lb.Length == 1 && Enc.GetString(lb) == l) lowerMap[b] = lb[0];
        }
    }

    // поисковая копия: только текстовые поля (двоичные числа и ссылки на примечания - пропуск),
    // после каждого поля - разделитель
    bool[] lowerText;

    void PrepareLower() {
        int fieldCount = Fields.Count;
        lowerText = new bool[fieldCount];
        lowerOffsets = new int[fieldCount];
        int pos = 0;
        for (int j = 0; j < fieldCount; j++) {
            lowerOffsets[j] = pos;
            pos += Fields[j].Length + 1;
            lowerText[j] = "CNFDL".IndexOf(Fields[j].Type) >= 0;
        }
        lowerLength = Math.Max(pos, 1);
    }

    void MakeLower(byte[] src, int start, byte[] low) {
        for (int j = 0; j < Fields.Count; j++) {
            DbfField f = Fields[j];
            int from = start + f.Offset, dst = lowerOffsets[j];
            if (lowerText[j]) for (int k = 0; k < f.Length; k++) low[dst + k] = lowerMap[src[from + k]];
            else for (int k = 0; k < f.Length; k++) low[dst + k] = 1;
            low[dst + f.Length] = 1;
        }
    }

    public int RecordLength { get { return recordLength; } }
    public int HeaderLength { get { return headerLength; } }

    // Пустая таблица той же структуры - в неё складываются записи, прочитанные по номерам
    public static DbfTable CreateLike(DbfTable h) {
        DbfTable t = new DbfTable();
        t.FilePath = h.FilePath;
        t.Fields = h.Fields;
        t.Enc = h.Enc;
        t.recordLength = h.recordLength;
        t.headerLength = h.headerLength;
        t.headerBytes = h.headerBytes;
        t.Expected = h.Expected;
        t.BuildLowerMap();
        t.PrepareLower();
        return t;
    }

    public void AddRecord(byte[] src, int start, int recNo) {
        if (lowerOffsets == null) PrepareLower();
        byte[] low = new byte[lowerLength];
        MakeLower(src, start, low);
        Append(src, start, low, recNo);
        Total++;
    }

    // запись как в файле: буфер и место в нём
    public byte[] RecordBuffer(int row, out int start) {
        start = (row % BlockRecords) * recordLength;
        return data[row / BlockRecords];
    }

    void Append(byte[] src, int start, byte[] low, int recNo) {
        RecNos.Add(recNo);
        int block = Count / BlockRecords;
        int slot = Count % BlockRecords;
        if (block == data.Count) {
            data.Add(new byte[BlockRecords * recordLength]);
            lower.Add(new byte[BlockRecords * lowerLength]);
        }
        Buffer.BlockCopy(src, start, data[block], slot * recordLength, recordLength);
        Buffer.BlockCopy(low, 0, lower[block], slot * lowerLength, lowerLength);
        Count++;
    }

    public object GetValue(int row, int field, MemoReader memo) {
        byte[] buf = data[row / BlockRecords];
        int start = (row % BlockRecords) * recordLength;
        return Parse(buf, start, Fields[field], Enc, memo);
    }

    public object[] GetRow(int row, MemoReader memo) {
        object[] values = new object[Fields.Count];
        for (int j = 0; j < values.Length; j++) values[j] = GetValue(row, j, memo);
        return values;
    }

    public MemoReader OpenMemo() {
        foreach (DbfField f in Fields) if (f.Type == 'M') return MemoReader.Open(FilePath, Enc);
        return null;
    }

    // ---- поиск ----

    public static string[] SplitWords(string query) {
        return query.ToLowerInvariant().Split(new char[] { ' ', ',', ';', '\t' }, StringSplitOptions.RemoveEmptyEntries);
    }

    public SearchWord[] PrepareWords(string query) {
        string[] words = SplitWords(query);
        SearchWord[] result = new SearchWord[words.Length];
        for (int i = 0; i < words.Length; i++) result[i] = PrepareWord(words[i]);
        return result;
    }

    public SearchWord PrepareWord(string word) {
        string w = word.ToLowerInvariant();
        // дата 03.03.2021 хранится в таблице как 20210303
        if (w.Length == 10 && w[2] == '.' && w[5] == '.' && IsDigits(w.Remove(5, 1).Remove(2, 1)))
            w = w.Substring(6, 4) + w.Substring(3, 2) + w.Substring(0, 2);
        SearchWord sw = new SearchWord();
        sw.Bytes = ToLowerBytes(w);
        if (IsDigits(w)) {
            sw.WholeNumber = w.Length <= 4;
            string trimmed = w.TrimStart('0');
            if (trimmed.Length > 0 && trimmed.Length < w.Length) sw.Trimmed = ToLowerBytes(trimmed);
        }
        return sw;
    }

    public int FieldIndex(string name) {
        for (int i = 0; i < Fields.Count; i++)
            if (string.Compare(Fields[i].Name, name, StringComparison.OrdinalIgnoreCase) == 0) return i;
        return -1;
    }

    // слово встречается в поле; field = -1 - где угодно в записи
    public bool FieldContains(int row, int field, SearchWord w) {
        byte[] buf = lower[row / BlockRecords];
        int start = (row % BlockRecords) * lowerLength;
        if (field < 0) return MatchWord(buf, start, start + lowerLength, w);
        int from = start + lowerOffsets[field];
        return MatchWord(buf, from, from + Fields[field].Length, w);
    }

    // поле целиком (без пробелов по краям) равно слову: дом "18" - это 18, а не 118 и не 18а
    public bool FieldEquals(int row, int field, SearchWord w) {
        byte[] buf = lower[row / BlockRecords];
        int from = (row % BlockRecords) * lowerLength + lowerOffsets[field];
        int end = from + Fields[field].Length;
        while (from < end && buf[from] <= 32) from++;
        while (end > from && buf[end - 1] <= 32) end--;
        if (end - from != w.Bytes.Length) return false;
        for (int k = 0; k < w.Bytes.Length; k++) if (buf[from + k] != w.Bytes[k]) return false;
        return true;
    }

    byte[] ToLowerBytes(string s) {
        byte[] b = Enc.GetBytes(s);
        for (int i = 0; i < b.Length; i++) b[i] = lowerMap[b[i]];
        return b;
    }

    // field = -1 - искать во всей записи, иначе только в этом поле
    public bool Matches(int row, SearchWord[] words, int field) {
        if (words.Length == 0) return true;
        byte[] buf = lower[row / BlockRecords];
        int start = (row % BlockRecords) * lowerLength;
        if (field < 0) return MatchesAll(buf, start, lowerLength, words);
        return MatchesAll(buf, start + lowerOffsets[field], Fields[field].Length, words);
    }

    static bool MatchesAll(byte[] buf, int from, int length, SearchWord[] words) {
        foreach (SearchWord w in words) if (!MatchWord(buf, from, from + length, w)) return false;
        return true;
    }

    static bool MatchWord(byte[] buf, int from, int end, SearchWord w) {
        if (w.WholeNumber)
            return ContainsNumber(buf, from, end, w.Bytes) || (w.Trimmed != null && ContainsNumber(buf, from, end, w.Trimmed));
        return IndexOf(buf, from, end, w.Bytes) >= 0 || (w.Trimmed != null && IndexOf(buf, from, end, w.Trimmed) >= 0);
    }

    static int IndexOf(byte[] buf, int from, int end, byte[] pattern) {
        int last = end - pattern.Length;
        byte first = pattern[0];
        for (int i = from; i <= last; i++) {
            if (buf[i] != first) continue;
            int k = 1;
            while (k < pattern.Length && buf[i + k] == pattern[k]) k++;
            if (k == pattern.Length) return i;
        }
        return -1;
    }

    // число целиком: "18" находит "18" и "18а", но не "118", не "180" и не копейки в "61.18"
    static bool ContainsNumber(byte[] buf, int from, int end, byte[] number) {
        int i = IndexOf(buf, from, end, number);
        while (i >= 0) {
            int after = i + number.Length;
            bool before = i == from || !(IsDigit(buf[i - 1]) || (IsPoint(buf[i - 1]) && i - 1 > from && IsDigit(buf[i - 2])));
            bool behind = after >= end || !(IsDigit(buf[after]) || (IsPoint(buf[after]) && after + 1 < end && IsDigit(buf[after + 1])));
            if (before && behind) return true;
            i = IndexOf(buf, i + 1, end, number);
        }
        return false;
    }

    static bool IsPoint(byte b) {
        return b == (byte)'.' || b == (byte)',';
    }

    static bool IsDigit(byte b) {
        return b >= (byte)'0' && b <= (byte)'9';
    }

    static bool IsDigits(string s) {
        if (s.Length == 0) return false;
        foreach (char c in s) if (c < '0' || c > '9') return false;
        return true;
    }

    // ---- разбор полей ----

    static object Parse(byte[] buf, int start, DbfField f, Encoding enc, MemoReader memo) {
        int at = start + f.Offset;
        switch (f.Type) {
            case 'C':
                return enc.GetString(buf, at, f.Length).TrimEnd(' ', '\0');
            case 'N':
            case 'F': {
                string s = Encoding.ASCII.GetString(buf, at, f.Length).Trim(' ', '\0');
                if (s.Length == 0) return null;
                decimal d;
                if (decimal.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) return d;
                return s;
            }
            case 'D': {
                string s = Encoding.ASCII.GetString(buf, at, Math.Min(8, f.Length)).Trim(' ', '\0');
                DateTime d;
                if (s.Length == 8 && DateTime.TryParseExact(s, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) return d;
                return null;
            }
            case 'L': {
                char c = (char)buf[at];
                if ("TtYy".IndexOf(c) >= 0) return "Да";
                if ("FfNn".IndexOf(c) >= 0) return "Нет";
                return null;
            }
            case 'M': {
                int block = MemoBlock(buf, at, f.Length);
                if (block <= 0) return null;
                return memo == null ? "(текст)" : memo.Read(block);
            }
            case 'G':
            case 'P':
                return MemoBlock(buf, at, f.Length) > 0 ? "(объект)" : null;
            case 'I':
                return f.Length == 4 ? (object)(decimal)BitConverter.ToInt32(buf, at) : null;
            case 'B':
                return f.Length == 8 ? (object)BitConverter.ToDouble(buf, at) : null;
            case 'Y':
                return f.Length == 8 ? (object)(BitConverter.ToInt64(buf, at) / 10000m) : null;
            case 'T': {
                if (f.Length != 8) return null;
                int day = BitConverter.ToInt32(buf, at);
                int ms = BitConverter.ToInt32(buf, at + 4);
                if (day <= 1721426) return null;   // 1721426 - юлианский день 01.01.0001
                try { return new DateTime(1, 1, 1).AddDays(day - 1721426).AddMilliseconds(ms); }
                catch (ArgumentOutOfRangeException) { return null; }
            }
            default:
                return enc.GetString(buf, at, f.Length).Trim(' ', '\0');
        }
    }

    static int MemoBlock(byte[] buf, int at, int length) {
        if (length == 4) return BitConverter.ToInt32(buf, at);
        string s = Encoding.ASCII.GetString(buf, at, length).Trim(' ', '\0');
        int b;
        return int.TryParse(s, NumberStyles.None, CultureInfo.InvariantCulture, out b) ? b : 0;
    }

    static byte[] ReadBytes(Stream s, int n) {
        byte[] b = new byte[n];
        if (ReadUpTo(s, b, n) < n) throw new InvalidDataException("Файл повреждён или обрезан.");
        return b;
    }

    internal static int ReadUpTo(Stream s, byte[] b, int n) {
        int got = 0;
        while (got < n) {
            int r = s.Read(b, got, n - got);
            if (r <= 0) break;
            got += r;
        }
        return got;
    }

    // ---- показ и выгрузка ----

    // Значение для показа: в таблице длинный текст обрезается, в карточке - целиком
    public static string Format(object v, bool full) {
        if (v == null) return "";
        if (v is DateTime) {
            DateTime d = (DateTime)v;
            return d.TimeOfDay == TimeSpan.Zero ? d.ToString("dd.MM.yyyy") : d.ToString("dd.MM.yyyy HH:mm:ss");
        }
        string s = v as string;
        if (s == null) return Convert.ToString(v, CultureInfo.CurrentCulture);
        if (full) return s;
        s = s.Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ');
        return s.Length > 200 ? s.Substring(0, 200) + "..." : s;
    }

    public static int CompareValues(object a, object b) {
        if (a == null) return b == null ? 0 : 1;
        if (b == null) return -1;
        if (a is decimal && b is decimal) return ((decimal)a).CompareTo((decimal)b);
        if (a is double && b is double) return ((double)a).CompareTo((double)b);
        if (a is DateTime && b is DateTime) return ((DateTime)a).CompareTo((DateTime)b);
        return string.Compare(Format(a, true), Format(b, true), StringComparison.CurrentCultureIgnoreCase);
    }

    // Выгрузка в формате "Таблица XML 2003": Excel открывает его сам и не теряет нули в начале номеров
    public static void WriteSpreadsheet(DbfTable t, IList<int> rows, int count, string file) {
        using (MemoReader memo = t.OpenMemo())
        using (StreamWriter w = new StreamWriter(file, false, new UTF8Encoding(false))) {
            w.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            w.WriteLine("<?mso-application progid=\"Excel.Sheet\"?>");
            w.WriteLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");
            w.WriteLine("<Styles><Style ss:ID=\"h\"><Font ss:Bold=\"1\"/></Style><Style ss:ID=\"d\"><NumberFormat ss:Format=\"Short Date\"/></Style></Styles>");
            w.WriteLine("<Worksheet ss:Name=\"" + Xml(Path.GetFileNameWithoutExtension(t.FilePath)) + "\"><Table>");
            w.Write("<Row>");
            foreach (DbfField f in t.Fields)
                w.Write("<Cell ss:StyleID=\"h\"><Data ss:Type=\"String\">" + Xml(f.Name) + "</Data></Cell>");
            w.WriteLine("</Row>");
            for (int i = 0; i < count; i++) {
                w.Write("<Row>");
                foreach (object v in t.GetRow(rows[i], memo)) {
                    if (v == null)
                        w.Write("<Cell/>");
                    else if (v is decimal || (v is double && !double.IsNaN((double)v) && !double.IsInfinity((double)v)))
                        w.Write("<Cell><Data ss:Type=\"Number\">" + Convert.ToString(v, CultureInfo.InvariantCulture) + "</Data></Cell>");
                    else if (v is DateTime)
                        w.Write("<Cell ss:StyleID=\"d\"><Data ss:Type=\"DateTime\">" + ((DateTime)v).ToString("yyyy-MM-dd'T'HH:mm:ss.fff", CultureInfo.InvariantCulture) + "</Data></Cell>");
                    else
                        w.Write("<Cell><Data ss:Type=\"String\">" + Xml(Format(v, true)) + "</Data></Cell>");
                }
                w.WriteLine("</Row>");
            }
            w.WriteLine("</Table></Worksheet></Workbook>");
        }
    }

    internal static string Xml(string s) {
        StringBuilder sb = new StringBuilder(s.Length);
        foreach (char c in s) {
            switch (c) {
                case '&': sb.Append("&amp;"); break;
                case '<': sb.Append("&lt;"); break;
                case '>': sb.Append("&gt;"); break;
                case '"': sb.Append("&quot;"); break;
                case '\n': sb.Append("&#10;"); break;
                case '\t': sb.Append(c); break;
                default:
                    if (c >= ' ') sb.Append(c);
                    break;
            }
        }
        return sb.ToString();
    }
}

// ---- выражения FoxPro: по ним построены индексы (ключ и условие FOR) ----

public class FoxValue {
    public char Type;      // C - текст, N - число, D - дата (номер дня), L - да/нет
    public byte[] Text;
    public double Num;
    public bool Log;

    public static FoxValue Chars(byte[] b) { FoxValue v = new FoxValue(); v.Type = 'C'; v.Text = b; return v; }
    public static FoxValue Number(double d) { FoxValue v = new FoxValue(); v.Type = 'N'; v.Num = d; return v; }
    public static FoxValue Date(double d) { FoxValue v = new FoxValue(); v.Type = 'D'; v.Num = d; return v; }
    public static FoxValue Logical(bool b) { FoxValue v = new FoxValue(); v.Type = 'L'; v.Log = b; return v; }
}

// Запись, на которой считается выражение
public class FoxContext {
    public DbfTable Table;
    public byte[] Rec;
    public int Start;
    public bool CyrillicUpper = true;   // UPPER() переводит и русские буквы (как в вашей FoxPro - проверяется по индексу)
}

public class FoxExpr {
    // f - поле, v - готовое значение, c - функция, + - = # < > a (<=) b (>=) e (==) $ & (и) | (или) ! (не) m (минус числа)
    public char Op;
    public string Name;
    public int Field = -1;
    public FoxValue Value;
    public FoxExpr[] Args = new FoxExpr[0];

    static readonly string[] Functions = {
        "UPPER", "LOWER", "STR", "DTOS", "DTOC", "LEFT", "RIGHT", "SUBSTR", "ALLTRIM", "TRIM", "RTRIM", "LTRIM",
        "PADL", "PADR", "VAL", "INT", "EMPTY", "DELETED", "IIF", "SPACE" };

    public static FoxExpr Parse(string text, DbfTable t) {
        Parser p = new Parser(text, t);
        FoxExpr e = p.Or();
        p.Space();
        if (p.pos < text.Length) throw new FormatException("непонятно: " + text.Substring(p.pos));
        return e;
    }

    // поля, из которых считается выражение
    public void CollectFields(List<int> list) {
        if (Op == 'f' && !list.Contains(Field)) list.Add(Field);
        foreach (FoxExpr a in Args) a.CollectFields(list);
    }

    // слагаемые верхнего уровня: STR(UL,5)+DOM+KV -> STR(UL,5), DOM, KV
    public List<FoxExpr> Terms() {
        List<FoxExpr> list = new List<FoxExpr>();
        if (Op == '+') { list.AddRange(Args[0].Terms()); list.AddRange(Args[1].Terms()); }
        else list.Add(this);
        return list;
    }

    // начало значения поля даёт начало ключа: FIO, UPPER(FIO), LEFT(FIO,20) - да; STR(), ALLTRIM() - нет
    public bool PrefixSafe() {
        if (Op == 'f') return true;
        if (Op != 'c') return false;
        if (Name == "UPPER" || Name == "LOWER" || Name == "PADR") return Args.Length > 0 && Args[0].PrefixSafe();
        if (Name == "LEFT") return Args.Length == 2 && Args[0].PrefixSafe();
        if (Name == "SUBSTR") return Args.Length >= 2 && Args[1].Op == 'v' && Args[1].Value.Num == 1 && Args[0].PrefixSafe();
        return false;
    }

    public bool UsesCase() {
        if (Op == 'c' && (Name == "UPPER" || Name == "LOWER")) return true;
        foreach (FoxExpr a in Args) if (a.UsesCase()) return true;
        return false;
    }

    // ---- вычисление ----

    public FoxValue Eval(FoxContext c) {
        switch (Op) {
            case 'f': return FieldValue(c, Field);
            case 'v': return Value;
            case 'c': return Call(c);
            case 'm': return FoxValue.Number(-Num(Args[0].Eval(c)));
            case '!': return FoxValue.Logical(!Bool(Args[0].Eval(c)));
            case '&': return FoxValue.Logical(Bool(Args[0].Eval(c)) && Bool(Args[1].Eval(c)));
            case '|': return FoxValue.Logical(Bool(Args[0].Eval(c)) || Bool(Args[1].Eval(c)));
        }
        FoxValue a = Args[0].Eval(c), b = Args[1].Eval(c);
        switch (Op) {
            case '+':
                if (a.Type == 'C' && b.Type == 'C') return FoxValue.Chars(Concat(a.Text, b.Text));
                if (a.Type == 'D' && b.Type == 'N') return FoxValue.Date(a.Num + b.Num);
                return FoxValue.Number(Num(a) + Num(b));
            case '-':
                if (a.Type == 'C' && b.Type == 'C') {
                    int end = a.Text.Length;
                    while (end > 0 && a.Text[end - 1] == ' ') end--;
                    byte[] r = new byte[a.Text.Length + b.Text.Length];
                    Buffer.BlockCopy(a.Text, 0, r, 0, end);
                    Buffer.BlockCopy(b.Text, 0, r, end, b.Text.Length);
                    for (int i = end + b.Text.Length; i < r.Length; i++) r[i] = (byte)' ';
                    return FoxValue.Chars(r);
                }
                if (a.Type == 'D' && b.Type == 'D') return FoxValue.Number(a.Num - b.Num);
                if (a.Type == 'D') return FoxValue.Date(a.Num - Num(b));
                return FoxValue.Number(Num(a) - Num(b));
            case '$':
                return FoxValue.Logical(Find(Str(b), Str(a)) >= 0);
        }
        int cmp = Compare(a, b, Op == '=' || Op == '#');
        switch (Op) {
            case '=': case 'e': return FoxValue.Logical(cmp == 0);
            case '#': return FoxValue.Logical(cmp != 0);
            case '<': return FoxValue.Logical(cmp < 0);
            case '>': return FoxValue.Logical(cmp > 0);
            case 'a': return FoxValue.Logical(cmp <= 0);
            default: return FoxValue.Logical(cmp >= 0);
        }
    }

    // "=" для текста - как в FoxPro при SET EXACT OFF: сравнение по длине правой части
    static int Compare(FoxValue a, FoxValue b, bool loose) {
        if (a.Type == 'C' && b.Type == 'C') {
            byte[] x = a.Text, y = b.Text;
            int n = loose ? y.Length : Math.Max(x.Length, y.Length);
            for (int i = 0; i < n; i++) {
                // (int) - иначе старый компилятор C# (.NET 4 на Windows 7) не собирает: «byte и int неявно преобразуются друг в друга»
                int p = i < x.Length ? (int)x[i] : 32, q = i < y.Length ? (int)y[i] : 32;
                if (p != q) return p < q ? -1 : 1;
            }
            return 0;
        }
        if (a.Type == 'L' && b.Type == 'L') return a.Log == b.Log ? 0 : a.Log ? 1 : -1;
        return Num(a).CompareTo(Num(b));
    }

    static double Num(FoxValue v) {
        if (v.Type == 'N' || v.Type == 'D') return v.Num;
        throw new NotSupportedException("ожидалось число");
    }

    static bool Bool(FoxValue v) {
        if (v.Type == 'L') return v.Log;
        throw new NotSupportedException("ожидалось да/нет");
    }

    static byte[] Str(FoxValue v) {
        if (v.Type == 'C') return v.Text;
        throw new NotSupportedException("ожидался текст");
    }

    static int Int(FoxValue v) {
        return (int)Num(v);
    }

    static byte[] Concat(byte[] a, byte[] b) {
        byte[] r = new byte[a.Length + b.Length];
        Buffer.BlockCopy(a, 0, r, 0, a.Length);
        Buffer.BlockCopy(b, 0, r, a.Length, b.Length);
        return r;
    }

    static byte[] Sub(byte[] s, int from, int len) {
        if (from < 0) from = 0;
        if (from > s.Length) from = s.Length;
        if (len > s.Length - from) len = s.Length - from;
        if (len < 0) len = 0;
        byte[] r = new byte[len];
        Buffer.BlockCopy(s, from, r, 0, len);
        return r;
    }

    static int Find(byte[] where, byte[] what) {
        for (int i = 0; i + what.Length <= where.Length; i++) {
            int k = 0;
            while (k < what.Length && where[i + k] == what[k]) k++;
            if (k == what.Length) return i;
        }
        return -1;
    }

    static FoxValue FieldValue(FoxContext c, int field) {
        DbfField f = c.Table.Fields[field];
        int at = c.Start + f.Offset;
        switch (f.Type) {
            case 'C': return FoxValue.Chars(Sub(c.Rec, at, f.Length));
            case 'N':
            case 'F': {
                string s = Encoding.ASCII.GetString(c.Rec, at, f.Length).Trim(' ', '\0');
                double d;
                if (s.Length == 0 || !double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) d = 0;
                return FoxValue.Number(d);
            }
            case 'D': {
                string s = Encoding.ASCII.GetString(c.Rec, at, Math.Min(8, f.Length)).Trim(' ', '\0');
                DateTime d;
                if (s.Length == 8 && DateTime.TryParseExact(s, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d))
                    return FoxValue.Date(Julian(d));
                return FoxValue.Date(0);
            }
            case 'L': return FoxValue.Logical("TtYy".IndexOf((char)c.Rec[at]) >= 0);
        }
        throw new NotSupportedException("поле " + f.Name + " типа " + f.Type);
    }

    public static double Julian(DateTime d) {
        return (d.Date - new DateTime(1, 1, 1)).Days + 1721426;
    }

    static string Dtos(double julian) {
        if (julian <= 0) return "        ";
        try { return new DateTime(1, 1, 1).AddDays(julian - 1721426).ToString("yyyyMMdd", CultureInfo.InvariantCulture); }
        catch (ArgumentOutOfRangeException) { return "        "; }
    }

    static readonly Dictionary<string, byte[]> caseMaps = new Dictionary<string, byte[]>();

    // таблица замены букв: UPPER/LOWER в кодировке таблицы; cyrillic = false - только латиница
    static byte[] CaseMap(Encoding enc, bool upper, bool cyrillic) {
        string key = enc.CodePage + (upper ? "U" : "L") + (cyrillic ? "R" : "");
        lock (caseMaps) {
            byte[] map;
            if (caseMaps.TryGetValue(key, out map)) return map;
            map = new byte[256];
            byte[] one = new byte[1];
            for (int b = 0; b < 256; b++) {
                map[b] = (byte)b;
                if (b < 128) {
                    if (upper && b >= 'a' && b <= 'z') map[b] = (byte)(b - 32);
                    if (!upper && b >= 'A' && b <= 'Z') map[b] = (byte)(b + 32);
                    continue;
                }
                if (!cyrillic) continue;
                one[0] = (byte)b;
                string s = enc.GetString(one);
                string t = upper ? s.ToUpperInvariant() : s.ToLowerInvariant();
                if (t == s) continue;
                byte[] tb = enc.GetBytes(t);
                if (tb.Length == 1 && enc.GetString(tb) == t) map[b] = tb[0];
            }
            caseMaps[key] = map;
            return map;
        }
    }

    FoxValue Call(FoxContext c) {
        FoxValue[] a = new FoxValue[Args.Length];
        if (Name != "IIF") for (int i = 0; i < a.Length; i++) a[i] = Args[i].Eval(c);
        switch (Name) {
            case "UPPER":
            case "LOWER": {
                byte[] s = Str(a[0]), map = CaseMap(c.Table.Enc, Name == "UPPER", c.CyrillicUpper);
                byte[] r = new byte[s.Length];
                for (int i = 0; i < s.Length; i++) r[i] = map[s[i]];
                return FoxValue.Chars(r);
            }
            case "STR": {
                double v = Num(a[0]);
                int len = a.Length > 1 ? Int(a[1]) : 10, dec = a.Length > 2 ? Int(a[2]) : 0;
                if (len <= 0) len = 10;
                string s = null;
                for (int d = Math.Max(dec, 0); d >= 0; d--) {
                    s = Math.Round(v, d, MidpointRounding.AwayFromZero).ToString("F" + d, CultureInfo.InvariantCulture);
                    if (s == "-0" || (s.StartsWith("-0.") && s.Trim('-', '0', '.').Length == 0)) s = s.Substring(1);
                    if (s.Length <= len) break;
                }
                if (s.Length > len) s = new string('*', len);
                return FoxValue.Chars(Encoding.ASCII.GetBytes(s.PadLeft(len)));
            }
            case "DTOS": return FoxValue.Chars(Encoding.ASCII.GetBytes(Dtos(Num(a[0]))));
            case "DTOC":
                if (a.Length > 1 && Int(a[1]) == 1) return FoxValue.Chars(Encoding.ASCII.GetBytes(Dtos(Num(a[0]))));
                throw new NotSupportedException("DTOC без ,1 зависит от настроек даты");
            case "LEFT": return FoxValue.Chars(Sub(Str(a[0]), 0, Int(a[1])));
            case "RIGHT": {
                byte[] s = Str(a[0]);
                int n = Math.Min(Math.Max(Int(a[1]), 0), s.Length);
                return FoxValue.Chars(Sub(s, s.Length - n, n));
            }
            case "SUBSTR": {
                byte[] s = Str(a[0]);
                int from = Int(a[1]) - 1;
                return FoxValue.Chars(Sub(s, from, a.Length > 2 ? Int(a[2]) : s.Length));
            }
            case "ALLTRIM":
            case "TRIM":
            case "RTRIM":
            case "LTRIM": {
                byte[] s = Str(a[0]);
                int from = 0, end = s.Length;
                if (Name != "LTRIM") while (end > 0 && (s[end - 1] == ' ' || s[end - 1] == 0)) end--;
                if (Name == "ALLTRIM" || Name == "LTRIM") while (from < end && s[from] == ' ') from++;
                return FoxValue.Chars(Sub(s, from, end - from));
            }
            case "PADL":
            case "PADR": {
                byte[] s = Str(a[0]);
                int n = Math.Max(Int(a[1]), 0);
                byte fill = a.Length > 2 && Str(a[2]).Length > 0 ? Str(a[2])[0] : (byte)' ';
                if (s.Length >= n) return FoxValue.Chars(Sub(s, 0, n));
                byte[] r = new byte[n];
                for (int i = 0; i < n; i++) r[i] = fill;
                Buffer.BlockCopy(s, 0, r, Name == "PADL" ? n - s.Length : 0, s.Length);
                return FoxValue.Chars(r);
            }
            case "VAL": {
                string s = Encoding.ASCII.GetString(Str(a[0])).Trim();
                int end = 0;
                while (end < s.Length && (char.IsDigit(s[end]) || s[end] == '.' || (end == 0 && (s[end] == '-' || s[end] == '+')))) end++;
                double d;
                return FoxValue.Number(double.TryParse(s.Substring(0, end), NumberStyles.Float, CultureInfo.InvariantCulture, out d) ? d : 0);
            }
            case "INT": return FoxValue.Number(Math.Truncate(Num(a[0])));
            case "SPACE": return FoxValue.Chars(Encoding.ASCII.GetBytes(new string(' ', Math.Max(Int(a[0]), 0))));
            case "EMPTY": {
                FoxValue v = a[0];
                if (v.Type == 'C') { foreach (byte b in v.Text) if (b != ' ' && b != 0) return FoxValue.Logical(false); return FoxValue.Logical(true); }
                if (v.Type == 'L') return FoxValue.Logical(!v.Log);
                return FoxValue.Logical(v.Num == 0);
            }
            case "DELETED": return FoxValue.Logical(c.Rec[c.Start] == (byte)'*');
            case "IIF": return Bool(Args[0].Eval(c)) ? Args[1].Eval(c) : Args[2].Eval(c);
        }
        throw new NotSupportedException("функция " + Name);
    }

    // Ключ индекса из значения: текст дополняется пробелами до длины ключа,
    // число и дата - 8 байт, упорядоченных так, чтобы сравнение байтов давало порядок чисел
    public static byte[] KeyBytes(FoxValue v, int keyLen) {
        byte[] k;
        switch (v.Type) {
            case 'C':
                k = new byte[keyLen];
                for (int i = 0; i < keyLen; i++) k[i] = i < v.Text.Length ? v.Text[i] : (byte)' ';
                return k;
            case 'L':
                return new byte[] { (byte)(v.Log ? 'T' : 'F') };
        }
        if (keyLen == 4) {
            uint u = (uint)((int)v.Num) + 0x80000000u;
            return new byte[] { (byte)(u >> 24), (byte)(u >> 16), (byte)(u >> 8), (byte)u };
        }
        double d = v.Num == 0 ? 0.0 : v.Num;   // без "минус нуля"
        byte[] le = BitConverter.GetBytes(d);
        if (!BitConverter.IsLittleEndian) Array.Reverse(le);
        k = new byte[8];
        for (int i = 0; i < 8; i++) k[i] = le[7 - i];
        if (d >= 0) k[0] ^= 0x80;
        else for (int i = 0; i < 8; i++) k[i] ^= 0xFF;
        return k;
    }

    // ---- разбор ----

    class Parser {
        readonly string s;
        readonly DbfTable t;
        public int pos;

        public Parser(string s, DbfTable t) { this.s = s; this.t = t; }

        public void Space() { while (pos < s.Length && char.IsWhiteSpace(s[pos])) pos++; }

        bool Word(string w) {
            Space();
            if (string.Compare(s, pos, w, 0, w.Length, StringComparison.OrdinalIgnoreCase) != 0) return false;
            int end = pos + w.Length;
            if (char.IsLetter(w[w.Length - 1]) && end < s.Length && (char.IsLetterOrDigit(s[end]) || s[end] == '_')) return false;
            pos = end;
            return true;
        }

        bool Sym(string w) {
            Space();
            if (string.CompareOrdinal(s, pos, w, 0, w.Length) != 0) return false;
            pos += w.Length;
            return true;
        }

        static FoxExpr Node(char op, params FoxExpr[] args) {
            FoxExpr e = new FoxExpr();
            e.Op = op;
            e.Args = args;
            return e;
        }

        public FoxExpr Or() {
            FoxExpr e = And();
            while (Word(".OR.") || Word("OR")) e = Node('|', e, And());
            return e;
        }

        FoxExpr And() {
            FoxExpr e = Not();
            while (Word(".AND.") || Word("AND")) e = Node('&', e, Not());
            return e;
        }

        FoxExpr Not() {
            if (Word(".NOT.") || Word("NOT")) return Node('!', Not());
            Space();
            if (pos < s.Length && s[pos] == '!' && !(pos + 1 < s.Length && s[pos + 1] == '=')) { pos++; return Node('!', Not()); }
            return Cmp();
        }

        FoxExpr Cmp() {
            FoxExpr e = Add();
            string[] ops = { "==", "<>", "!=", "<=", ">=", "=", "#", "<", ">", "$" };
            char[] codes = { 'e', '#', '#', 'a', 'b', '=', '#', '<', '>', '$' };
            for (int i = 0; i < ops.Length; i++) if (Sym(ops[i])) return Node(codes[i], e, Add());
            return e;
        }

        FoxExpr Add() {
            FoxExpr e = Unary();
            while (true) {
                if (Sym("+")) e = Node('+', e, Unary());
                else if (Sym("-") ) e = Node('-', e, Unary());
                else return e;
            }
        }

        FoxExpr Unary() {
            if (Sym("-")) return Node('m', Unary());
            return Primary();
        }

        FoxExpr Primary() {
            Space();
            if (pos >= s.Length) throw new FormatException("выражение оборвалось");
            char ch = s[pos];
            if (ch == '(') {
                pos++;
                FoxExpr e = Or();
                if (!Sym(")")) throw new FormatException("нет закрывающей скобки");
                return e;
            }
            if (ch == '\'' || ch == '"' || ch == '[') {
                char close = ch == '[' ? ']' : ch;
                int end = s.IndexOf(close, pos + 1);
                if (end < 0) throw new FormatException("строка без конца");
                FoxExpr e = new FoxExpr();
                e.Op = 'v';
                e.Value = FoxValue.Chars(t.Enc.GetBytes(s.Substring(pos + 1, end - pos - 1)));
                pos = end + 1;
                return e;
            }
            if (Word(".T.") || Word(".F.")) {
                FoxExpr e = new FoxExpr();
                e.Op = 'v';
                e.Value = FoxValue.Logical(char.ToUpperInvariant(s[pos - 2]) == 'T');
                return e;
            }
            if (char.IsDigit(ch) || (ch == '.' && pos + 1 < s.Length && char.IsDigit(s[pos + 1]))) {
                int start = pos;
                while (pos < s.Length && (char.IsDigit(s[pos]) || s[pos] == '.')) pos++;
                FoxExpr e = new FoxExpr();
                e.Op = 'v';
                e.Value = FoxValue.Number(double.Parse(s.Substring(start, pos - start), CultureInfo.InvariantCulture));
                return e;
            }
            if (!(char.IsLetter(ch) || ch == '_')) throw new FormatException("непонятный знак '" + ch + "'");
            string name = Ident();
            // псевдоним таблицы: ABONENT.NAB или ABONENT->NAB
            Space();
            if (pos + 1 < s.Length && s[pos] == '-' && s[pos + 1] == '>') { pos += 2; Space(); name = Ident(); }
            else if (pos + 1 < s.Length && s[pos] == '.' && char.IsLetter(s[pos + 1]) && t.FieldIndex(name) < 0) {
                int save = pos;
                pos++;
                string inner = Ident();
                if (pos < s.Length && s[pos] == '.') pos = save;   // это .AND. и подобное
                else name = inner;
            }
            Space();
            if (pos < s.Length && s[pos] == '(') {
                pos++;
                FoxExpr e = new FoxExpr();
                e.Op = 'c';
                e.Name = FunctionName(name);
                List<FoxExpr> args = new List<FoxExpr>();
                if (!Sym(")")) {
                    do args.Add(Or()); while (Sym(","));
                    if (!Sym(")")) throw new FormatException("нет закрывающей скобки у " + name);
                }
                e.Args = args.ToArray();
                return e;
            }
            int f = t.FieldIndex(name);
            if (f < 0) throw new FormatException("нет такого поля: " + name);
            FoxExpr fe = new FoxExpr();
            fe.Op = 'f';
            fe.Field = f;
            fe.Name = t.Fields[f].Name;
            return fe;
        }

        string Ident() {
            int start = pos;
            while (pos < s.Length && (char.IsLetterOrDigit(s[pos]) || s[pos] == '_')) pos++;
            if (pos == start) throw new FormatException("ожидалось имя");
            return s.Substring(start, pos - start).ToUpperInvariant();
        }

        // FoxPro понимает имена функций, сокращённые до 4 букв: SUBS, ALLT, UPPE
        static string FunctionName(string name) {
            foreach (string f in Functions) {
                if (f == name) return f;
                if (name.Length >= 4 && f.StartsWith(name)) return f;
            }
            throw new NotSupportedException("функция " + name);
        }
    }
}

// ---- индексы FoxPro: .CDX (несколько тегов в файле) и .IDX (один индекс в файле) ----

public class IndexTag {
    public string FilePath, FileName, Name;
    public string Expr = "", ForText;
    public int KeyLen, Options;
    public bool Compact, Structural, Descending;
    public long Root;
    public FoxExpr Key, ForExpr;
    public char KeyType = '?';
    public List<FoxExpr> Terms = new List<FoxExpr>();
    public List<string> TermFields = new List<string>();   // поле каждого слагаемого ключа (null - не одно поле)
    public string Problem;          // почему индекс не годится (null - годится)
    public int State;               // 0 - ещё не проверен, 1 - проверен и годится, -1 - не годится
    public string Check = "";
    public bool CyrillicUpper = true;
    public int MinKeys = -1;        // обычный .IDX: в узлах первые ключи (1) или последние (0); -1 - ещё не смотрели
    public string Raw = "";         // служебные байты заголовка (порядок сортировки и т.п.) - для отчёта
    public string Collation = "";   // порядок сортировки FoxPro (SET COLLATE): пусто или MACHINE - байты как есть
    public bool Collated;           // ключ - не буквы, а "веса" сортировки (RUSSIAN, GENERAL...)
    public string Learned = "";     // как изучены веса по этому индексу - для отчёта
    public readonly object Lock = new object();

    public string Label { get { return Name == null ? FileName : FileName + ":" + Name; } }
    public string FirstField { get { return TermFields.Count > 0 ? TermFields[0] : null; } }
}

public class IndexNode {
    public bool Leaf;
    public long Right = -1;
    public List<byte[]> Keys = new List<byte[]>();
    public List<long> Values = new List<long>();   // в листе - номер записи, иначе - где лежит следующий узел
}

// Чтение индексного файла кусками по 512 байт (узлами), без загрузки целиком
public class IndexReader : IDisposable {
    readonly FileStream fs;
    readonly Dictionary<long, byte[]> pages = new Dictionary<long, byte[]>();
    public int Reads;

    public IndexReader(string path) {
        fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.RandomAccess);
    }

    public long Length { get { return fs.Length; } }

    public byte[] Read(long offset, int size) {
        if (offset < 0 || offset + size > fs.Length) throw new InvalidDataException("ссылка за концом файла индекса");
        byte[] b = new byte[size];
        fs.Seek(offset, SeekOrigin.Begin);
        if (DbfTable.ReadUpTo(fs, b, size) < size) throw new InvalidDataException("файл индекса обрезан");
        Reads++;
        return b;
    }

    // узел индекса (512 байт); прочитанные узлы запоминаются до конца поиска
    byte[] Page(long offset) {
        byte[] b;
        if (pages.TryGetValue(offset, out b)) return b;
        if (offset <= 0) throw new InvalidDataException("неверная ссылка в индексе");
        b = Read(offset, 512);
        pages[offset] = b;
        return b;
    }

    public void Dispose() { fs.Close(); }

    static int LE16(byte[] b, int at) { return b[at] | (b[at + 1] << 8); }
    static long LE32(byte[] b, int at) { return (uint)(b[at] | (b[at + 1] << 8) | (b[at + 2] << 16) | (b[at + 3] << 24)); }
    static long BE32(byte[] b, int at) { return (uint)((b[at] << 24) | (b[at + 1] << 16) | (b[at + 2] << 8) | b[at + 3]); }

    static string CString(byte[] b, int at, int max, Encoding enc) {
        int end = at;
        while (end < b.Length && end < at + max && b[end] != 0) end++;
        return enc.GetString(b, at, end - at).Trim();
    }

    public IndexNode Node(IndexTag tag, long offset) {
        byte[] p = Page(offset);
        IndexNode node = new IndexNode();
        int attr = LE16(p, 0), n = LE16(p, 2);
        node.Leaf = (attr & 2) != 0;
        long right = LE32(p, 8);
        node.Right = right == 0xFFFFFFFFL || right == 0 ? -1 : right;
        int keyLen = tag.KeyLen;
        if (tag.Compact && node.Leaf) {
            // хвост ключа: у текста - пробелы, у чисел и у "весов" сортировки (RUSSIAN, GENERAL) - нулевые байты
            DecodeLeaf(p, n, keyLen, tag.KeyType == 'C' && !tag.Collated ? (byte)' ' : (byte)0, node);
            return node;
        }
        int size = keyLen + (tag.Compact ? 8 : 4);
        if (12 + n * size > 512) throw new InvalidDataException("узел индекса повреждён");
        for (int i = 0; i < n; i++) {
            int at = 12 + i * size;
            byte[] k = new byte[keyLen];
            Buffer.BlockCopy(p, at, k, 0, keyLen);
            node.Keys.Add(k);
            // компактный: номер записи и ссылка на узел; обычный .IDX: одно число (в листе - запись, иначе - узел)
            node.Values.Add(tag.Compact ? BE32(p, at + keyLen + 4) : BE32(p, at + keyLen));
        }
        return node;
    }

    // Лист компактного индекса: в начале - номера записей и счётчики сжатия, сами ключи - с конца узла.
    // Ключ = первые dup байт предыдущего ключа + свои байты + trail байт-заполнителей.
    static void DecodeLeaf(byte[] p, int n, int keyLen, byte trail, IndexNode node) {
        long recMask = LE32(p, 14);
        int dupMask = p[18], trlMask = p[19], recBits = p[20], dupBits = p[21], req = p[23];
        if (req < 1 || req > 8 || 24 + n * req > 512) throw new InvalidDataException("лист индекса повреждён");
        int pos = 512;
        byte[] prev = new byte[keyLen];
        for (int i = 0; i < n; i++) {
            ulong v = 0;
            for (int b = 0; b < req; b++) v |= (ulong)p[24 + i * req + b] << (8 * b);
            long rec = (long)(v & (ulong)recMask);
            int dup = (int)((v >> recBits) & (ulong)dupMask);
            int trl = (int)((v >> (recBits + dupBits)) & (ulong)trlMask);
            if (i == 0) dup = 0;
            int len = keyLen - dup - trl;
            if (len < 0 || dup > keyLen || pos - len < 24 + n * req) throw new InvalidDataException("лист индекса повреждён");
            byte[] k = new byte[keyLen];
            Buffer.BlockCopy(prev, 0, k, 0, dup);
            pos -= len;
            Buffer.BlockCopy(p, pos, k, dup, len);
            for (int j = keyLen - trl; j < keyLen; j++) k[j] = trail;
            node.Keys.Add(k);
            node.Values.Add(rec);
            prev = k;
        }
    }

    // ключ из индекса сравнивается с искомым только по длине искомого (так ищется и начало)
    public static int Compare(byte[] entry, byte[] key) {
        int n = Math.Min(entry.Length, key.Length);
        for (int i = 0; i < n; i++) if (entry[i] != key[i]) return entry[i] < key[i] ? -1 : 1;
        return key.Length > entry.Length ? -1 : 0;
    }

    // Все записи, у которых ключ начинается с key (или равен ему, если key полной длины)
    public List<int> Seek(IndexTag tag, byte[] key, int limit, out bool more) {
        more = false;
        List<int> found = new List<int>();
        if (!tag.Compact && tag.MinKeys < 0) DetectMinKeys(tag);
        IndexNode node = Node(tag, tag.Root);
        for (int depth = 0; !node.Leaf; depth++) {
            if (depth > 40 || node.Keys.Count == 0) return found;
            int pick;
            if (tag.MinKeys == 1) {
                // в узле первые ключи потомков: берём последнего потомка, чей первый ключ меньше искомого
                pick = 0;
                for (int i = 1; i < node.Keys.Count; i++) if (Compare(node.Keys[i], key) < 0) pick = i; else break;
            } else {
                // в узле последние ключи потомков: первый потомок, чей последний ключ не меньше искомого
                pick = node.Keys.Count - 1;
                for (int i = 0; i < node.Keys.Count; i++) if (Compare(node.Keys[i], key) >= 0) { pick = i; break; }
            }
            node = Node(tag, node.Values[pick]);
        }
        for (int guard = 0; guard < 1000000; guard++) {
            for (int i = 0; i < node.Keys.Count; i++) {
                int c = Compare(node.Keys[i], key);
                if (c < 0) continue;
                if (c > 0) return found;
                if (found.Count >= limit) { more = true; return found; }
                found.Add((int)node.Values[i]);
            }
            if (node.Right < 0) return found;
            node = Node(tag, node.Right);
        }
        return found;
    }

    // Самый левый лист - для обхода индекса по порядку
    public IndexNode First(IndexTag tag) {
        if (!tag.Compact && tag.MinKeys < 0) DetectMinKeys(tag);
        IndexNode node = Node(tag, tag.Root);
        for (int depth = 0; !node.Leaf && node.Values.Count > 0 && depth < 40; depth++) node = Node(tag, node.Values[0]);
        return node;
    }

    void DetectMinKeys(IndexTag tag) {
        tag.MinKeys = 0;
        IndexNode root = Node(tag, tag.Root);
        if (root.Leaf || root.Keys.Count == 0) return;
        IndexNode child = Node(tag, root.Values[0]);
        if (child.Keys.Count == 0) return;
        if (Compare(root.Keys[0], child.Keys[child.Keys.Count - 1]) == 0) return;
        if (Compare(root.Keys[0], child.Keys[0]) == 0) tag.MinKeys = 1;
    }

    // ---- заголовки: список тегов файла ----

    public static List<IndexTag> ReadTags(string path, Encoding enc) {
        return ReadTags(path, enc, string.Compare(Path.GetExtension(path), ".cdx", StringComparison.OrdinalIgnoreCase) == 0);
    }

    // cdx - файл со списком тегов (.CDX); иначе - один индекс (.IDX). Для временных файлов (.TMP) пробуем оба
    public static List<IndexTag> ReadTags(string path, Encoding enc, bool cdx) {
        List<IndexTag> tags = new List<IndexTag>();
        using (IndexReader r = new IndexReader(path)) {
            if (r.Length < 1024) throw new InvalidDataException("файл слишком короткий для индекса");
            byte[] h = r.Read(0, 1024);
            if (cdx) {
                // в начале .CDX - список тегов: такой же индекс, где ключ - имя тега, а "номер записи" - где лежит его заголовок
                IndexTag dir = new IndexTag();
                dir.Compact = true;
                dir.KeyType = 'C';
                dir.KeyLen = LE16(h, 12);
                dir.Root = LE32(h, 0);
                if (dir.KeyLen < 1 || dir.KeyLen > 64) throw new InvalidDataException("не похоже на индекс FoxPro");
                IndexNode node = r.First(dir);
                for (int guard = 0; guard < 1000; guard++) {
                    for (int i = 0; i < node.Keys.Count; i++) {
                        IndexTag t = ReadCompactHeader(r, node.Values[i], enc);
                        t.Name = enc.GetString(node.Keys[i]).Trim(' ', '\0');
                        t.FilePath = path;
                        t.FileName = Path.GetFileName(path);
                        tags.Add(t);
                    }
                    if (node.Right < 0) break;
                    node = r.Node(dir, node.Right);
                }
            } else if ((h[14] & 0x20) != 0) {
                IndexTag t = ReadCompactHeader(r, 0, enc);
                t.FilePath = path;
                t.FileName = Path.GetFileName(path);
                tags.Add(t);
            } else {
                // обычный (некомпактный) .IDX: заголовок 512 байт, выражение - с 16-го байта
                IndexTag t = new IndexTag();
                t.FilePath = path;
                t.FileName = Path.GetFileName(path);
                t.Root = LE32(h, 0);
                t.KeyLen = LE16(h, 12);
                t.Options = h[14];
                t.Expr = CString(h, 16, 220, enc);
                if ((t.Options & 8) != 0) t.ForText = CString(h, 236, 220, enc);
                tags.Add(t);
            }
        }
        return tags;
    }

    static IndexTag ReadCompactHeader(IndexReader r, long at, Encoding enc) {
        byte[] h = r.Read(at, 1024);
        IndexTag t = new IndexTag();
        t.Compact = true;
        StringBuilder raw = new StringBuilder("сигн. " + h[15].ToString("X2") + ", байты 480-511:");
        for (int i = 480; i < 512; i++) raw.Append(" " + h[i].ToString("X2"));
        t.Raw = raw.ToString();
        // имя порядка сортировки (RUSSIAN, GENERAL, MACHINE) - в байтах 494-501
        StringBuilder coll = new StringBuilder();
        for (int i = 494; i < 502 && h[i] >= (byte)'A' && h[i] <= (byte)'Z'; i++) coll.Append((char)h[i]);
        t.Collation = coll.ToString();
        t.Root = LE32(h, 0);
        t.KeyLen = LE16(h, 12);
        t.Options = h[14];
        t.Descending = LE16(h, 502) != 0;
        int forPos = LE16(h, 504), forLen = LE16(h, 506), keyPos = LE16(h, 508), keyLen = LE16(h, 510);
        if (keyPos == 0 && keyLen != 0 && forPos == 0 && forLen != 0) forPos = keyLen;
        if (keyPos < 512) t.Expr = CString(h, 512 + keyPos, keyLen == 0 ? 512 - keyPos : keyLen, enc);
        if ((t.Options & 8) != 0 && forPos < 512 && h[512 + forPos] != 0)
            t.ForText = CString(h, 512 + forPos, forLen == 0 ? 512 - forPos : forLen, enc);
        return t;
    }
}

// Итог одного поиска
public class SearchResult {
    public string Text;
    public SearchMode Mode;
    public DbfTable Table;
    public AbonentQuery Query;
    public List<int> Rows = new List<int>();
    public int Hidden;          // нашлись, но в невыбранных сельсоветах
    public bool NoIndex;        // нет подходящего индекса - можно только перебором
    public bool TooMany;        // нашлось слишком много - показана часть
    public bool Scanned;        // искали перебором всей базы
    public string Error;
    public bool Partial;        // частичное совпадение (иначе - только точное)
    public AddressMatch Address; // как понят адрес (точный поиск адреса)
    public string NameText, AddressText;   // поиск по ФИО с адресом ("Иванов Боровляны"): что ФИО, что адрес
    public string Note = "";    // пояснение для строки состояния
    public string How = "";     // как искали - для отчёта
    public double Seconds;
    public Dictionary<int, int> Tariff = new Dictionary<int, int>();      // строка -> номер тарифа (T1, T2...)
    public Dictionary<int, string> Power = new Dictionary<int, string>(); // строка -> мощность (доп. сведения)
    public Dictionary<int, bool> Added = new Dictionary<int, bool>();     // строки, которые не искали: другие тарифы того же счётчика
    public Dictionary<int, string> Group = new Dictionary<int, string>(); // строка -> её группа (рамка): тарифы одного счётчика, абоненты одного адреса
    public Dictionary<int, string> Related = new Dictionary<int, string>(); // добавленные по адресу или ФИО -> почему
    public Dictionary<int, bool> Orange = new Dictionary<int, bool>();      // на адресе больше одного счётчика - оранжевым

    public string GroupOf(int row) {
        string g;
        return Group.TryGetValue(row, out g) ? g : null;
    }

    public int Searched { get { return Rows.Count - Added.Count; } }

    public string TariffText(int row) {
        int n;
        return Tariff.TryGetValue(row, out n) ? "T" + n : "";
    }

    public string PowerText(int row) {
        string v;
        return Power.TryGetValue(row, out v) ? v : "";
    }
}

public delegate bool CancelCheck();

// ---- сведения из соседних таблиц ----
// Тарифы: у многотарифного счётчика на каждый тариф (T1, T2, T3) свой лицевой; связка лежит в ABDIF_T.DBF:
// основной лицевой (MAINNAB), лицевой тарифа (NAB) и номер тарифа.
// Дополнительные сведения (в программе базы - Ctrl+D): DOP.DBF / DOGOVOR.DBF, оттуда же мощность.
public class ExtraInfo {
    // тарифы
    string tariffPath;
    DateTime tariffTime, tariffChecked;
    long tariffSize;
    readonly Dictionary<string, int> tariffOf = new Dictionary<string, int>();   // лицевой -> номер тарифа
    readonly Dictionary<string, string> mainOf = new Dictionary<string, string>(); // лицевой -> основной лицевой
    readonly Dictionary<string, List<KeyValuePair<int, string>>> groups = new Dictionary<string, List<KeyValuePair<int, string>>>(); // основной -> (тариф, лицевой)
    int mainField = -1, nabField = -1, numField = -1;
    readonly object sync = new object();
    public string TariffNote = "";

    // дополнительные сведения
    public readonly List<LiveBase> Tables = new List<LiveBase>();
    public LiveBase PowerBase;
    public int PowerField = -1;
    public string PowerNote = "";

    public static string Nab(string s) {
        string t = s.Trim();
        string r = t.TrimStart('0');
        return r.Length == 0 && t.Length > 0 ? "0" : r;
    }

    public static ExtraInfo Open(string folder) {
        ExtraInfo x = new ExtraInfo();
        string tariff = Find(folder, "ABDIF_T.DBF");
        if (tariff != null) {
            x.tariffPath = tariff;
            try { x.LoadTariffs(true); }
            catch (Exception ex) { x.TariffNote = "таблица тарифов не прочиталась: " + ex.Message; x.tariffPath = null; }
        } else x.TariffNote = "таблицы тарифов ABDIF_T.DBF нет";
        Report.Line("Тарифы (T1, T2, T3): " + x.TariffNote);

        foreach (string name in new string[] { "DOP.DBF", "DOGOVOR.DBF" }) {
            string path = Find(folder, name);
            if (path == null) { Report.Line("Доп. сведения: таблицы " + name + " нет"); continue; }
            try {
                LiveBase b = LiveBase.Open(path);
                if (b.Header.FieldIndex("NAB") < 0) { Report.Line("Доп. сведения: в " + name + " нет поля NAB - не связать с абонентом"); continue; }
                x.Tables.Add(b);
                Report.Line("Доп. сведения " + name + ": записей " + b.Header.Expected + ", индексы: "
                    + (b.Tags.Count == 0 ? "нет" : TagList(b)) + ". Поля:");
                Report.Fields(b.Sample, "    ");
            } catch (Exception ex) {
                Report.Line("Доп. сведения: " + name + " не открылась - " + ex.Message);
            }
        }
        x.FindPower();
        Report.Line("Мощность: " + x.PowerNote);
        return x;
    }

    static string TagList(LiveBase b) {
        List<string> l = new List<string>();
        foreach (IndexTag t in b.Tags) l.Add(t.Name + " (" + t.Expr + ")");
        return string.Join(", ", l.ToArray());
    }

    static string Find(string folder, string name) {
        foreach (string f in Directory.GetFiles(folder))
            if (string.Compare(Path.GetFileName(f), name, StringComparison.OrdinalIgnoreCase) == 0) return f;
        return null;
    }

    // поле мощности: по имени (MOSH..., MOCH..., POW...), число с одним знаком после запятой
    void FindPower() {
        int best = 0;
        foreach (LiveBase b in Tables) {
            for (int i = 0; i < b.Header.Fields.Count; i++) {
                DbfField f = b.Header.Fields[i];
                if (f.Type != 'N' && f.Type != 'F') continue;
                string n = f.Name.ToUpperInvariant();
                int score = 0;
                if (n.Contains("MOSH") || n.Contains("MOSC") || n.Contains("MOCH") || n.Contains("MOSN") || n.Contains("MOWN") || n.Contains("MOW")) score = 10;
                else if (n.StartsWith("MOS") || n.StartsWith("MOЩ") || n.StartsWith("MO")) score = 7;
                else if (n.Contains("POW") || n.Contains("PMAX") || n.Contains("PUST") || n.Contains("PRAZ")) score = 6;
                if (f.Decimals == 1) score += 3;
                else if (f.Decimals > 0) score += 1;
                if (score > best) { best = score; PowerBase = b; PowerField = i; }
            }
        }
        if (PowerBase != null && best >= 6) {
            PowerNote = "поле " + Path.GetFileName(PowerBase.FilePath) + "." + PowerBase.Header.Fields[PowerField].Name;
            return;
        }
        // по имени не нашлось: единственное число с одним знаком после запятой в DOP
        PowerBase = null;
        PowerField = -1;
        foreach (LiveBase b in Tables) {
            int found = -1, count = 0;
            for (int i = 0; i < b.Header.Fields.Count; i++)
                if ((b.Header.Fields[i].Type == 'N' || b.Header.Fields[i].Type == 'F') && b.Header.Fields[i].Decimals == 1) { found = i; count++; }
            if (count == 1) { PowerBase = b; PowerField = found; PowerNote = "поле " + Path.GetFileName(b.FilePath) + "." + b.Header.Fields[found].Name + " (угадано: единственное число вида 0.0)"; return; }
        }
        PowerNote = "поле мощности не найдено - пришлите отчёт (в нём список полей таблиц доп. сведений)";
    }

    // ---- тарифы ----

    void LoadTariffs(bool first) {
        FileInfo fi = new FileInfo(tariffPath);
        DbfTable t = DbfTable.Load(tariffPath, false);
        mainField = t.FieldIndex("MAINNAB");
        nabField = t.FieldIndex("NAB");
        if (first) {
            numField = -1;
            // номер тарифа - числовое поле, где только 1..9
            for (int j = 0; j < t.Fields.Count && numField < 0; j++) {
                if (j == mainField || j == nabField) continue;
                DbfField f = t.Fields[j];
                if (f.Type != 'N' && !(f.Type == 'C' && f.Length <= 2)) continue;
                int filled = 0, ok = 0;
                for (int r = 0; r < t.Count && r < 2000; r++) {
                    string v = DbfTable.Format(t.GetValue(r, j, null), true).Trim();
                    if (v.Length == 0) continue;
                    filled++;
                    int n;
                    if (int.TryParse(v, out n) && n >= 1 && n <= 9) ok++;
                }
                if (filled > 0 && ok == filled) numField = j;
            }
        }
        Dictionary<string, int> tariff = new Dictionary<string, int>();
        Dictionary<string, string> main = new Dictionary<string, string>();
        Dictionary<string, List<KeyValuePair<int, string>>> group = new Dictionary<string, List<KeyValuePair<int, string>>>();
        if (nabField >= 0 && numField >= 0) {
            for (int r = 0; r < t.Count; r++) {
                string raw = DbfTable.Format(t.GetValue(r, nabField, null), true).Trim();
                string nab = Nab(raw);
                int n;
                if (nab.Length == 0 || !int.TryParse(DbfTable.Format(t.GetValue(r, numField, null), true).Trim(), out n)) continue;
                tariff[nab] = n;
                string m = mainField >= 0 ? Nab(DbfTable.Format(t.GetValue(r, mainField, null), true)) : "";
                if (m.Length == 0) continue;
                main[nab] = m;
                List<KeyValuePair<int, string>> list;
                if (!group.TryGetValue(m, out list)) { list = new List<KeyValuePair<int, string>>(); group[m] = list; }
                list.Add(new KeyValuePair<int, string>(n, raw));
            }
        }
        foreach (List<KeyValuePair<int, string>> list in group.Values)
            list.Sort(delegate(KeyValuePair<int, string> a, KeyValuePair<int, string> b) { return a.Key.CompareTo(b.Key); });
        lock (sync) {
            tariffOf.Clear();
            mainOf.Clear();
            groups.Clear();
            foreach (KeyValuePair<string, int> kv in tariff) tariffOf[kv.Key] = kv.Value;
            foreach (KeyValuePair<string, string> kv in main) mainOf[kv.Key] = kv.Value;
            foreach (KeyValuePair<string, List<KeyValuePair<int, string>>> kv in group) groups[kv.Key] = kv.Value;
            tariffTime = fi.LastWriteTime;
            tariffSize = fi.Length;
            tariffChecked = DateTime.Now;
        }
        if (first) {
            TariffNote = Path.GetFileName(tariffPath) + ", записей " + t.Count + ", лицевых с тарифом " + tariff.Count
                + "; поля: основной - " + (mainField < 0 ? "нет" : t.Fields[mainField].Name) + ", лицевой - " + (nabField < 0 ? "нет" : t.Fields[nabField].Name)
                + ", номер тарифа - " + (numField < 0 ? "не найден" : t.Fields[numField].Name);
            Report.Line("Поля таблицы тарифов:");
            Report.Fields(t, "    ");
        }
    }

    // не реже раза в минуту смотрим, не поменялась ли таблица тарифов (данные - свежие)
    void FreshTariffs() {
        if (tariffPath == null) return;
        bool check;
        lock (sync) check = DateTime.Now - tariffChecked > TimeSpan.FromSeconds(60);
        if (!check) return;
        try {
            FileInfo fi = new FileInfo(tariffPath);
            bool changed;
            lock (sync) { changed = fi.LastWriteTime != tariffTime || fi.Length != tariffSize; tariffChecked = DateTime.Now; }
            if (changed) LoadTariffs(false);
        } catch (Exception) { }
    }

    // номер тарифа лицевого (0 - не тарифный) и основной лицевой
    public int Tariff(string nab, out string main) {
        FreshTariffs();
        string k = Nab(nab);
        lock (sync) {
            int n;
            if (!tariffOf.TryGetValue(k, out n)) { main = null; return 0; }
            if (!mainOf.TryGetValue(k, out main)) main = null;
            return n;
        }
    }

    // все лицевые одного многотарифного счётчика по основному лицевому: (номер тарифа, лицевой), по порядку тарифов
    public List<KeyValuePair<int, string>> Group(string main) {
        lock (sync) {
            List<KeyValuePair<int, string>> list;
            return main != null && groups.TryGetValue(Nab(main), out list) ? new List<KeyValuePair<int, string>>(list) : new List<KeyValuePair<int, string>>();
        }
    }

    // ---- мощность и карточка ----

    public Dictionary<string, string> Power(List<string> nabs) {
        Dictionary<string, string> result = new Dictionary<string, string>();
        if (PowerBase == null || nabs.Count == 0) return result;
        DbfTable t;
        Dictionary<string, int> rows = PowerBase.LookupNabs(nabs, out t);
        if (t == null) return result;
        foreach (KeyValuePair<string, int> kv in rows) {
            int start;
            byte[] buf = t.RecordBuffer(kv.Value, out start);
            DbfField f = t.Fields[PowerField];
            result[kv.Key] = Encoding.ASCII.GetString(buf, start + f.Offset, f.Length).Trim();
        }
        return result;
    }

    // для карточки: все поля из таблиц доп. сведений (пары "подпись, значение")
    // запись абонента в каждой таблице доп. сведений (DOP, DOGOVOR)
    public List<ExtraRecord> Records(string nab) {
        List<ExtraRecord> list = new List<ExtraRecord>();
        foreach (LiveBase b in Tables) {
            ExtraRecord e = new ExtraRecord();
            e.Name = Path.GetFileName(b.FilePath);
            list.Add(e);
            DbfTable t;
            Dictionary<string, int> rows;
            try { rows = b.LookupNabs(new List<string>(new string[] { nab }), out t); }
            catch (Exception ex) { e.Problem = "не прочиталось: " + ex.Message; continue; }
            int row;
            if (t == null) { e.Problem = "нет индекса по номеру абонента"; continue; }
            if (!rows.TryGetValue(Nab(nab), out row)) { e.Problem = "записи нет"; continue; }
            e.Table = t;
            using (MemoReader memo = t.OpenMemo()) e.Values = t.GetRow(row, memo);
        }
        return list;
    }

    public List<string> Details(string nab) {
        List<string> pairs = new List<string>();
        foreach (ExtraRecord e in Records(nab)) {
            pairs.Add("--- Доп. сведения (" + e.Name + ")");
            if (e.Problem != null) { pairs.Add(e.Problem); continue; }
            pairs.Add("");
            for (int j = 0; j < e.Values.Length; j++) {
                if (string.Compare(e.Table.Fields[j].Name, "NAB", StringComparison.OrdinalIgnoreCase) == 0) continue;
                pairs.Add(FieldNames.Title(e.Table.Fields[j].Name));
                pairs.Add(DbfTable.Format(e.Values[j], true));
            }
        }
        return pairs;
    }
}

// Запись абонента в таблице доп. сведений
public class ExtraRecord {
    public string Name;        // таблица (DOP.DBF)
    public DbfTable Table;
    public object[] Values;
    public string Problem;     // не прочиталось, записи нет...
}

// Свой индекс по ФИО: файл indeks_fio.dat в папке программы (индекса по ФИО у таблицы абонентов нет).
// В нём только ФИО (маленькими буквами) и номер записи - не копия базы. Строится один раз: таблица читается
// в фоне, программа в это время работает; прервали (закрыли программу) - продолжится с того же места. Дальше:
//  - новые абоненты (FoxPro дописывает их в конец таблицы) дочитываются перед каждым поиском - секунды;
//  - удалённые пропускаются: найденные записи всё равно читаются из базы;
//  - исправленные ФИО подхватываются тихой пересборкой раз в сутки (старый индекс в это время работает).
public class NameIndex {
    const string Magic = "POISK-FIO-1";
    const int BlockShift = 22, BlockSize = 1 << BlockShift;   // ФИО лежат подряд в блоках по 4 МБ
    readonly List<byte[]> blocks = new List<byte[]>();
    readonly List<int> blockLength = new List<int>();
    int[] start = new int[1 << 16];     // где ФИО записи: номер блока и место в нём
    byte[] length = new byte[1 << 16];
    int[] recNo = new int[1 << 16];
    public int Count;                   // сколько ФИО в индексе
    public int Scanned;                 // сколько записей таблицы просмотрено
    public int Total;                   // записей в таблице, когда смотрели последний раз
    public DateTime Built = DateTime.Now;   // когда начата сборка (заново - только кнопкой «обновить»)
    public double Seconds;
    readonly int field, fieldLength, headerLength, recordLength, codePage;
    readonly string table;
    readonly Encoding enc;
    readonly byte[] fold = new byte[256];   // маленькие буквы, ё -> е

    public NameIndex(DbfTable h, string tablePath) {
        int f = h.FieldIndex("FIO");
        field = h.Fields[f].Offset;
        fieldLength = h.Fields[f].Length;
        headerLength = h.HeaderLength;
        recordLength = h.RecordLength;
        enc = h.Enc;
        codePage = enc.CodePage;
        table = Path.GetFileName(tablePath).ToUpperInvariant();
        byte[] one = new byte[1];
        for (int b = 0; b < 256; b++) {
            fold[b] = (byte)b;
            one[0] = (byte)b;
            string s = enc.GetString(one);
            string l = s.ToLowerInvariant().Replace('ё', 'е');
            if (l == s) continue;
            byte[] lb = enc.GetBytes(l);
            if (lb.Length == 1 && enc.GetString(lb) == l) fold[b] = lb[0];
        }
    }

    public static int RecordCount(FileStream fs) {
        byte[] h = new byte[8];
        fs.Seek(0, SeekOrigin.Begin);
        if (DbfTable.ReadUpTo(fs, h, 8) < 8) return 0;
        return BitConverter.ToInt32(h, 4);
    }

    // дочитать таблицу с Scanned до конца; progress может прервать (исключением);
    // file - сохранять туда по ходу (каждые 100 тысяч записей), чтобы прерванная сборка продолжилась
    public void Continue(string dbfPath, LoadProgress progress, string file) {
        DateTime started = DateTime.Now;
        try {
            using (FileStream fs = new FileStream(dbfPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16, FileOptions.SequentialScan)) {
                Total = RecordCount(fs);
                Read(fs, Scanned, Total, progress, file);
            }
        } finally {
            Seconds += (DateTime.Now - started).TotalSeconds;
        }
    }

    // перед поиском: дочитать новые записи; false - таблица стала короче (её пересобрали), индекс устарел
    public bool Update(FileStream fs, out int added) {
        int count = RecordCount(fs);
        added = 0;
        if (count < Scanned) return false;
        Total = count;
        if (count > Scanned) { int was = Count; Read(fs, Scanned, count, null, null); added = Count - was; }
        return true;
    }

    void Read(FileStream fs, int from, int count, LoadProgress progress, string file) {
        const int chunkRecords = 4096;
        byte[] buf = new byte[chunkRecords * recordLength];
        fs.Seek(headerLength + (long)from * recordLength, SeekOrigin.Begin);
        int index = from, saved = from;
        while (index < count) {
            int want = Math.Min(chunkRecords, count - index);
            int got = DbfTable.ReadUpTo(fs, buf, want * recordLength) / recordLength;
            bool end = false;
            for (int r = 0; r < got; r++) {
                int p = r * recordLength;
                if (buf[p] == 0x1A) { got = r; end = true; break; }   // конец файла
                if (buf[p] != (byte)'*') Add(buf, p + field, index + r + 1);
            }
            index += got;
            Scanned = index;
            if (end || got < want) break;
            if (file != null && index - saved >= 100000) { TrySave(file); saved = index; }
            if (progress != null) progress(index, count);
        }
    }

    void Add(byte[] src, int from, int rec) {
        int n = fieldLength;
        while (n > 0 && (src[from + n - 1] == (byte)' ' || src[from + n - 1] == 0)) n--;
        if (n > 255) n = 255;
        if (blocks.Count == 0 || blockLength[blocks.Count - 1] + n > BlockSize) { blocks.Add(new byte[BlockSize]); blockLength.Add(0); }
        int bi = blocks.Count - 1, used = blockLength[bi];
        byte[] block = blocks[bi];
        for (int k = 0; k < n; k++) block[used + k] = fold[src[from + k]];
        if (Count == start.Length) {
            int size = Math.Max(16, Count * 2);
            Array.Resize(ref start, size);
            Array.Resize(ref length, size);
            Array.Resize(ref recNo, size);
        }
        start[Count] = (bi << BlockShift) | used;
        length[Count] = (byte)n;
        recNo[Count] = rec;
        Count++;
        blockLength[bi] = used + n;
    }

    // номера записей, где ФИО подходит: точно (с фамилии, словами целиком) или частично (все слова - части ФИО)
    public List<int> Find(List<string> words, bool partial) {
        List<int> found = new List<int>();
        if (words.Count == 0) return found;
        byte[] first = enc.GetBytes(words[0]);
        for (int k = 0; k < first.Length; k++) first[k] = fold[first[k]];
        for (int i = 0; i < Count; i++) {
            byte[] block = blocks[start[i] >> BlockShift];
            int s = start[i] & (BlockSize - 1), n = length[i];
            if (!Contains(block, s, n, first)) continue;
            string fio = enc.GetString(block, s, n);
            if (partial ? AbonentQuery.ContainsAll(fio, words) : AbonentQuery.NameMatches(fio, words)) found.Add(recNo[i]);
        }
        return found;
    }

    static bool Contains(byte[] data, int from, int n, byte[] what) {
        int last = from + n - what.Length;
        for (int p = from; p <= last; p++) {
            if (data[p] != what[0]) continue;
            int k = 1;
            while (k < what.Length && data[p + k] == what[k]) k++;
            if (k == what.Length) return true;
        }
        return false;
    }

    public string Describe() {
        return Count + " ФИО, просмотрено записей " + Scanned + " из " + Total + ", сборка начата " + Built.ToString("dd.MM.yyyy HH:mm");
    }

    void TrySave(string file) {
        try { Save(file); } catch (Exception) { }
    }

    // в файл: сначала во временный, потом заменить - прерванная запись не портит прежний индекс
    public void Save(string file) {
        string tmp = file + ".tmp";
        using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None, 1 << 16))
        using (BinaryWriter w = new BinaryWriter(fs, Encoding.UTF8)) {
            w.Write(Magic);
            w.Write(table);
            w.Write(headerLength);
            w.Write(recordLength);
            w.Write(field);
            w.Write(fieldLength);
            w.Write(codePage);
            w.Write(Scanned);
            w.Write(Total);
            w.Write(Built.Ticks);
            w.Write(Count);
            w.Write(blocks.Count);
            for (int i = 0; i < blocks.Count; i++) { w.Write(blockLength[i]); w.Write(blocks[i], 0, blockLength[i]); }
            WriteInts(w, start, Count);
            w.Write(length, 0, Count);
            WriteInts(w, recNo, Count);
        }
        if (File.Exists(file)) File.Delete(file);
        File.Move(tmp, file);
    }

    // из файла; null - файл от другой таблицы или другой структуры (тогда строим заново)
    public static NameIndex Load(string file, DbfTable h, string tablePath) {
        using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16))
        using (BinaryReader r = new BinaryReader(fs, Encoding.UTF8)) {
            if (r.ReadString() != Magic) return null;
            NameIndex n = new NameIndex(h, tablePath);
            if (r.ReadString() != n.table || r.ReadInt32() != n.headerLength || r.ReadInt32() != n.recordLength
                || r.ReadInt32() != n.field || r.ReadInt32() != n.fieldLength || r.ReadInt32() != n.codePage) return null;
            n.Scanned = r.ReadInt32();
            n.Total = r.ReadInt32();
            n.Built = new DateTime(r.ReadInt64());
            int count = r.ReadInt32();
            int nb = r.ReadInt32();
            for (int i = 0; i < nb; i++) {
                int len = r.ReadInt32();
                byte[] b = new byte[BlockSize];
                if (r.Read(b, 0, len) != len) return null;
                n.blocks.Add(b);
                n.blockLength.Add(len);
            }
            n.start = ReadInts(r, count);
            n.length = r.ReadBytes(count);
            n.recNo = ReadInts(r, count);
            if (n.start == null || n.recNo == null || n.length.Length != count) return null;
            n.Count = count;
            return n;
        }
    }

    static void WriteInts(BinaryWriter w, int[] a, int n) {
        byte[] b = new byte[n * 4];
        Buffer.BlockCopy(a, 0, b, 0, n * 4);
        w.Write(b);
    }

    static int[] ReadInts(BinaryReader r, int n) {
        byte[] b = r.ReadBytes(n * 4);
        if (b.Length != n * 4) return null;
        int[] a = new int[Math.Max(16, n)];
        Buffer.BlockCopy(b, 0, a, 0, n * 4);
        return a;
    }
}

// База абонентов "вживую": при запуске читаются только заголовок, начало таблицы и список индексов.
// Каждый поиск идёт по индексу FoxPro прямо в файлах базы - данные всегда свежие.
public class LiveBase {
    public string FilePath;
    public DbfTable Header;      // поля и кодировка
    public DbfTable Sample;      // первые записи - чтобы понять, как записаны номера и ФИО
    public StreetDirectory Dir;
    public List<IndexTag> Tags = new List<IndexTag>();
    public List<string> IndexFiles = new List<string>();
    public int RecordCount;
    public ExtraInfo Extra;      // тарифы и доп. сведения из соседних таблиц

    public const int FetchLimit = 300;    // больше записей за один поиск не показываем (адрес - до 5000: потом отбор по дому)
    const int SeekLimit = 5000;
    const int NameByAddressLimit = 30000;   // ФИО с адресом: сколько абонентов этого места читаем, чтобы найти среди них ФИО

    static readonly string[] AccountFields = { "NAB", "LS", "LIC", "LSCH", "LS_ERIP" };

    // Режим Excel: своя копия выгрузки быта (byt.dbf) целиком в памяти, поиск - AbonentQuery по всей таблице (индексов нет)
    public DbfTable Mem;
    int memLimit = FetchLimit;      // сколько найденных показывать (больше - «показана часть»)

    public static LiveBase OpenMemory(string path, StreetDirectory dir) {
        LiveBase b = new LiveBase();
        b.FilePath = path;
        b.Mem = DbfTable.Load(path, false);
        b.Mem.FilePath = path;
        b.Header = b.Mem;
        b.Sample = b.Mem;
        b.RecordCount = b.Mem.Count;
        b.Dir = dir;
        return b;
    }

    // поиск в памяти (режим Excel): как перебор, только таблица уже прочитана; ФИО с адресом - «Иванов Боровляны»
    SearchResult SearchMemory(string text, SearchMode mode, Dictionary<string, bool> selsovety, int limit, bool partial) {
        DateTime started = DateTime.Now;
        memLimit = mode == SearchMode.Address ? Math.Max(limit, SeekLimit) : Math.Max(limit, FetchLimit);
        SearchResult res = MemoryOnce(text, mode, selsovety, partial, null, null);
        if (mode == SearchMode.Name && res.Rows.Count == 0 && res.Hidden == 0) {
            string[] w = DbfTable.SplitWords(text);
            for (int k = w.Length - 1; k >= 1; k--) {
                string name = string.Join(" ", w, 0, k), place = string.Join(" ", w, k, w.Length - k);
                SearchResult a = MemoryOnce(text, mode, selsovety, partial, name, place);
                if (a.Rows.Count > 0 || a.Hidden > 0) { res = a; break; }
            }
        }
        res.How = "выгрузка в памяти (" + Mem.Count + " записей)" + (res.How.Length > 0 ? "; " + res.How : "");
        res.Seconds = (DateTime.Now - started).TotalSeconds;
        return res;
    }

    SearchResult MemoryOnce(string text, SearchMode mode, Dictionary<string, bool> selsovety, bool partial, string nameText, string addressText) {
        DateTime started = DateTime.Now;
        SearchResult res = new SearchResult();
        res.Text = text;
        res.Mode = mode;
        res.Partial = partial;
        res.NameText = nameText;
        res.AddressText = addressText;
        if (mode == SearchMode.Address && !partial && Dir != null) {
            res.Address = Dir.Match(text);
            if (res.Address.Problem != null) { res.Note = res.Address.Problem; return Finish(res, null, selsovety, started); }
        }
        return Finish(res, Mem, selsovety, started);
    }

    public static LiveBase Open(string path) {
        LiveBase b = new LiveBase();
        b.FilePath = path;
        b.Header = DbfTable.LoadHeader(path);
        b.RecordCount = b.Header.Expected;
        b.Sample = DbfTable.Load(path, null, null, 500);
        b.FindIndexes();
        return b;
    }

    // Индексы рядом с таблицей: свой .CDX (с тем же именем, FoxPro открывает его сам) и прочие .CDX/.IDX,
    // если их выражения состоят из полей этой таблицы
    void FindIndexes() {
        string folder = Path.GetDirectoryName(FilePath);
        string own = Path.GetFileNameWithoutExtension(FilePath);
        List<string> files = new List<string>();
        Dictionary<string, bool> tables = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        string[] all = Directory.GetFiles(folder);
        foreach (string f in all) if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) == 0) tables[Path.GetFileNameWithoutExtension(f)] = true;
        foreach (string f in all) {
            string ext = Path.GetExtension(f).ToLowerInvariant();
            if (ext != ".cdx" && ext != ".idx") continue;
            IndexFiles.Add(Path.GetFileName(f));
            // .CDX другой таблицы (ARC13.CDX у ARC13.DBF) - её собственный индекс, не наш
            string name = Path.GetFileNameWithoutExtension(f);
            if (ext == ".cdx" && string.Compare(name, own, StringComparison.OrdinalIgnoreCase) != 0 && tables.ContainsKey(name)) continue;
            files.Add(f);
        }
        files.Sort(delegate(string a, string b) {
            bool oa = string.Compare(Path.GetFileNameWithoutExtension(a), own, StringComparison.OrdinalIgnoreCase) == 0;
            bool ob = string.Compare(Path.GetFileNameWithoutExtension(b), own, StringComparison.OrdinalIgnoreCase) == 0;
            if (oa != ob) return oa ? -1 : 1;
            return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
        });
        foreach (string f in files) {
            bool structural = string.Compare(Path.GetFileNameWithoutExtension(f), own, StringComparison.OrdinalIgnoreCase) == 0
                && string.Compare(Path.GetExtension(f), ".cdx", StringComparison.OrdinalIgnoreCase) == 0;
            List<IndexTag> tags;
            try {
                tags = IndexReader.ReadTags(f, Header.Enc);
            } catch (Exception ex) {
                if (structural) Report.Line("    " + Path.GetFileName(f) + ": не прочитался - " + ex.Message);
                continue;
            }
            foreach (IndexTag t in tags) {
                t.Structural = structural;
                Prepare(t);
                // чужой индекс (другой таблицы) - выражение не из наших полей; такие не показываем
                if (!structural && t.Key == null) continue;
                Tags.Add(t);
            }
        }
    }

    void Prepare(IndexTag t) {
        try {
            t.Key = FoxExpr.Parse(t.Expr, Header);
        } catch (Exception ex) {
            t.Problem = "выражение не разобрать (" + ex.Message + ")";
            return;
        }
        if (t.ForText != null && t.ForText.Length > 0) {
            try { t.ForExpr = FoxExpr.Parse(t.ForText, Header); }
            catch (Exception ex) { t.Problem = "условие FOR не разобрать (" + ex.Message + ")"; return; }
        }
        if ((t.Options & 1) != 0) { t.Problem = "UNIQUE - в индексе только первая запись с каждым ключом"; return; }
        try {
            byte[] blank = BlankRecord();
            FoxContext c = Context(blank, t);
            t.KeyType = t.Key.Eval(c).Type;
            if (t.ForExpr != null && t.ForExpr.Eval(c).Type != 'L') { t.Problem = "условие FOR - не да/нет"; return; }
        } catch (Exception ex) {
            t.Problem = "выражение не посчитать (" + ex.Message + ")";
            return;
        }
        t.Collated = t.KeyType == 'C' && t.Collation.Length > 0 && t.Collation != "MACHINE";
        if ((t.KeyType == 'N' || t.KeyType == 'D') && t.KeyLen != 8 && t.KeyLen != 4) { t.Problem = "непонятная длина числового ключа " + t.KeyLen; return; }
        if (t.KeyLen < 1 || t.KeyLen > 240) { t.Problem = "непонятная длина ключа " + t.KeyLen; return; }
        t.Terms = t.KeyType == 'C' ? t.Key.Terms() : new List<FoxExpr>(new FoxExpr[] { t.Key });
        foreach (FoxExpr term in t.Terms) {
            List<int> fields = new List<int>();
            term.CollectFields(fields);
            t.TermFields.Add(fields.Count == 1 ? Header.Fields[fields[0]].Name.ToUpperInvariant() : null);
        }
    }

    public byte[] BlankRecord() {
        byte[] r = new byte[Header.RecordLength];
        for (int i = 0; i < r.Length; i++) r[i] = (byte)' ';
        return r;
    }

    FoxContext Context(byte[] rec, IndexTag t) {
        FoxContext c = new FoxContext();
        c.Table = Header;
        c.Rec = rec;
        c.CyrillicUpper = t == null || t.CyrillicUpper;
        return c;
    }

    // ---- чтение записей по номерам ----

    public FileStream OpenTable() {
        return new FileStream(FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.RandomAccess);
    }

    public int CurrentCount(FileStream fs) {
        byte[] h = new byte[8];
        fs.Seek(0, SeekOrigin.Begin);
        if (DbfTable.ReadUpTo(fs, h, 8) == 8) RecordCount = BitConverter.ToInt32(h, 4);
        return RecordCount;
    }

    public byte[] ReadRecord(FileStream fs, int recNo) {
        long at = Header.HeaderLength + (long)(recNo - 1) * Header.RecordLength;
        if (recNo < 1 || at + Header.RecordLength > fs.Length) return null;
        byte[] r = new byte[Header.RecordLength];
        fs.Seek(at, SeekOrigin.Begin);
        return DbfTable.ReadUpTo(fs, r, r.Length) == r.Length ? r : null;
    }

    // Записи из разных мест таблицы (по одной через равные промежутки)
    public DbfTable SpreadSample(int n) {
        DbfTable part = DbfTable.CreateLike(Header);
        part.FilePath = FilePath;
        using (FileStream fs = OpenTable()) {
            int count = CurrentCount(fs);
            for (int i = 1; i <= n && count > 0; i++) {
                int recNo = (int)Math.Max(1, (long)count * i / (n + 1));
                byte[] rec = ReadRecord(fs, recNo);
                if (rec != null && rec[0] != (byte)'*') part.AddRecord(rec, 0, recNo);
            }
        }
        return part;
    }

    // Записи по номерам; соседние читаются одним куском. Удалённые пропускаются.
    public DbfTable Fetch(FileStream fs, List<int> recNos, int limit, out int deleted) {
        deleted = 0;
        DbfTable part = DbfTable.CreateLike(Header);
        part.FilePath = FilePath;
        List<int> list = new List<int>(recNos);
        list.Sort();
        int len = Header.RecordLength;
        byte[] buf = new byte[65536 + len];
        int i = 0;
        while (i < list.Count && part.Count < limit) {
            int first = list[i], j = i;
            while (j + 1 < list.Count && (long)(list[j + 1] - first + 1) * len <= 65536 && list[j + 1] - list[j] <= 16) j++;
            int last = list[j];
            fs.Seek(Header.HeaderLength + (long)(first - 1) * len, SeekOrigin.Begin);
            int got = DbfTable.ReadUpTo(fs, buf, (last - first + 1) * len);
            for (int k = i; k <= j && part.Count < limit; k++) {
                if (k > i && list[k] == list[k - 1]) continue;
                int pos = (list[k] - first) * len;
                if (pos + len > got) continue;
                if (buf[pos] == (byte)'*') { deleted++; continue; }
                part.AddRecord(buf, pos, list[k]);
            }
            i = j + 1;
        }
        return part;
    }

    // ---- проверка индекса: ключи в нём такие же, как считает программа? ----

    // Берём записи из разных мест таблицы, считаем их ключ и ищем его в индексе - запись должна найтись.
    // Так заодно видно, что индекс от этой таблицы и что он не устарел.
    public bool Verify(IndexTag t) {
        lock (t.Lock) {
            if (t.State != 0) return t.State > 0;
            if (t.Problem != null) { t.State = -1; t.Check = t.Problem; return false; }
            if (t.Collated) {
                Learn(t);
                if (t.Problem != null) { t.State = -1; t.Check = t.Problem + "; " + t.Learned; return false; }
            }
            bool[] variants = t.Key.UsesCase() && !t.Collated ? new bool[] { true, false } : new bool[] { true };
            string last = "";
            foreach (bool cyr in variants) {
                t.CyrillicUpper = cyr;
                string note;
                int result = TryVerify(t, out note);
                last = note;
                if (result > 0) {
                    t.State = 1;
                    t.Check = "годится: " + note + (t.Key.UsesCase() ? (cyr ? " (UPPER - и русские буквы)" : " (UPPER - только латиница)") : "");
                    return true;
                }
                if (result == 0) { t.State = 0; t.Check = "не проверен: " + note; t.CyrillicUpper = true; return false; }
            }
            t.CyrillicUpper = true;
            t.State = -1;
            t.Check = "не годится: " + last;
            return false;
        }
    }

    // 1 - годится, -1 - нет, 0 - не удалось проверить (ошибка чтения)
    int TryVerify(IndexTag t, out string note) {
        int tried = 0, ok = 0;
        string sample = "";
        try {
            using (FileStream fs = OpenTable())
            using (IndexReader r = new IndexReader(t.FilePath)) {
                int count = CurrentCount(fs);
                if (count == 0) { note = "таблица пуста"; return 0; }
                for (int step = 1; step <= 40 && tried < 8; step++) {
                    int recNo = (int)Math.Max(1, Math.Min(count, (long)count * step / 41));
                    byte[] rec = ReadRecord(fs, recNo);
                    if (rec == null || rec[0] == (byte)'*') continue;
                    FoxContext c = Context(rec, t);
                    if (t.ForExpr != null && !t.ForExpr.Eval(c).Log) continue;
                    byte[] key = t.Collated ? CollatedKey(t, t.Key.Eval(c).Text, true) : FoxExpr.KeyBytes(t.Key.Eval(c), t.KeyLen);
                    if (key == null || (t.KeyType == 'C' && IsBlank(key))) continue;   // пустой ключ есть у многих - не показательно
                    bool more;
                    List<int> found = r.Seek(t, key, SeekLimit, out more);
                    if (more && !found.Contains(recNo)) continue;      // слишком много одинаковых - не показательно
                    tried++;
                    if (found.Contains(recNo)) ok++;
                    else if (sample.Length == 0) sample = "; ключ записи: " + (t.Collated ? "длина " + key.Length : Report.Shape(Header.Enc.GetString(key), false))
                        + ", нашлось по нему записей: " + found.Count;
                }
                note = "нашлись " + ok + " из " + tried + " проверочных записей (чтений индекса " + r.Reads + ")" + sample;
            }
        } catch (Exception ex) {
            note = "ошибка при проверке: " + ex.Message;
            return 0;
        }
        if (tried < 2) { note = "мало записей для проверки (" + tried + ")"; return ok == tried && tried > 0 ? 1 : 0; }
        return ok >= tried * 0.75 ? 1 : -1;
    }

    // ---- порядок сортировки RUSSIAN / GENERAL ----
    // При SET COLLATE TO "RUSSIAN" (или GENERAL) FoxPro кладёт в индекс не сами символы, а их "веса":
    // по байту на символ (большие и маленькие буквы - одинаково), затем добавки для букв с особыми знаками,
    // остаток ключа - нулевые байты. Ключ вдвое длиннее поля. Таблица весов RUSSIAN нигде не опубликована,
    // поэтому программа узнаёт её по самому индексу: берёт ключи из нескольких мест индекса, читает их записи
    // и сопоставляет символ за символом.

    // веса GENERAL для латиницы, цифр и знаков (для RUSSIAN они, как правило, те же - проверяется по индексу)
    static readonly int[] GeneralAscii = {
        16,16,16,16,16,16,16,16,16,17,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,86,87,88,89,90,91,92,93,94,95,33,34,35,36,37,38,
        39,96,97,98,100,102,103,104,105,106,107,108,109,111,112,114,115,116,117,118,119,120,122,123,124,125,126,40,41,42,43,44,
        45,96,97,98,100,102,103,104,105,106,107,108,109,111,112,114,115,116,117,118,119,120,122,123,124,125,126,46,47,48,49,16 };

    class Weights {
        public int[] Head = new int[256];
        public bool LikeGeneral = true;   // все изученные латинские буквы, цифры и знаки совпали с GENERAL
        public int Known;
        public Weights() { for (int i = 0; i < 256; i++) Head[i] = -1; }
    }

    readonly Dictionary<string, Weights> weights = new Dictionary<string, Weights>();

    Weights WeightsOf(string collation) {
        lock (weights) {
            Weights w;
            if (!weights.TryGetValue(collation, out w)) { w = new Weights(); weights[collation] = w; }
            return w;
        }
    }

    // вес символа: изученный; для латиницы и цифр - как в GENERAL, если изученное с ним не расходится; иначе -1
    int Head(Weights w, byte c) {
        int h = w.Head[c];
        if (h >= 0) return h;
        return c < 128 && w.LikeGeneral ? GeneralAscii[c] : -1;
    }

    // Начало ключа по значению: веса символов до первого неизвестного (тогда ищется по более короткому началу)
    byte[] CollatedKey(IndexTag t, byte[] raw, bool trimEnd) {
        if (raw == null) return null;
        Weights w = WeightsOf(t.Collation);
        int n = raw.Length;
        if (trimEnd) while (n > 0 && raw[n - 1] == (byte)' ') n--;
        List<byte> key = new List<byte>();
        lock (w) {
            for (int i = 0; i < n && key.Count < t.KeyLen; i++) {
                int h = Head(w, raw[i]);
                if (h < 0) break;
                key.Add((byte)h);
            }
        }
        return key.Count == 0 ? null : key.ToArray();
    }

    IndexNode Descend(IndexReader r, IndexTag t, bool last) {
        IndexNode node = r.Node(t, t.Root);
        for (int depth = 0; !node.Leaf && node.Values.Count > 0 && depth < 40; depth++)
            node = r.Node(t, node.Values[last ? node.Values.Count - 1 : node.Values.Count / 2]);
        return node;
    }

    void Learn(IndexTag t) {
        if (t.Learned.Length > 0) return;
        Weights w = WeightsOf(t.Collation);
        int samples = 0, shorter = 0, conflicts = 0, learned = 0;
        try {
            using (FileStream fs = OpenTable())
            using (IndexReader r = new IndexReader(t.FilePath)) {
                List<IndexNode> leaves = new List<IndexNode>();
                leaves.Add(r.First(t));
                leaves.Add(Descend(r, t, false));
                leaves.Add(Descend(r, t, true));
                foreach (IndexNode leaf in leaves) {
                    for (int i = 0, used = 0; i < leaf.Keys.Count && used < 25; i++) {
                        byte[] rec = ReadRecord(fs, (int)leaf.Values[i]);
                        if (rec == null) continue;
                        FoxValue v = t.Key.Eval(Context(rec, t));
                        if (v.Type != 'C') continue;
                        int n = v.Text.Length;
                        while (n > 0 && v.Text[n - 1] == (byte)' ') n--;
                        if (n == 0) continue;
                        byte[] k = leaf.Keys[i];
                        int m = k.Length;
                        while (m > 0 && k[m - 1] == 0) m--;
                        used++;
                        samples++;
                        if (m < n) { shorter++; continue; }
                        bool conflict = false;
                        lock (w) {
                            for (int j = 0; j < n; j++) {
                                byte c = v.Text[j];
                                if (w.Head[c] < 0) { w.Head[c] = k[j]; learned++; w.Known++; }
                                else if (w.Head[c] != k[j]) conflict = true;
                            }
                        }
                        if (conflict) conflicts++;
                    }
                }
            }
        } catch (Exception ex) {
            t.Learned = "веса не изучены: " + ex.Message;
            t.Problem = "не удалось изучить сортировку " + t.Collation;
            return;
        }
        lock (w) {
            for (int c = 0; c < 128; c++) if (w.Head[c] >= 0 && w.Head[c] != GeneralAscii[c]) w.LikeGeneral = false;
        }
        t.Learned = "сортировка " + t.Collation + ": изучено по " + samples + " ключам, новых символов " + learned
            + (shorter > 0 ? ", ключ короче значения: " + shorter : "") + (conflicts > 0 ? ", противоречий: " + conflicts : "");
        if (samples >= 5 && shorter + conflicts > samples / 5)
            t.Problem = "ключи устроены не так, как ожидалось (сортировка " + t.Collation + ")";
    }

    // для отчёта: какие веса узнаны (цифры, пробел, сколько русских букв)
    public string WeightsReport() {
        StringBuilder sb = new StringBuilder();
        lock (weights) {
            foreach (KeyValuePair<string, Weights> kv in weights) {
                Weights w = kv.Value;
                StringBuilder digits = new StringBuilder();
                for (int c = '0'; c <= '9'; c++) digits.Append((char)c + "=" + (w.Head[c] < 0 ? "?" : w.Head[c].ToString()) + " ");
                int cyr = 0;
                for (int c = 128; c < 256; c++) if (w.Head[c] >= 0) cyr++;
                sb.Append("Сортировка " + kv.Key + ": узнано символов " + w.Known + "; цифры: " + digits + "пробел=" + (w.Head[32] < 0 ? "?" : w.Head[32].ToString())
                    + "; русских и прочих букв: " + cyr + "; латиница и цифры как в GENERAL: " + (w.LikeGeneral ? "да" : "нет") + ". ");
            }
        }
        return sb.ToString();
    }

    static bool IsBlank(byte[] k) {
        foreach (byte b in k) if (b != ' ' && b != 0) return false;
        return true;
    }

    // Подходящий проверенный индекс, ключ которого начинается с поля field
    public IndexTag TagFor(string field) {
        return TagFor(field, false);
    }

    // preferLong - лучше индекс из нескольких полей (улица + дом: сразу находится нужный дом)
    public IndexTag TagFor(string field, bool preferLong) {
        List<IndexTag> list = new List<IndexTag>();
        foreach (IndexTag t in Tags) if (t.Problem == null && string.Compare(t.FirstField, field, StringComparison.OrdinalIgnoreCase) == 0) list.Add(t);
        list.Sort(delegate(IndexTag a, IndexTag b) {
            if (a.Structural != b.Structural) return a.Structural ? -1 : 1;
            if ((a.ForExpr == null) != (b.ForExpr == null)) return a.ForExpr == null ? -1 : 1;
            if (preferLong && a.Terms.Count != b.Terms.Count) return b.Terms.Count.CompareTo(a.Terms.Count);
            return a.Expr.Length.CompareTo(b.Expr.Length);
        });
        foreach (IndexTag t in list) if (Verify(t)) return t;
        return null;
    }

    // проверить все индексы по нужным полям сразу после запуска (итог - в отчёт)
    public void VerifyMain() {
        foreach (string f in new string[] { "NAB", "LS_ERIP", "NCH", "NSC", "FIO" }) TagFor(f);
        TagFor("UL", true);
    }

    // ---- ключи для поиска ----

    void Put(byte[] rec, string fieldName, string value) {
        int i = Header.FieldIndex(fieldName);
        if (i < 0) throw new ArgumentException(fieldName);
        DbfField f = Header.Fields[i];
        byte[] b;
        switch (f.Type) {
            case 'N':
            case 'F': {
                double d;
                if (!double.TryParse(value.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out d)) throw new FormatException("не число");
                string s = d.ToString("F" + f.Decimals, CultureInfo.InvariantCulture);
                if (s.Length > f.Length) throw new FormatException("не помещается");
                b = Encoding.ASCII.GetBytes(s.PadLeft(f.Length));
                break;
            }
            default:
                b = Header.Enc.GetBytes(value);
                break;
        }
        for (int k = 0; k < f.Length; k++) rec[f.Offset + k] = k < b.Length ? b[k] : (byte)' ';
    }

    // Ключ (или его начало) по значениям первых полей ключа. prefixLast - последнее значение может быть началом поля.
    public byte[] KeyFor(IndexTag t, string[] values, bool prefixLast) {
        if (values.Length == 0 || values.Length > t.Terms.Count) return null;
        byte[] rec = BlankRecord();
        try {
            for (int i = 0; i < values.Length; i++) {
                if (t.TermFields[i] == null) return null;
                Put(rec, t.TermFields[i], values[i]);
            }
            FoxContext c = Context(rec, t);
            if (t.KeyType != 'C') {
                if (prefixLast || values.Length != 1) return null;
                return FoxExpr.KeyBytes(t.Key.Eval(c), t.KeyLen);
            }
            if (t.Collated) {
                // веса сортировки: значения подряд, без хвостовых пробелов; ищется всегда начало ключа,
                // точное совпадение потом сверяется по самим записям
                List<byte> raw = new List<byte>();
                for (int i = 0; i < values.Length; i++) {
                    FoxValue v = t.Terms[i].Eval(c);
                    if (v.Type != 'C' || (prefixLast && i == values.Length - 1 && !t.Terms[i].PrefixSafe())) return null;
                    raw.AddRange(v.Text);
                }
                return CollatedKey(t, raw.ToArray(), true);
            }
            List<byte> key = new List<byte>();
            for (int i = 0; i < values.Length; i++) {
                FoxValue v = t.Terms[i].Eval(c);
                if (v.Type != 'C') return null;
                int len = v.Text.Length;
                if (i == values.Length - 1 && prefixLast) {
                    if (!t.Terms[i].PrefixSafe()) return null;
                    while (len > 0 && v.Text[len - 1] == ' ') len--;
                }
                for (int k = 0; k < len; k++) key.Add(v.Text[k]);
            }
            if (key.Count == 0) return null;
            if (key.Count > t.KeyLen) key.RemoveRange(t.KeyLen, key.Count - t.KeyLen);
            return key.ToArray();
        } catch (FormatException) {
            return null;
        }
    }

    // ---- поиск ----

    class Seeker {
        public readonly Dictionary<int, bool> Found = new Dictionary<int, bool>();
        public bool More;
        public int Seeks, Reads;
        public readonly List<string> Tags = new List<string>();
        readonly Dictionary<string, IndexReader> readers = new Dictionary<string, IndexReader>();

        public int Seek(IndexTag t, byte[] key) {
            if (key == null) return 0;
            IndexReader r;
            if (!readers.TryGetValue(t.FilePath, out r)) { r = new IndexReader(t.FilePath); readers[t.FilePath] = r; }
            if (!Tags.Contains(t.Label)) Tags.Add(t.Label);
            Seeks++;
            int before = r.Reads;
            bool more;
            List<int> list = r.Seek(t, key, SeekLimit, out more);
            Reads += r.Reads - before;
            if (more) More = true;
            int added = 0;
            foreach (int n in list) if (!Found.ContainsKey(n)) { Found[n] = true; added++; }
            return list.Count;
        }

        public void Close() { foreach (IndexReader r in readers.Values) r.Dispose(); }
    }

    public SearchResult Search(string text, SearchMode mode, Dictionary<string, bool> selsovety, bool partial) {
        return Search(text, mode, selsovety, FetchLimit, partial);
    }

    // ---- свой индекс по ФИО (в базе индекса по ФИО нет) - см. NameIndex ----
    NameIndex names;                       // готовый - по нему ищем
    readonly object namesLock = new object();
    public string NamesFile;               // файл индекса (в папке программы)

    public bool NamesNeeded { get { return Mem == null && Header.FieldIndex("FIO") >= 0 && TagFor("FIO") == null; } }
    public bool NamesReady { get { return names != null; } }

    // Файл индекса при запуске. Возвращает индекс, который надо (до)строить в фоне, или null - готов, строить не надо
    public NameIndex OpenNames() {
        NameIndex n = null;
        try { if (NamesFile != null && File.Exists(NamesFile)) n = NameIndex.Load(NamesFile, Header, FilePath); }
        catch (Exception ex) { Report.Line("Свой индекс ФИО не прочитался (" + ex.Message + ") - нужно построить заново (кнопкой)"); n = null; }
        if (n == null) { Report.Line("Свой индекс ФИО: ещё нет - строится кнопкой «построить» (" + NamesFile + ")"); return new NameIndex(Header, FilePath); }
        int count;
        using (FileStream fs = OpenTable()) count = NameIndex.RecordCount(fs);
        if (count < n.Scanned) { Report.Line("Свой индекс ФИО: таблицу пересобрали (записей стало меньше) - нужно построить заново (кнопкой)"); return new NameIndex(Header, FilePath); }
        n.Total = count;
        if (count - n.Scanned > 20000) { Report.Line("Свой индекс ФИО: недостроен (" + n.Scanned + " из " + count + ") - достраивается кнопкой"); return n; }
        lock (namesLock) names = n;
        Report.Line("Свой индекс ФИО: готов, " + n.Describe());
        // полностью заново сам больше не перестраивается (было - раз в сутки: перечитывалась вся база по сети, минуты, поиск
        // в это время стоял); новые абоненты дочитываются (CatchUpNames), исправленные Ф.И.О. - кнопкой «обновить»
        return null;
    }

    // полностью заново (кнопка «обновить»: в базе исправляли Ф.И.О.)
    public NameIndex NewNames() { return new NameIndex(Header, FilePath); }

    public DateTime NamesBuilt { get { lock (namesLock) return names == null ? DateTime.MinValue : names.Built; } }

    // новые записи таблицы (новые абоненты) - дочитать в индекс и сохранить: читается только конец таблицы.
    // -1 - таблицу пересобрали (записей стало меньше), индекс не годится
    public int CatchUpNames() {
        lock (namesLock) {
            if (names == null) return 0;
            int added;
            using (FileStream fs = OpenTable())
                if (!names.Update(fs, out added)) { names = null; return -1; }
            if (added > 0 && NamesFile != null) {
                try { names.Save(NamesFile); } catch (Exception ex) { Report.Line("Свой индекс ФИО не сохранился: " + ex.Message); }
            }
            return added;
        }
    }

    // сколько поисков идёт сейчас (по всем окнам): сборка индекса ФИО им уступает - иначе поиск ждёт диск/сеть
    static int activeSearches;
    public static bool Searching { get { return System.Threading.Thread.VolatileRead(ref activeSearches) > 0; } }

    // (до)строить в фоне; готовый становится рабочим и сохраняется. savePartial - сохранять по ходу
    // (первая сборка: прервали - продолжится; при пересборке - нет, чтобы не испортить рабочий файл)
    public void BuildNames(NameIndex n, LoadProgress progress, bool savePartial) {
        try { n.Continue(FilePath, progress, savePartial ? NamesFile : null); }
        catch (OperationCanceledException) {
            // остановили первую сборку - недостроенное сохраняется, «достроить» (и после перезапуска) продолжит с того же места
            if (savePartial && NamesFile != null && n.Scanned > 0)
                try { n.Save(NamesFile); } catch (Exception ex) { Report.Line("Свой индекс ФИО не сохранился: " + ex.Message); }
            throw;
        }
        lock (namesLock) {
            names = n;
            try { if (NamesFile != null) n.Save(NamesFile); }
            catch (Exception ex) { Report.Line("Свой индекс ФИО не сохранился: " + ex.Message); }
        }
        Report.Line(DateTime.Now.ToString("HH:mm:ss") + "  Свой индекс ФИО построен за " + n.Seconds.ToString("0") + " с: " + n.Describe());
    }

    // ФИО по своему индексу: номера записей (перед этим дочитываются новые записи таблицы); null - индекс устарел
    List<int> FindNames(FileStream fs, string name, bool partial, out string how) {
        List<string> words = partial ? new List<string>(DbfTable.SplitWords(name.Replace('ё', 'е').Replace('Ё', 'Е'))) : AbonentQuery.PersonWords(name);
        lock (namesLock) {
            int added;
            if (!names.Update(fs, out added)) { names = null; how = "свой индекс ФИО устарел (таблицу пересобрали)"; return null; }
            List<int> found = names.Find(words, partial);
            how = "свой индекс ФИО: " + names.Describe() + (added > 0 ? ", дочитано новых записей: " + added : "") + "; совпало " + found.Count;
            return found;
        }
    }

    // ФИО (и, если есть, адрес "Иванов Боровляны") из найденных по своему индексу; null - так не получилось
    SearchResult SearchNames(SearchResult res, string text, bool withAddress, Dictionary<string, bool> selsovety, int limit, DateTime started) {
        string name = text, addr = null;
        if (withAddress) {
            if (!SplitNameAddress(text, out name, out addr)) return null;
            AddressMatch m = Dir.Match(addr);
            res.Address = m;
            if (m.Problem != null) { res.Note = m.Problem; return Finish(res, null, selsovety, started); }
        }
        using (FileStream fs = OpenTable()) {
            string how;
            List<int> recNos = FindNames(fs, name, res.Partial, out how);
            if (recNos == null) { res.NoIndex = true; res.How = how; return Finish(res, null, selsovety, started); }
            // с адресом, а по ФИО слишком много (частая фамилия) - лучше взять абонентов этого места по индексу адреса
            if (addr != null && recNos.Count > limit) return null;
            if (recNos.Count > limit) res.TooMany = true;
            int deleted;
            DbfTable part = Fetch(fs, recNos, limit, out deleted);
            res.NameText = name;
            if (addr != null) res.AddressText = addr;
            res.How = how + ", прочитано записей " + part.Count + (deleted > 0 ? ", удалённых пропущено " + deleted : "");
            return Finish(res, part, selsovety, started);
        }
    }

    // Ошибка чтения бывает, если программа базы как раз дописывает индекс - тогда пробуем ещё раз.
    // partial - частичное совпадение (начало номера, похожие слова); иначе - только точное
    public SearchResult Search(string text, SearchMode mode, Dictionary<string, bool> selsovety, int limit, bool partial) {
        System.Threading.Interlocked.Increment(ref activeSearches);
        try { return SearchCounted(text, mode, selsovety, limit, partial); }
        finally { System.Threading.Interlocked.Decrement(ref activeSearches); }
    }

    SearchResult SearchCounted(string text, SearchMode mode, Dictionary<string, bool> selsovety, int limit, bool partial) {
        SearchResult r = SearchOnce(text, mode, selsovety, limit, partial, false);
        if (r.Error != null) {
            System.Threading.Thread.Sleep(300);
            SearchResult again = SearchOnce(text, mode, selsovety, limit, partial, false);
            again.How += "; (со второй попытки, первая: " + r.Error + ")";
            return again;
        }
        // по индексу ФИО целиком не нашлось - может, в конце адрес ("Иванов Боровляны")
        if (mode == SearchMode.Name && r.Rows.Count == 0 && r.Hidden == 0 && r.AddressText == null && !r.NoIndex && (TagFor("FIO") != null || names != null)) {
            SearchResult a = SearchOnce(text, mode, selsovety, limit, partial, true);
            if (a.Error == null && (a.Rows.Count > 0 || a.Hidden > 0 || a.NameText != null)) return a;
        }
        return r;
    }

    // withAddress - ФИО с адресом ("Иванов Боровляны"), даже если есть индекс по ФИО
    SearchResult SearchOnce(string text, SearchMode mode, Dictionary<string, bool> selsovety, int limit, bool partial, bool withAddress) {
        if (Mem != null) return SearchMemory(text, mode, selsovety, limit, partial);
        DateTime started = DateTime.Now;
        SearchResult res = new SearchResult();
        res.Text = text;
        res.Mode = mode;
        res.Partial = partial;
        if (mode == SearchMode.Name && names != null && TagFor("FIO") == null) {
            try {
                SearchResult r = SearchNames(res, text, withAddress, selsovety, limit, started);
                if (r != null) return r;
                res = new SearchResult();
                res.Text = text;
                res.Mode = mode;
                res.Partial = partial;
            } catch (Exception ex) {
                res.Error = ex.Message;
                res.How += " ОШИБКА: " + ex.GetType().Name + ": " + ex.Message;
                return Finish(res, null, selsovety, started);
            }
        }
        Seeker s = new Seeker();
        try {
            bool ok;
            switch (mode) {
                case SearchMode.Account: ok = SeekAccount(text, s, res, partial); break;
                case SearchMode.Meter: ok = SeekMeter(text, s, res, partial); break;
                case SearchMode.Name:
                    if (withAddress) ok = SeekNameByAddress(text, s, res, partial);
                    else {
                        ok = SeekName(text, s, res, partial);
                        if (!ok && res.Note.Length == 0) ok = SeekNameByAddress(text, s, res, partial);
                    }
                    break;
                default: ok = partial || Dir == null ? SeekAddress(text, s, res) : SeekAddressExact(text, s, res); break;
            }
            if (!ok) { res.NoIndex = res.Error == null && res.Note.Length == 0; return Finish(res, null, selsovety, started); }
            List<int> recNos = new List<int>(s.Found.Keys);
            if (mode == SearchMode.Address) limit = Math.Max(limit, SeekLimit);
            if (res.NameText != null) limit = Math.Max(limit, NameByAddressLimit);
            if (recNos.Count > limit || s.More) res.TooMany = true;
            int deleted;
            DbfTable part;
            using (FileStream fs = OpenTable()) part = Fetch(fs, recNos, limit, out deleted);
            res.How = "индекс " + string.Join(", ", s.Tags.ToArray()) + ": поисков " + s.Seeks + ", чтений индекса " + s.Reads
                + ", ключей нашлось " + recNos.Count + (s.More ? "+" : "") + ", прочитано записей " + part.Count
                + (deleted > 0 ? ", удалённых пропущено " + deleted : "") + (res.How.Length > 0 ? "; " + res.How : "");
            return Finish(res, part, selsovety, started);
        } catch (Exception ex) {
            res.Error = ex.Message;
            res.How += " ОШИБКА: " + ex.GetType().Name + ": " + ex.Message;
            return Finish(res, null, selsovety, started);
        } finally {
            s.Close();
        }
    }

    // Перебор всей таблицы - если нужного индекса нет (долго, но находит всё)
    public SearchResult Scan(string text, SearchMode mode, Dictionary<string, bool> selsovety, LoadProgress progress, bool partial) {
        DateTime started = DateTime.Now;
        SearchResult res = new SearchResult();
        res.Text = text;
        res.Mode = mode;
        res.Scanned = true;
        res.Partial = partial;
        DbfTable part;
        if (mode == SearchMode.Address && Dir != null && Header.FieldIndex("UL") >= 0) {
            Dictionary<string, bool> codes = new Dictionary<string, bool>();
            if (partial) {
                int best;
                foreach (string c in Dir.BestStreets(AddressParts.Parse(text).Words, null, out best)) codes[c] = true;
            } else {
                res.Address = Dir.Match(text);
                if (res.Address.Problem != null) { res.Note = res.Address.Problem; return Finish(res, null, selsovety, started); }
                foreach (string c in res.Address.Codes) codes[c] = true;
            }
            DbfField ul = Header.Fields[Header.FieldIndex("UL")];
            part = DbfTable.Load(FilePath, null, delegate(byte[] rec, int start) {
                return codes.ContainsKey(StreetDirectory.NormalizeCode(Encoding.ASCII.GetString(rec, start + ul.Offset, ul.Length)));
            }, progress, 20000);
        } else {
            // предварительный отбор: запись должна содержать номер (или фамилию); точность проверяется потом
            string words = text;
            if (mode == SearchMode.Account) { words = Digits(text).TrimStart('0'); if (words.Length == 0) words = Digits(text); }
            else if (mode == SearchMode.Meter) words = LongestDigits(text).TrimStart('0');
            else if (mode == SearchMode.Name && !partial) { string[] w = DbfTable.SplitWords(text.Replace('.', ' ')); words = w.Length > 0 ? w[0] : ""; }
            part = DbfTable.Load(FilePath, words, null, progress, 20000);
        }
        res.TooMany = part.Truncated;
        double mb = part.BytesRead / 1048576.0;
        res.How = "перебор всей таблицы: " + mb.ToString("0") + " МБ за " + part.Seconds.ToString("0") + " с, записей " + part.Total + ", подошло " + part.Count;
        return Finish(res, part, selsovety, started);
    }

    SearchResult Finish(SearchResult res, DbfTable part, Dictionary<string, bool> selsovety, DateTime started) {
        if (part == null) part = DbfTable.CreateLike(Header);
        part.FilePath = FilePath;
        res.Table = part;
        res.Query = new AbonentQuery(part, Dir);
        res.Query.Partial = res.Partial;
        res.Query.Address = res.Address;
        if (part.Count > 0 && res.Note.Length == 0) {
            List<int> rows = res.Query.Find(res.NameText ?? res.Text, res.Mode);
            // ФИО с адресом: из найденных по ФИО - только по этому адресу (дом, квартира - если вписаны)
            if (res.NameText != null && res.AddressText != null) {
                Dictionary<int, bool> here = new Dictionary<int, bool>();
                foreach (int row in res.Query.Find(res.AddressText, SearchMode.Address)) here[row] = true;
                rows = rows.FindAll(delegate(int row) { return here.ContainsKey(row); });
            }
            if (Mem != null && part == Mem && rows.Count > memLimit) { rows.RemoveRange(memLimit, rows.Count - memLimit); res.TooMany = true; }
            int ul = part.FieldIndex("UL");
            foreach (int row in rows) {
                if (Dir != null && ul >= 0 && selsovety != null
                    && !Dir.InSelsovety(DbfTable.Format(part.GetValue(row, ul, null), true), selsovety)) { res.Hidden++; continue; }
                res.Rows.Add(row);
            }
            if (res.Rows.Count > 0) AddExtras(res);
        }
        res.Seconds = (DateTime.Now - started).TotalSeconds;
        return res;
    }

    // Тариф (T1, T2...) и мощность для найденных; лицевые одного счётчика - рядом, по порядку тарифов
    // Дополнительный поиск к найденному: другие тарифы того же счётчика (ABDIF_T), другие счётчики на том же
    // адресе и абоненты с тем же ФИО в том же доме. Найденное и добавленное собирается в группы (рамка).
    void AddExtras(SearchResult res) {
        int nab = res.Table.FieldIndex("NAB");
        if (nab < 0) return;
        Dictionary<int, string> mainOf = new Dictionary<int, string>();
        if (Extra != null) {
            foreach (int row in res.Rows) {
                string v = DbfTable.Format(res.Table.GetValue(row, nab, null), true);
                string main;
                int t = Extra.Tariff(v, out main);
                if (t > 0) { res.Tariff[row] = t; mainOf[row] = main == null ? ExtraInfo.Nab(v) : main; }
            }
            if (res.Tariff.Count > 0) AddSiblings(res, nab, mainOf);
        }
        try { AddRelated(res, nab, mainOf); }
        catch (Exception ex) { res.How += "; поиск по адресу/ФИО не удался: " + ex.Message; }
        Arrange(res, mainOf);
        if (Extra == null) return;
        List<string> nabs = new List<string>();
        foreach (int row in res.Rows) if (nabs.Count < 100) nabs.Add(DbfTable.Format(res.Table.GetValue(row, nab, null), true));
        try {
            Dictionary<string, string> power = Extra.Power(nabs);
            foreach (int row in res.Rows) {
                string p;
                if (power.TryGetValue(ExtraInfo.Nab(DbfTable.Format(res.Table.GetValue(row, nab, null), true)), out p)) res.Power[row] = p;
            }
        } catch (Exception ex) {
            res.How += "; мощность не прочиталась: " + ex.Message;
        }
    }

    string Field(DbfTable t, int row, int field) {
        return field < 0 ? "" : DbfTable.Format(t.GetValue(row, field, null), true).Trim();
    }

    // адрес целиком (улица, дом, корпус, квартира) - для сравнения; пусто, если дома нет
    string AddrKey(DbfTable t, int row) {
        string dom = AddressMatch.Num(Field(t, row, t.FieldIndex("DOM")));
        if (dom.Length == 0) return "";
        return StreetDirectory.NormalizeCode(Field(t, row, t.FieldIndex("UL"))) + "|" + dom + "|"
            + Part(Field(t, row, t.FieldIndex("KOR"))) + "|" + Part(Field(t, row, t.FieldIndex("KV")));
    }

    // корпус/квартира "0" - то же, что пусто (частный дом)
    static string Part(string v) {
        string n = AddressMatch.Num(v);
        return n == "0" ? "" : n;
    }

    string HouseKey(DbfTable t, int row) {
        string dom = AddressMatch.Num(Field(t, row, t.FieldIndex("DOM")));
        return dom.Length == 0 ? "" : StreetDirectory.NormalizeCode(Field(t, row, t.FieldIndex("UL"))) + "|" + dom;
    }

    static string FioKey(string fio) {
        StringBuilder sb = new StringBuilder();
        foreach (string w in fio.ToLowerInvariant().Replace('ё', 'е').Split(new char[] { ' ', '.', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)) {
            if (sb.Length > 0) sb.Append(' ');
            sb.Append(w);
        }
        return sb.ToString();
    }

    // Другие абоненты того же дома: с тем же адресом (второй счётчик) или с тем же ФИО. Дом читается по индексу
    // улица+дом; ФИО ищется только в доме найденного (индекса по ФИО в базе нет).
    void AddRelated(SearchResult res, int nab, Dictionary<int, string> mainOf) {
        DbfTable tb = res.Table;
        int ulF = tb.FieldIndex("UL"), domF = tb.FieldIndex("DOM"), fioF = tb.FieldIndex("FIO");
        if (ulF < 0 || domF < 0) return;
        IndexTag t = Mem != null ? null : TagFor("UL", true);
        if (Mem == null && (t == null || t.Terms.Count < 2 || t.TermFields[1] != "DOM")) return;
        List<int> searched = new List<int>();
        foreach (int row in res.Rows) if (!res.Added.ContainsKey(row)) searched.Add(row);
        // дома найденных (не больше 30 - иначе поиск по общему адресу читал бы слишком много)
        Dictionary<string, List<int>> houses = new Dictionary<string, List<int>>();
        foreach (int row in searched) {
            string h = HouseKey(tb, row);
            if (h.Length == 0) continue;
            List<int> list;
            if (!houses.TryGetValue(h, out list)) { if (houses.Count >= 30) continue; list = new List<int>(); houses[h] = list; }
            list.Add(row);
        }
        if (houses.Count == 0) return;
        Dictionary<int, int> rowOfRec = new Dictionary<int, int>();
        for (int row = 0; row < tb.Count; row++) rowOfRec[tb.RecNos[row]] = row;
        List<int> foundRecs = new List<int>();
        if (Mem != null) {
            // режим Excel: вся таблица в памяти - дома найденных ищем перебором строк
            for (int row = 0; row < tb.Count; row++) if (houses.ContainsKey(HouseKey(tb, row))) foundRecs.Add(tb.RecNos[row]);
        } else {
            Seeker s = new Seeker();
            try {
                foreach (List<int> list in houses.Values) {
                    int r0 = list[0];
                    s.Seek(t, KeyFor(t, new string[] { Field(tb, r0, ulF), Field(tb, r0, domF) }, false));
                }
            } finally {
                s.Close();
            }
            foundRecs.AddRange(s.Found.Keys);
        }
        List<int> missing = new List<int>();
        foreach (int rec in foundRecs) if (!rowOfRec.ContainsKey(rec)) missing.Add(rec);
        bool grown = false;
        if (missing.Count > 0) {
            int deleted;
            DbfTable more;
            using (FileStream fs = OpenTable()) more = Fetch(fs, missing, 3000, out deleted);
            for (int row = 0; row < more.Count; row++) {
                int start;
                byte[] buf = more.RecordBuffer(row, out start);
                tb.AddRecord(buf, start, more.RecNos[row]);
                rowOfRec[more.RecNos[row]] = tb.Count - 1;
                grown = true;
            }
        }
        Dictionary<int, bool> shown = new Dictionary<int, bool>();
        foreach (int row in res.Rows) shown[row] = true;
        int added = 0;
        foreach (int rec in foundRecs) {
            int h;
            if (!rowOfRec.TryGetValue(rec, out h) || shown.ContainsKey(h)) continue;
            List<int> list;
            if (!houses.TryGetValue(HouseKey(tb, h), out list)) continue;   // начало номера дома совпало, а дом другой ("180")
            string addr = AddrKey(tb, h), fio = fioF < 0 ? "" : FioKey(Field(tb, h, fioF));
            string hNab = ExtraInfo.Nab(Field(tb, h, nab));
            foreach (int r in list) {
                if (ExtraInfo.Nab(Field(tb, r, nab)) == hNab) continue;
                string why = null;
                if (addr.Length > 0 && addr == AddrKey(tb, r)) why = "тот же адрес - ещё один счётчик";
                else if (fio.Length > 0 && fioF >= 0 && fio == FioKey(Field(tb, r, fioF))) why = "то же ФИО в этом доме";
                if (why == null) continue;
                string main;
                if (Extra != null) {
                    int tr = Extra.Tariff(Field(tb, h, nab), out main);
                    if (tr > 0) {
                        res.Tariff[h] = tr;
                        mainOf[h] = main == null ? hNab : main;
                        string rm;
                        if (mainOf.TryGetValue(r, out rm) && rm == mainOf[h]) { shown[h] = true; break; }   // это тариф того же счётчика
                    }
                }
                res.Rows.Add(h);
                res.Added[h] = true;
                res.Related[h] = why;
                shown[h] = true;
                added++;
                break;
            }
        }
        if (grown) {
            AbonentQuery q = new AbonentQuery(tb, Dir);
            q.Partial = res.Query.Partial;
            q.Address = res.Query.Address;
            q.LastExplain = res.Query.LastExplain;
            q.Miss = res.Query.Miss;
            res.Query = q;
        }
        res.How += "; домов проверено на второй счётчик/то же ФИО: " + houses.Count + ", добавлено абонентов: " + added;
    }

    // Группы (рамка): тарифы одного счётчика, абоненты одного адреса и добавленные к найденному.
    // В группе больше одного счётчика - не тарифные строки оранжевым. Группа стоит на месте первой её строки.
    void Arrange(SearchResult res, Dictionary<int, string> mainOf) {
        DbfTable tb = res.Table;
        Dictionary<int, int> parent = new Dictionary<int, int>();
        foreach (int row in res.Rows) parent[row] = row;
        Dictionary<string, int> firstOf = new Dictionary<string, int>();
        foreach (int row in res.Rows) {
            string m;
            if (mainOf.TryGetValue(row, out m)) Join(parent, firstOf, "T" + m, row);
            string a = AddrKey(tb, row);
            if (a.Length > 0) Join(parent, firstOf, "A" + a, row);
        }
        // один человек (то же ФИО) в одном доме - тоже вместе
        int fioF = tb.FieldIndex("FIO");
        if (fioF >= 0)
            foreach (int row in res.Rows) {
                string h = HouseKey(tb, row), f = FioKey(Field(tb, row, fioF));
                if (h.Length > 0 && f.Length > 0) Join(parent, firstOf, "F" + h + "|" + f, row);
            }
        Dictionary<int, List<int>> members = new Dictionary<int, List<int>>();
        foreach (int row in res.Rows) {
            int root = Find(parent, row);
            List<int> l;
            if (!members.TryGetValue(root, out l)) { l = new List<int>(); members[root] = l; }
            l.Add(row);
        }
        Dictionary<int, int> original = new Dictionary<int, int>();
        for (int i = 0; i < res.Rows.Count; i++) original[res.Rows[i]] = i;
        Dictionary<int, int> clusterPos = new Dictionary<int, int>(), unitPos = new Dictionary<int, int>();
        Dictionary<string, int> unitFirst = new Dictionary<string, int>();
        foreach (KeyValuePair<int, List<int>> kv in members) {
            List<int> l = kv.Value;
            int pos = int.MaxValue;
            Dictionary<string, bool> units = new Dictionary<string, bool>();
            foreach (int row in l) {
                pos = Math.Min(pos, original[row]);
                string m;
                string unit = mainOf.TryGetValue(row, out m) ? "T" + m : "R" + row;
                units[unit] = true;
                int up;
                if (!unitFirst.TryGetValue(unit, out up) || original[row] < up) unitFirst[unit] = original[row];
            }
            foreach (int row in l) {
                clusterPos[row] = pos;
                if (l.Count > 1) res.Group[row] = "G" + kv.Key;
                if (units.Count > 1 && !res.Tariff.ContainsKey(row)) res.Orange[row] = true;
            }
        }
        foreach (int row in res.Rows) {
            string m;
            unitPos[row] = unitFirst[mainOf.TryGetValue(row, out m) ? "T" + m : "R" + row];
        }
        List<int> order = new List<int>(res.Rows);
        order.Sort(delegate(int x, int y) {
            int c = clusterPos[x].CompareTo(clusterPos[y]);
            if (c == 0) c = unitPos[x].CompareTo(unitPos[y]);
            if (c == 0) { int tx, ty; res.Tariff.TryGetValue(x, out tx); res.Tariff.TryGetValue(y, out ty); c = tx.CompareTo(ty); }
            return c != 0 ? c : original[x].CompareTo(original[y]);
        });
        res.Rows = order;
    }

    static int Find(Dictionary<int, int> parent, int x) {
        while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
        return x;
    }

    static void Join(Dictionary<int, int> parent, Dictionary<string, int> firstOf, string key, int row) {
        int first;
        if (!firstOf.TryGetValue(key, out first)) { firstOf[key] = row; return; }
        int a = Find(parent, first), b = Find(parent, row);
        if (a != b) parent[b] = a;
    }

    // Нашёлся лицевой одного из тарифов - добавляем остальные тарифы того же счётчика (их не искали - помечаются)
    void AddSiblings(SearchResult res, int nab, Dictionary<int, string> mainOf) {
        Dictionary<string, int> rowOf = new Dictionary<string, int>();
        for (int row = 0; row < res.Table.Count; row++) {
            string k = ExtraInfo.Nab(DbfTable.Format(res.Table.GetValue(row, nab, null), true));
            if (!rowOf.ContainsKey(k)) rowOf[k] = row;
        }
        Dictionary<int, bool> shown = new Dictionary<int, bool>();
        foreach (int row in res.Rows) shown[row] = true;
        List<string> missing = new List<string>();
        Dictionary<string, string> wantMain = new Dictionary<string, string>();
        Dictionary<string, bool> doneGroup = new Dictionary<string, bool>();
        foreach (string main in mainOf.Values) {
            if (doneGroup.ContainsKey(main)) continue;
            doneGroup[main] = true;
            foreach (KeyValuePair<int, string> sib in Extra.Group(main)) {
                string k = ExtraInfo.Nab(sib.Value);
                wantMain[k] = main;
                if (!rowOf.ContainsKey(k)) missing.Add(sib.Value);
            }
        }
        bool grown = false;
        if (missing.Count > 0) {
            try {
                DbfTable more;
                Dictionary<string, int> found = LookupNabs(missing, out more);
                foreach (KeyValuePair<string, int> kv in found) {
                    int start;
                    byte[] buf = more.RecordBuffer(kv.Value, out start);
                    res.Table.AddRecord(buf, start, more.RecNos[kv.Value]);
                    rowOf[kv.Key] = res.Table.Count - 1;
                    grown = true;
                }
            } catch (Exception ex) {
                res.How += "; другие тарифы не прочитались: " + ex.Message;
            }
        }
        foreach (KeyValuePair<string, string> kv in wantMain) {
            int row;
            if (!rowOf.TryGetValue(kv.Key, out row) || shown.ContainsKey(row)) continue;
            string main;
            int t = Extra.Tariff(kv.Key, out main);
            if (t <= 0) continue;
            res.Rows.Add(row);
            res.Added[row] = true;
            res.Tariff[row] = t;
            mainOf[row] = kv.Value;
            shown[row] = true;
        }
        if (grown) {
            // в таблице результата добавились записи - столбцы (улица по справочнику) считаем заново
            AbonentQuery q = new AbonentQuery(res.Table, Dir);
            q.Partial = res.Query.Partial;
            q.Address = res.Query.Address;
            q.LastExplain = res.Query.LastExplain;
            q.Miss = res.Query.Miss;
            res.Query = q;
        }
        if (res.Added.Count > 0) res.How += "; добавлено лицевых других тарифов тех же счётчиков: " + res.Added.Count;
    }

    // Записи по номерам абонентов (по индексу NAB): номер (без нулей впереди) -> строка в table. null - нет индекса
    public Dictionary<string, int> LookupNabs(List<string> nabs, out DbfTable table) {
        Dictionary<string, int> result = new Dictionary<string, int>();
        table = null;
        IndexTag t = TagFor("NAB");
        if (t == null) return result;
        int f = Header.FieldIndex("NAB");
        int width = Header.Fields[f].Length;
        Seeker s = new Seeker();
        try {
            foreach (string raw in nabs) {
                string v = raw.Trim();
                if (v.Length == 0) continue;
                List<string> variants = new List<string>();
                AddVariant(variants, v);
                AddVariant(variants, ExtraInfo.Nab(v));
                string core = ExtraInfo.Nab(v);
                for (int w = core.Length + 1; w <= width && Header.Fields[f].Type == 'C'; w++) AddVariant(variants, core.PadLeft(w, '0'));
                foreach (string x in variants) s.Seek(t, KeyFor(t, new string[] { x }, false));
            }
        } finally {
            s.Close();
        }
        int deleted;
        using (FileStream fs = OpenTable()) table = Fetch(fs, new List<int>(s.Found.Keys), 2000, out deleted);
        Dictionary<string, bool> wanted = new Dictionary<string, bool>();
        foreach (string raw in nabs) wanted[ExtraInfo.Nab(raw)] = true;
        for (int row = 0; row < table.Count; row++) {
            string k = ExtraInfo.Nab(DbfTable.Format(table.GetValue(row, f, null), true));
            if (wanted.ContainsKey(k) && !result.ContainsKey(k)) result[k] = row;
        }
        return result;
    }

    static string Digits(string s) {
        StringBuilder sb = new StringBuilder();
        foreach (char c in s) if (c >= '0' && c <= '9') sb.Append(c);
        return sb.ToString();
    }

    static string LongestDigits(string s) {
        string best = "", cur = "";
        foreach (char c in s + " ") {
            if (c >= '0' && c <= '9') { cur += c; continue; }
            if (cur.Length > best.Length) best = cur;
            cur = "";
        }
        return best;
    }

    // Как в этой таблице обычно записано поле: длина числа, нули впереди, прижато вправо, заглавные буквы
    class Style {
        public int Digits;
        public bool Zeros, Right, Upper;
    }

    Style StyleOf(string field) {
        Style st = new Style();
        int f = Sample.FieldIndex(field);
        if (f < 0 || Sample.Count == 0) return st;
        Dictionary<int, int> lengths = new Dictionary<int, int>();
        int filled = 0, zeros = 0, right = 0, upper = 0, letters = 0;
        for (int r = 0; r < Sample.Count; r++) {
            int start;
            byte[] buf = Sample.RecordBuffer(r, out start);
            string raw = Sample.Enc.GetString(buf, start + Sample.Fields[f].Offset, Sample.Fields[f].Length);
            string v = raw.Trim();
            if (v.Length == 0) continue;
            filled++;
            if (raw.StartsWith(" ")) right++;
            if (v.StartsWith("0")) zeros++;
            int n;
            lengths.TryGetValue(v.Length, out n);
            lengths[v.Length] = n + 1;
            foreach (char c in v) if (char.IsLetter(c)) { letters++; if (char.IsUpper(c)) upper++; }
        }
        int best = 0;
        foreach (KeyValuePair<int, int> kv in lengths) if (kv.Value > best) { best = kv.Value; st.Digits = kv.Key; }
        st.Zeros = filled > 0 && zeros * 2 > filled;
        st.Right = filled > 0 && right * 2 > filled;
        st.Upper = letters > 0 && upper * 10 > letters * 7;
        return st;
    }

    static void AddVariant(List<string> list, string v) {
        if (v != null && v.Length > 0 && !list.Contains(v)) list.Add(v);
    }

    // текст как записан в поле: прижат вправо, если так принято в таблице
    string Aligned(string field, string v, Style st) {
        int f = Header.FieldIndex(field);
        if (f < 0 || !st.Right || Header.Fields[f].Type != 'C') return v;
        return v.PadLeft(Header.Fields[f].Length);
    }

    // Лицевой: точный номер в нескольких видах (с нулями впереди и без);
    // при частичном совпадении ещё номера, начинающиеся так, и номер внутри длинного Л/С
    bool SeekAccount(string text, Seeker s, SearchResult res, bool partial) {
        string digits = Digits(text);
        if (digits.Length == 0) { res.Note = "Впишите номер."; return false; }
        string core = digits.TrimStart('0');
        if (core.Length == 0) core = "0";
        bool any = false;
        foreach (string field in AccountFields) {
            IndexTag t = TagFor(field);
            if (t == null) continue;
            any = true;
            int f = Header.FieldIndex(field);
            int width = Header.Fields[f].Length;
            List<string> exact = new List<string>();
            AddVariant(exact, digits);
            AddVariant(exact, core);
            if (Header.Fields[f].Type == 'C') for (int w = core.Length + 1; w <= width; w++) AddVariant(exact, core.PadLeft(w, '0'));
            foreach (string v in exact) {
                s.Seek(t, KeyFor(t, new string[] { v }, false));
                if (Header.Fields[f].Type == 'C') s.Seek(t, KeyFor(t, new string[] { v.PadLeft(width) }, false));
            }
            if (s.Found.Count > 0) { res.How = "точный номер (поле " + field + ")"; return true; }
        }
        if (!any) return false;
        if (!partial) { res.How = "точный номер"; return true; }
        // начало номера (только если номер не короче 4 цифр - иначе слишком много)
        if (digits.Length >= 4) {
            foreach (string field in AccountFields) {
                IndexTag t = TagFor(field);
                if (t == null || Header.Fields[Header.FieldIndex(field)].Type != 'C') continue;
                s.Seek(t, KeyFor(t, new string[] { digits }, true));
                if (core != digits) s.Seek(t, KeyFor(t, new string[] { core }, true));
                // в таблице номера с нулями впереди (044060216) - "4406021" ищем и как "04406021"
                Style st = StyleOf(field);
                if (st.Zeros) for (string z = "0" + core; z.Length < st.Digits; z = "0" + z) if (z != digits) s.Seek(t, KeyFor(t, new string[] { z }, true));
                if (s.Found.Count > 0) { res.How = "начало номера (поле " + field + ")"; return true; }
            }
        }
        // длинный Л/С, внутри которого номер абонента
        IndexTag nab = TagFor("NAB");
        if (nab != null && core.Length >= 8) {
            Style st = StyleOf("NAB");
            int len = st.Digits > 0 ? st.Digits : 9;
            for (int from = 0; from + len <= digits.Length && from < 12; from++) {
                string piece = digits.Substring(from, len);
                if (piece.TrimStart('0').Length < 5) continue;
                s.Seek(nab, KeyFor(nab, new string[] { piece }, false));
                s.Seek(nab, KeyFor(nab, new string[] { piece.TrimStart('0') }, false));
            }
            if (s.Found.Count > 0) res.How = "номер абонента внутри длинного номера";
        }
        return true;
    }

    // Счётчик: точный номер (нули впереди, пробелы, "№" не важны); при частичном совпадении - ещё начало номера.
    // Если не нашлось - то же по снятому счётчику (NSC)
    bool SeekMeter(string text, Seeker s, SearchResult res, bool partial) {
        string typed = text.Replace("№", " ").Trim();
        if (typed.Length == 0) { res.Note = "Впишите номер."; return false; }
        bool any = false;
        foreach (string field in new string[] { "NCH", "NSC" }) {
            IndexTag t = TagFor(field);
            if (t == null) continue;
            any = true;
            Style st = StyleOf(field);
            int width = Header.Fields[Header.FieldIndex(field)].Length;
            List<string> variants = new List<string>();
            AddVariant(variants, typed);
            AddVariant(variants, typed.ToUpperInvariant());
            foreach (string key in AbonentQuery.MeterKeys(typed)) {
                AddVariant(variants, key);
                AddVariant(variants, key.ToUpperInvariant());
                if (key.Length > 0 && char.IsDigit(key[0])) for (int w = key.Length + 1; w <= Math.Min(width, 12); w++) AddVariant(variants, key.PadLeft(w, '0'));
            }
            foreach (string v in variants) s.Seek(t, KeyFor(t, new string[] { Aligned(field, v, st) }, false));
            if (partial && s.Found.Count == 0 && !st.Right) foreach (string v in variants) if (v.Length >= 3) s.Seek(t, KeyFor(t, new string[] { v }, true));
            if (s.Found.Count > 0) { res.How = field == "NSC" ? "по снятому счётчику (NSC)" : "поле " + field; return true; }
        }
        return any;
    }

    static byte[] WholeWord(byte[] key, IndexTag t, bool whole) {
        if (key == null || !whole || t.Collated || key.Length >= t.KeyLen) return key;
        byte[] k = new byte[key.Length + 1];
        Buffer.BlockCopy(key, 0, k, 0, key.Length);
        k[key.Length] = (byte)' ';
        return k;
    }

    static string Title(string s) {
        StringBuilder sb = new StringBuilder();
        bool start = true;
        foreach (char c in s) {
            sb.Append(start ? char.ToUpperInvariant(c) : char.ToLowerInvariant(c));
            start = c == ' ' || c == '-' || c == '.';
        }
        return sb.ToString();
    }

    // ФИО: точно - фамилия (и имя, отчество, если вписаны) целыми словами: "иванов" не находит "Иванова";
    // частично - ФИО, начинающиеся так. Если целиком не нашлось - по одной фамилии (дальше сверяется в записях)
    bool SeekName(string text, Seeker s, SearchResult res, bool partial) {
        string[] words = DbfTable.SplitWords(text.Replace('.', ' '));
        if (words.Length == 0) { res.Note = "Впишите фамилию."; return false; }
        IndexTag t = TagFor("FIO");
        if (t == null) return false;
        Style st = StyleOf("FIO");
        for (int n = words.Length; n >= 1; n = n > 1 ? 1 : 0) {
            string q = string.Join(" ", words, 0, n);
            List<string> variants = new List<string>();
            if (st.Upper) AddVariant(variants, q.ToUpperInvariant());
            AddVariant(variants, Title(q));
            AddVariant(variants, q.ToUpperInvariant());
            AddVariant(variants, q);
            // целое слово: после него в ФИО пробел (кроме инициала - "иванов и")
            bool whole = !partial && words[n - 1].Length > 1;
            foreach (string v in variants) s.Seek(t, WholeWord(KeyFor(t, new string[] { v }, true), t, whole));
            if (s.Found.Count > 0) { res.How = n == words.Length ? "начало ФИО" : "по фамилии"; return true; }
        }
        return true;
    }

    // ФИО с адресом: "Иванов Боровляны", "Иванов Иван, Боровляны Заводская 18". Индекса по ФИО в базе нет,
    // поэтому по индексу адреса берём абонентов этого места и среди них ищем ФИО (вся таблица не читается).
    // Адрес - после запятой или последние слова, которые есть в справочнике улиц и населённых пунктов.
    // "Иванов Боровляны" -> ФИО "Иванов", адрес "Боровляны": адрес - после запятой или последние слова,
    // которые есть в справочнике улиц и населённых пунктов
    bool SplitNameAddress(string text, out string name, out string addr) {
        name = null;
        addr = null;
        if (Dir == null) return false;
        int comma = text.IndexOf(',');
        if (comma > 0) {
            name = text.Substring(0, comma).Trim();
            addr = text.Substring(comma + 1).Trim();
        } else {
            string[] w = text.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            // ФИО - первые k слов, остальное - адрес (сначала пробуем адрес подлиннее)
            for (int k = 1; k < w.Length && addr == null; k++) {
                if (char.IsDigit(w[k][0])) continue;   // число - часть ФИО или дом, адрес с него не начинается
                string a = string.Join(" ", w, k, w.Length - k);
                AddressMatch m = Dir.Match(a);
                if (m.Problem == null && m.Codes.Count > 0) { name = string.Join(" ", w, 0, k); addr = a; }
            }
        }
        return addr != null && name != null && name.Length > 0 && addr.Length > 0;
    }

    bool SeekNameByAddress(string text, Seeker s, SearchResult res, bool partial) {
        string name, addr;
        if (!SplitNameAddress(text, out name, out addr)) return false;
        if (TagFor("FIO") != null) {
            // есть индекс по ФИО: ищем ФИО по нему, адрес сверяется в найденных
            AddressMatch m = Dir.Match(addr);
            res.Address = m;
            if (m.Problem != null) { res.Note = m.Problem; return false; }
            if (!SeekName(name, s, res, partial)) return false;
            res.How = "ФИО по индексу, адрес сверяется";
        } else {
            if (!SeekAddressExact(addr, s, res)) return false;
            res.How = "ФИО среди абонентов по адресу";
        }
        res.NameText = name;
        res.AddressText = addr;
        return true;
    }

    // Точный адрес: населённый пункт -> улица в нём -> дом -> корпус -> квартира (см. StreetDirectory.Match).
    // По индексу берём абонентов найденных улиц - сразу с домом, если индекс по улице и дому.
    bool SeekAddressExact(string text, Seeker s, SearchResult res) {
        AddressMatch m = Dir.Match(text);
        res.Address = m;
        if (m.Problem != null) { res.Note = m.Problem; return false; }
        IndexTag t = TagFor("UL", true);
        if (t == null) return false;
        int got = 0;
        if (m.House != null && t.Terms.Count > 1 && t.TermFields[1] == "DOM") {
            Style st = StyleOf("DOM");
            List<string> houses = new List<string>();
            foreach (string h in new string[] { m.House, m.House.ToUpperInvariant() }) {
                AddVariant(houses, h);
                AddVariant(houses, Aligned("DOM", h, st));
            }
            foreach (string code in m.Codes) foreach (string h in houses) got += s.Seek(t, KeyFor(t, new string[] { code, h }, false));
        }
        // дом записан в базе иначе (или дом не указан) - берём улицы целиком, дом сверяется в записях
        if (got == 0) foreach (string code in m.Codes) s.Seek(t, KeyFor(t, new string[] { code }, false));
        return true;
    }

    // Частичное совпадение адреса: улицы, где совпало больше всего слов (как раньше)
    bool SeekAddress(string text, Seeker s, SearchResult res) {
        AddressParts a = AddressParts.Parse(text);
        if (a.Words.Count == 0) { res.Note = a.House != null ? "Впишите улицу или населённый пункт, не только номер дома." : "Впишите адрес."; return false; }
        IndexTag t = TagFor("UL", true);
        if (t == null) return false;
        if (Dir == null) {
            // в UL названия улиц: ищем по началу названия
            foreach (string w in a.Words) {
                if (w.Length < 3) continue;
                s.Seek(t, KeyFor(t, new string[] { w.ToUpperInvariant() }, true));
                s.Seek(t, KeyFor(t, new string[] { Title(w) }, true));
                s.Seek(t, KeyFor(t, new string[] { w }, true));
            }
            res.How = "по началу названия улицы";
            return true;
        }
        int best;
        // улицы ищем во всех сельсоветах: если адрес в невыбранном, покажем, что он там есть (скрытым)
        List<string> codes = Dir.BestStreets(a.Words, null, out best);
        res.How = "улиц по справочнику: " + codes.Count + " (совпало слов " + best + " из " + a.Words.Count + ")";
        if (codes.Count == 0) { res.Note = "Такой улицы или населённого пункта нет в справочнике улиц."; return false; }
        if (codes.Count > 300) { res.Note = "Подходит слишком много улиц (" + codes.Count + ") - уточните адрес."; return false; }
        bool withHouse = a.House != null && t.Terms.Count > 1 && t.TermFields[1] == "DOM";
        foreach (string code in codes) {
            int got = 0;
            if (withHouse) {
                got = s.Seek(t, KeyFor(t, new string[] { code, a.House.ToUpperInvariant() }, false));
                if (got == 0 && a.House.ToUpperInvariant() != a.House) got = s.Seek(t, KeyFor(t, new string[] { code, a.House }, false));
            }
            if (got == 0) s.Seek(t, KeyFor(t, new string[] { code }, false));
        }
        return true;
    }
}

// ---- точный адрес: населённый пункт -> улица в нём -> дом -> корпус -> квартира ----

// Слово адреса после разбора
public class AddrToken {
    public string Text;
    public char Kind;      // w - слово или число названия, h - "дом", k - "корпус", f - "квартира",
                           // t - тип населённого пункта (аг., д.), s - тип улицы (ул., пер.), r - лишнее (область, район, "с/с")
    public bool Ss;        // название сельсовета (стоит перед "с/с")
    public bool Bound;     // число сразу после "дом"/"корп"/"кв" - не часть названия
    public bool Used;      // уже узнано как название
    public bool Digit { get { return Text.Length > 0 && char.IsDigit(Text[0]); } }
}

// Слова адреса и названия из справочников приводятся к одному виду: маленькие буквы, ё -> е,
// без знаков препинания, сокращения через дефис ("пр-т", "с/с") - одним словом
public static class AddressText {
    static readonly string[][] Glued = {
        new string[] { "пр-т", "прт" }, new string[] { "б-р", "бр" }, new string[] { "р-н", "рн" }, new string[] { "с/с", "сс" },
        new string[] { "кв-л", "квл" }, new string[] { "кв-ра", "квра" }, new string[] { "пр-д", "прд" }, new string[] { "г.п.", "гп" },
        new string[] { "р.п.", "рп" }, new string[] { "а.г.", "аг" } };
    public static readonly string[] TownTypes = {
        "г", "город", "аг", "агрогородок", "п", "пос", "поселок", "гп", "рп", "кп", "д", "дер", "деревня", "с", "село",
        "х", "хут", "хутор", "ст", "станция" };
    public static readonly string[] StreetTypes = {
        "ул", "улица", "пер", "переулок", "пр", "прт", "просп", "проспект", "пл", "площадь", "бр", "бульв", "бульвар",
        "ш", "шоссе", "туп", "тупик", "проезд", "прд", "мкр", "мкрн", "микрорайон", "наб", "набережная", "тракт",
        "линия", "квл", "квартал", "аллея", "спуск" };
    static readonly string[] Regions = { "беларусь", "республика", "рб" };

    public static List<string> Words(string s) {
        string t = " " + s.ToLowerInvariant().Replace('ё', 'е') + " ";
        foreach (string[] g in Glued) t = t.Replace(g[0], " " + g[1] + " ");
        StringBuilder sb = new StringBuilder();
        foreach (char c in t) sb.Append(char.IsLetterOrDigit(c) || c == '/' ? c : ' ');
        List<string> list = new List<string>();
        foreach (string w in sb.ToString().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)) list.Add(w.Trim('/'));
        list.RemoveAll(delegate(string w) { return w.Length == 0; });
        return list;
    }

    // слова названия из справочника - без типов ("аг. Боровляны" -> боровляны, "Заводская ул." -> заводская)
    public static string[] NameWords(string s) {
        List<string> list = new List<string>();
        foreach (string w in Words(s))
            if (Array.IndexOf(TownTypes, w) < 0 && Array.IndexOf(StreetTypes, w) < 0) list.Add(w);
        return list.ToArray();
    }

    public static List<AddrToken> Tokens(string query) {
        List<string> words = new List<string>();
        foreach (string w in Words(query)) {
            // слитно: "д18", "кв5", "к2"
            string marker = null;
            if (w.Length > 2 && w.StartsWith("кв") && char.IsDigit(w[2])) marker = "кв";
            else if (w.Length > 1 && (w[0] == 'д' || w[0] == 'к') && char.IsDigit(w[1])) marker = w.Substring(0, 1);
            if (marker != null) { words.Add(marker); words.Add(w.Substring(marker.Length)); }
            else words.Add(w);
        }
        List<AddrToken> toks = new List<AddrToken>();
        for (int i = 0; i < words.Count; i++) {
            string w = words[i];
            bool nextDigit = i + 1 < words.Count && char.IsDigit(words[i + 1][0]);
            AddrToken t = new AddrToken();
            t.Text = w;
            AddrToken prev = toks.Count > 0 ? toks[toks.Count - 1] : null;
            if (w == "дом" || (w == "д" && nextDigit)) t.Kind = 'h';
            else if ((w == "к" || w == "корп" || w == "корпус") && nextDigit) t.Kind = 'k';
            else if (w == "кв" || w == "квартира" || w == "квра") t.Kind = 'f';
            else if (w == "к") t.Kind = 'r';
            else if (Array.IndexOf(TownTypes, w) >= 0) t.Kind = 't';
            else if (Array.IndexOf(StreetTypes, w) >= 0) t.Kind = 's';
            else if (w == "сс" || w == "сельсовет") { t.Kind = 'r'; if (prev != null && prev.Kind == 'w' && !prev.Digit) prev.Ss = true; }
            else if (w == "рн" || w == "район" || w == "обл" || w == "область") { t.Kind = 'r'; if (prev != null && prev.Kind == 'w' && !prev.Digit) prev.Kind = 'r'; }
            else if (Array.IndexOf(Regions, w) >= 0) t.Kind = 'r';
            else t.Kind = 'w';
            if (t.Kind == 'w' && t.Digit && prev != null && (prev.Kind == 'h' || prev.Kind == 'k' || prev.Kind == 'f')) t.Bound = true;
            toks.Add(t);
        }
        return toks;
    }
}

// Адрес, узнанный по справочнику. Каждая указанная часть должна совпасть точно, не указанная - не ограничивает.
public class AddressMatch {
    public List<string> Codes = new List<string>();   // коды улиц, где искать
    public string House, Korp, Flat;
    public string Problem;          // почему искать нечего (null - всё понятно)
    public string Said = "";        // что поняли: "аг. Боровляны -> Заводская ул. -> дом 18" (для строки состояния)
    public string Explain = "";     // то же без названий - для отчёта

    // дом, корпус, квартира для сравнения: без пробелов и дефисов, маленькими буквами, без нулей впереди
    public static string Num(string s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        foreach (char c in s.ToLowerInvariant()) if (c != ' ' && c != '-' && c != '.' && c != ',') sb.Append(c);
        string r = sb.ToString();
        int z = 0;
        while (z < r.Length - 1 && r[z] == '0' && char.IsDigit(r[z + 1])) z++;
        return r.Substring(z);
    }
}

// Адрес, разобранный на части: слова (населённый пункт, улица), дом, корпус, квартира (для частичного совпадения)
public class AddressParts {
    public List<string> Words = new List<string>();
    public string House, Korp, Flat;
    public int Skipped;

    static readonly string[] Skip = {
        "ул", "улица", "пер", "переулок", "пр", "пр-т", "просп", "проспект", "пл", "площадь", "б-р", "бульвар",
        "ш", "шоссе", "туп", "тупик", "проезд", "мкр", "микрорайон", "наб", "набережная", "тракт",
        "г", "город", "аг", "агрогородок", "п", "пос", "поселок", "посёлок", "гп", "рп", "дер", "деревня",
        "с", "село", "х", "хутор", "с/с", "сс", "сельсовет", "р-н", "район", "обл", "область" };

    // "Острошицкий Городок Заводская ул. 18", "аг. Острошицкий Городок, ул. Заводская, д. 18, кв. 5", "заводская 18 5"
    public static AddressParts Parse(string query) {
        AddressParts a = new AddressParts();
        List<string> numbers = new List<string>();
        List<string> early = new List<string>();   // числа до названия: номер строки из списка или сам дом
        string pending = null;                     // "дом", "корп" или "кв" перед числом
        foreach (string raw in DbfTable.SplitWords(query.Replace('.', ' '))) {
            string w = raw;
            // слитно: "кв5", "д18", "к2"
            string marker = null;
            if (w.Length > 2 && w.StartsWith("кв") && IsDigitAt(w, 2)) { marker = "кв"; w = w.Substring(2); }
            else if (w.Length > 1 && (w[0] == 'д' || w[0] == 'к') && IsDigitAt(w, 1)) { marker = w[0] == 'д' ? "дом" : "корп"; w = w.Substring(1); }
            if (marker != null) pending = marker;

            if (w == "д" || w == "дом") { pending = "дом"; continue; }
            if (w == "к" || w == "корп" || w == "корпус") { pending = "корп"; continue; }
            if (w == "кв" || w == "квартира") { pending = "кв"; continue; }
            if (Array.IndexOf(Skip, w) >= 0) { pending = null; a.Skipped++; continue; }

            if (IsDigitAt(w, 0)) {
                if (IsDigits(w) && w.Length >= 5) { pending = null; a.Skipped++; continue; }   // лицевой или код - не адрес
                if (pending == "корп" && a.Korp == null) a.Korp = w;
                else if (pending == "кв" && a.Flat == null) a.Flat = w;
                else if (pending == "дом" && a.House == null) a.House = w;
                else if (a.Words.Count > 0) numbers.Add(w);
                else early.Add(w);
                pending = null;
                continue;
            }
            pending = null;
            if (HasDigit(w)) { a.Skipped++; continue; }
            a.Words.Add(w);
        }
        // числа до названия улицы - обычно номер строки из списка, их пропускаем;
        // но если слов нет совсем ("18"), это и есть дом
        if (a.Words.Count == 0) numbers.InsertRange(0, early);
        else a.Skipped += early.Count;
        // числа без пояснений: первое - дом, второе - квартира
        foreach (string n in numbers) {
            if (a.House == null) a.House = n;
            else if (a.Flat == null) a.Flat = n;
            else if (a.Korp == null) a.Korp = n;
        }
        return a;
    }

    static bool IsDigitAt(string s, int i) {
        return i < s.Length && s[i] >= '0' && s[i] <= '9';
    }

    static bool IsDigits(string s) {
        foreach (char c in s) if (c < '0' || c > '9') return false;
        return s.Length > 0;
    }

    static bool HasDigit(string s) {
        foreach (char c in s) if (c >= '0' && c <= '9') return true;
        return false;
    }
}

public class DbfViewer : Form {
    readonly string settingsFile;
    string folder;
    readonly TextBox folderBox = new TextBox();
    readonly ComboBox tableBox = new ComboBox();
    readonly CheckBox encodingBox = new CheckBox();
    internal readonly TextBox searchBox = new TextBox();
    readonly ComboBox fieldBox = new ComboBox();
    readonly DataGridView grid = new DataGridView();
    readonly Label status = new Label();
    readonly Timer searchTimer = new Timer();

    DbfTable table;
    object[] sortKeys;   // значения столбца сортировки, пока идёт сортировка
    readonly List<int> view = new List<int>();
    int sortColumn = -1;
    bool sortDescending;
    bool suspend;
    bool resizeColumns;
    bool loading;
    readonly FlowLayoutPanel bar1 = Bar();
    readonly FlowLayoutPanel bar2 = Bar();

    // больше стольки записей таблица целиком не показывается - только найденное
    const int ShowAllLimit = 5000;

    public static void Run(string settingsFile) {
        Application.EnableVisualStyles();
        Application.Run(new DbfViewer(settingsFile));
    }

    public DbfViewer(string settingsFile) {
        this.settingsFile = settingsFile;
        Font = Look.Base;
        Look.Wear(this);
        Text = "Просмотр базы (только чтение)";
        Size = new Size(1100, 700);
        StartPosition = FormStartPosition.CenterScreen;

        folderBox.Width = 420;
        folderBox.KeyDown += new KeyEventHandler(OnFolderKey);
        Button openButton = new Button();
        openButton.Text = "Открыть";
        openButton.AutoSize = true;
        openButton.Click += delegate { OpenTypedFolder(); };
        Button folderButton = new Button();
        folderButton.Text = "Обзор...";
        folderButton.AutoSize = true;
        folderButton.Click += delegate { ChooseFolder(); };
        bar1.Controls.AddRange(new Control[] { Caption("Папка:"), folderBox, openButton, folderButton });

        tableBox.DropDownStyle = ComboBoxStyle.DropDownList;
        tableBox.Width = 180;
        tableBox.SelectedIndexChanged += delegate { LoadSelected(); };
        Button reload = new Button();
        reload.Text = "Обновить";
        reload.AutoSize = true;
        reload.Click += delegate { LoadSelected(); };
        searchBox.Width = 260;
        searchBox.TextChanged += delegate { searchTimer.Stop(); searchTimer.Start(); };
        searchBox.KeyDown += new KeyEventHandler(OnSearchKey);
        fieldBox.DropDownStyle = ComboBoxStyle.DropDownList;
        fieldBox.Width = 140;
        fieldBox.SelectedIndexChanged += delegate { ApplyFilter(); };
        Button everywhere = new Button();
        everywhere.Text = "Во всех таблицах";
        everywhere.AutoSize = true;
        everywhere.Click += delegate { SearchAllTables(); };
        Button excel = new Button();
        excel.Text = "В Excel";
        excel.AutoSize = true;
        excel.Click += delegate { ExportToExcel(); };
        encodingBox.Text = "Другая кодировка";
        encodingBox.AutoSize = true;
        encodingBox.Margin = new Padding(12, 6, 3, 3);
        encodingBox.CheckedChanged += delegate { LoadSelected(); };
        bar2.Controls.AddRange(new Control[] {
            Caption("Таблица:"), tableBox, reload,
            Caption("Поиск:"), searchBox, everywhere, Caption("в поле:"), fieldBox, excel, encodingBox });

        grid.Dock = DockStyle.Fill;
        grid.VirtualMode = true;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        grid.CellValueNeeded += new DataGridViewCellValueEventHandler(OnCellValueNeeded);
        grid.ColumnHeaderMouseClick += new DataGridViewCellMouseEventHandler(OnHeaderClick);
        grid.CellDoubleClick += new DataGridViewCellEventHandler(OnCellDoubleClick);
        grid.KeyDown += new KeyEventHandler(OnGridKey);
        CopyText.Grid(grid);

        status.Dock = DockStyle.Bottom;
        status.Height = 22;
        status.TextAlign = ContentAlignment.MiddleLeft;

        searchTimer.Interval = 300;
        searchTimer.Tick += delegate { searchTimer.Stop(); ApplyFilter(); };

        Controls.Add(grid);
        Controls.Add(status);
        Controls.Add(bar2);
        Controls.Add(bar1);

        string lastTable = ReadSetting(1);
        Shown += delegate {
            Cursor = Cursors.WaitCursor;
            status.Text = "Ищу папку базы...";
            status.Refresh();
            folder = Places.FindFolder(ReadSetting(0));
            Cursor = Cursors.Default;
            FillTables(lastTable);
            searchBox.Focus();
        };
    }

    void OnFolderKey(object sender, KeyEventArgs e) {
        if (e.KeyCode != Keys.Enter) return;
        e.Handled = true;
        e.SuppressKeyPress = true;
        OpenTypedFolder();
    }

    void OpenTypedFolder() {
        string p = folderBox.Text.Trim();
        if (p.Length == 0) return;
        folder = p;
        SaveSettings();
        FillTables(null);
    }

    static FlowLayoutPanel Bar() {
        FlowLayoutPanel p = new FlowLayoutPanel();
        p.Dock = DockStyle.Top;
        p.AutoSize = true;
        p.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        p.Padding = new Padding(4, 4, 4, 0);
        return p;
    }

    static Label Caption(string text) {
        Label l = new Label();
        l.Text = text;
        l.AutoSize = true;
        l.Margin = new Padding(10, 8, 0, 3);
        return l;
    }

    void ChooseFolder() {
        FolderBrowserDialog d = new FolderBrowserDialog();
        d.Description = "Папка с таблицами базы (файлы .dbf)";
        if (folder != null && Directory.Exists(folder)) d.SelectedPath = folder;
        if (d.ShowDialog(this) != DialogResult.OK) return;
        folder = d.SelectedPath;
        SaveSettings();
        FillTables(null);
    }

    void FillTables(string select) {
        folderBox.Text = folder;
        suspend = true;
        tableBox.Items.Clear();
        suspend = false;
        string[] files = new string[0];
        try { files = Places.DbfFiles(folder); }
        catch (Exception ex) { Message("Не удалось открыть папку " + folder + "\n\n" + ex.Message + "\n\nПроверьте путь в поле \"Папка\" и нажмите \"Открыть\"."); }
        Array.Sort(files, StringComparer.OrdinalIgnoreCase);
        int index = -1;
        foreach (string f in files) {
            string name = Path.GetFileName(f);
            if (select != null && string.Compare(name, select, StringComparison.OrdinalIgnoreCase) == 0) index = tableBox.Items.Count;
            tableBox.Items.Add(name);
        }
        table = null;
        BuildColumns();
        if (files.Length == 0) status.Text = "В этой папке нет таблиц .dbf. Впишите другой путь или нажмите \"Обзор...\".";
        else if (index >= 0) tableBox.SelectedIndex = index;
        else status.Text = "Выберите таблицу в списке.";
    }

    void LoadSelected() {
        if (suspend || loading || tableBox.SelectedItem == null) return;
        string name = (string)tableBox.SelectedItem;
        table = null;
        BuildColumns();
        SetBusy(true);
        status.Text = "Загрузка " + name + "...";
        status.Refresh();
        try {
            table = DbfTable.Load(Path.Combine(folder, name), encodingBox.Checked, null, delegate(int done, int expected) {
                if (IsDisposed) throw new OperationCanceledException();
                status.Text = "Загрузка " + name + ": прочитано " + done + " из " + expected + " записей...";
                Application.DoEvents();
            });
        } catch (OperationCanceledException) {
            return;
        } catch (IOException ex) {
            table = null;
            Message("Не удалось открыть таблицу (возможно, она сейчас занята):\n" + ex.Message);
        } catch (Exception ex) {
            table = null;
            Message("Не удалось прочитать таблицу:\n" + ex.Message);
        } finally {
            if (!IsDisposed) SetBusy(false);
        }
        SaveSettings();
        BuildColumns();
        ApplyFilter();
        searchBox.Focus();
    }

    void SetBusy(bool busy) {
        loading = busy;
        bar1.Enabled = !busy;
        bar2.Enabled = !busy;
        grid.Enabled = !busy;
        Cursor = busy ? Cursors.WaitCursor : Cursors.Default;
    }

    void BuildColumns() {
        suspend = true;
        grid.RowCount = 0;
        grid.Columns.Clear();
        fieldBox.Items.Clear();
        fieldBox.Items.Add("все поля");
        fieldBox.SelectedIndex = 0;
        sortColumn = -1;
        view.Clear();
        if (table != null) {
            foreach (DbfField f in table.Fields) {
                DataGridViewTextBoxColumn c = new DataGridViewTextBoxColumn();
                c.HeaderText = f.Name;
                c.SortMode = DataGridViewColumnSortMode.Programmatic;
                if ("NFIBY".IndexOf(f.Type) >= 0) c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                grid.Columns.Add(c);
                fieldBox.Items.Add(f.Name);
            }
            resizeColumns = true;
        }
        suspend = false;
    }

    internal void ApplyFilter() {
        if (suspend || loading) return;
        view.Clear();
        if (table != null) {
            SearchWord[] words = table.PrepareWords(searchBox.Text);
            if (words.Length > 0 || table.Count <= ShowAllLimit) {
                int field = fieldBox.SelectedIndex - 1;   // -1 - искать во всех полях
                for (int i = 0; i < table.Count; i++) {
                    if (table.Matches(i, words, field)) view.Add(i);
                }
                SortView();
            }
        }
        grid.RowCount = 0;
        grid.RowCount = view.Count;
        grid.Invalidate();
        if (resizeColumns && grid.Columns.Count > 0 && view.Count > 0) {   // ширина - по первым найденным строкам
            resizeColumns = false;
            grid.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
            foreach (DataGridViewColumn c in grid.Columns) if (c.Width > 300) c.Width = 300;
        }
        UpdateStatus();
    }

    // Поиск по всем таблицам папки: таблицы читаются по очереди, в памяти остаются только совпадения
    internal void SearchAllTables() {
        string query = searchBox.Text.Trim();
        string[] words = DbfTable.SplitWords(query);
        if (words.Length == 0) {
            Message("Впишите в поле \"Поиск\", что искать: адрес, номер, фамилию...");
            searchBox.Focus();
            return;
        }
        if (tableBox.Items.Count == 0) {
            Message("В папке нет таблиц .dbf.");
            return;
        }
        searchTimer.Stop();
        ScanResults results = new ScanResults(this, query);
        results.Show(this);
        Enabled = false;
        try {
            int count = tableBox.Items.Count;
            for (int i = 0; i < count && !results.Cancelled; i++) {
                string name = (string)tableBox.Items[i];
                results.SetProgress("Проверяю " + name + " (" + (i + 1) + " из " + count + ")...");
                ScanTable(results, name, query);
            }
        } finally {
            Enabled = true;
            results.Finish();
        }
    }

    void ScanTable(ScanResults results, string name, string query) {
        try {
            DbfTable t = DbfTable.Load(Path.Combine(folder, name), encodingBox.Checked, query,
                delegate(int done, int expected) {
                    Application.DoEvents();
                    if (results.Cancelled || IsDisposed) throw new OperationCanceledException();
                });
            if (t.Count > 0) results.AddResult(name, t.Count, t.Total);
        } catch (OperationCanceledException) {
        } catch (Exception ex) {
            results.AddError(name, ex.Message);
        }
        Application.DoEvents();
    }

    // Открыть таблицу из результатов поиска сразу с тем же поиском
    internal void OpenTable(string name, string query) {
        int index = -1;
        for (int i = 0; i < tableBox.Items.Count; i++) {
            if (string.Compare((string)tableBox.Items[i], name, StringComparison.OrdinalIgnoreCase) == 0) { index = i; break; }
        }
        if (index < 0) return;
        searchBox.Text = query;
        searchTimer.Stop();
        if (tableBox.SelectedIndex == index) ApplyFilter();
        else tableBox.SelectedIndex = index;
        Activate();
    }

    void SortView() {
        if (sortColumn < 0 || table == null || sortColumn >= table.Fields.Count || view.Count < 2) return;
        sortKeys = new object[table.Count];
        foreach (int row in view) sortKeys[row] = table.GetValue(row, sortColumn, null);
        view.Sort(new Comparison<int>(CompareRows));
        sortKeys = null;
    }

    int CompareRows(int a, int b) {
        int r = DbfTable.CompareValues(sortKeys[a], sortKeys[b]);
        if (sortDescending) r = -r;
        return r != 0 ? r : a.CompareTo(b);
    }

    void UpdateStatus() {
        if (table == null) { status.Text = ""; return; }
        if (DbfTable.SplitWords(searchBox.Text).Length == 0 && table.Count > ShowAllLimit) {
            status.Text = "В таблице " + table.Count + " записей. Впишите в \"Поиск\" адрес, номер или фамилию - покажу только подходящие. Например: заводская 18";
            return;
        }
        status.Text = "Показано записей: " + view.Count + " из " + table.Count
            + (table.Deleted > 0 ? " (удалённые записи не показываются: " + table.Deleted + ")" : "")
            + ".   Двойной щелчок или Enter по строке - карточка целиком.";
    }

    void OnCellValueNeeded(object sender, DataGridViewCellValueEventArgs e) {
        if (table == null || e.RowIndex >= view.Count || e.ColumnIndex >= table.Fields.Count) return;
        e.Value = DbfTable.Format(table.GetValue(view[e.RowIndex], e.ColumnIndex, null), false);
    }

    void OnHeaderClick(object sender, DataGridViewCellMouseEventArgs e) {
        if (table == null || e.ColumnIndex < 0) return;
        if (e.ColumnIndex == sortColumn) {
            sortDescending = !sortDescending;
        } else {
            if (sortColumn >= 0 && sortColumn < grid.Columns.Count)
                grid.Columns[sortColumn].HeaderCell.SortGlyphDirection = SortOrder.None;
            sortColumn = e.ColumnIndex;
            sortDescending = false;
        }
        grid.Columns[sortColumn].HeaderCell.SortGlyphDirection = sortDescending ? SortOrder.Descending : SortOrder.Ascending;
        Cursor = Cursors.WaitCursor;
        SortView();
        Cursor = Cursors.Default;
        grid.Invalidate();
    }

    void OnCellDoubleClick(object sender, DataGridViewCellEventArgs e) {
        if (e.RowIndex >= 0) ShowCard(e.RowIndex);
    }

    void OnGridKey(object sender, KeyEventArgs e) {
        if (e.KeyCode == Keys.Enter && grid.CurrentCell != null) {
            e.Handled = true;
            e.SuppressKeyPress = true;
            ShowCard(grid.CurrentCell.RowIndex);
        }
    }

    void OnSearchKey(object sender, KeyEventArgs e) {
        if (e.KeyCode == Keys.Enter) {
            e.Handled = true;
            e.SuppressKeyPress = true;
            searchTimer.Stop();
            if (e.Control) SearchAllTables();   // Ctrl+Enter - искать во всех таблицах
            else ApplyFilter();
        } else if (e.KeyCode == Keys.Down && grid.RowCount > 0) {
            e.Handled = true;
            grid.Focus();
        }
    }

    internal void ShowCard(int viewRow) {
        if (table == null || viewRow < 0 || viewRow >= view.Count) return;
        Card.Show(this, table, view[viewRow]);
    }

    void ExportToExcel() {
        if (table == null || view.Count == 0) { Message("Нечего выгружать: таблица пуста или ничего не найдено."); return; }
        const int limit = 65000;
        if (view.Count > limit) {
            string q = "Найдено " + view.Count + " записей, в Excel будут выгружены первые " + limit
                + ".\nМожно сначала сузить список поиском. Продолжить?";
            if (MessageBox.Show(this, q, Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        }
        string name = Path.GetFileNameWithoutExtension(table.FilePath);
        string file = Path.Combine(Path.GetTempPath(), name + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xml");
        Cursor = Cursors.WaitCursor;
        try {
            DbfTable.WriteSpreadsheet(table, view, Math.Min(view.Count, limit), file);
        } catch (Exception ex) {
            Message("Не удалось сохранить файл для Excel:\n" + ex.Message);
            return;
        } finally {
            Cursor = Cursors.Default;
        }
        try {
            Process.Start("excel.exe", "\"" + file + "\"");
        } catch {
            try { Process.Start(file); }
            catch (Exception ex) { Message("Файл сохранён, но Excel не открылся сам:\n" + file + "\n\n" + ex.Message); }
        }
    }

    string ReadSetting(int line) {
        try {
            if (!File.Exists(settingsFile)) return null;
            string[] lines = File.ReadAllLines(settingsFile, Encoding.UTF8);
            return line < lines.Length && lines[line].Trim().Length > 0 ? lines[line].Trim() : null;
        } catch (Exception) {
            return null;
        }
    }

    void SaveSettings() {
        try {
            string current = tableBox.SelectedItem as string;
            File.WriteAllLines(settingsFile, new string[] { folder, current == null ? "" : current }, Encoding.UTF8);
        } catch (Exception) {
            // папка скрипта может быть только для чтения - тогда просто не запоминаем
        }
    }

    void Message(string text) {
        if (IsDisposed) return;
        MessageBox.Show(this, text, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}

// Окно с результатами поиска по всем таблицам: где и сколько нашлось
public class ScanResults : Form {
    readonly DbfViewer viewer;
    readonly string query;
    readonly ListView list = new ListView();
    readonly Label info = new Label();
    readonly Button stop = new Button();
    public bool Cancelled;
    bool scanning = true;
    int found;

    public ScanResults(DbfViewer viewer, string query) {
        this.viewer = viewer;
        this.query = query;
        Font = Look.Base;
        Look.Wear(this);
        Text = "Поиск во всех таблицах: " + query;
        Size = new Size(560, 500);
        StartPosition = FormStartPosition.CenterScreen;

        list.Dock = DockStyle.Fill;
        list.View = View.Details;
        list.FullRowSelect = true;
        list.HideSelection = false;
        list.MultiSelect = false;
        list.Columns.Add("Таблица", 180);
        list.Columns.Add("Найдено", 90, HorizontalAlignment.Right);
        list.Columns.Add("Всего записей", 260);
        list.ItemActivate += delegate { OpenSelected(); };

        Panel bottom = new Panel();
        bottom.Dock = DockStyle.Bottom;
        bottom.Height = 34;
        info.Dock = DockStyle.Fill;
        info.TextAlign = ContentAlignment.MiddleLeft;
        stop.Text = "Стоп";
        stop.Dock = DockStyle.Right;
        stop.Width = 90;
        stop.Click += delegate { Cancelled = true; };
        bottom.Controls.Add(info);
        bottom.Controls.Add(stop);

        Controls.Add(list);
        Controls.Add(bottom);
        FormClosing += delegate { Cancelled = true; };
    }

    public void SetProgress(string text) {
        if (IsDisposed) return;
        info.Text = text;
        info.Refresh();
    }

    public void AddResult(string table, int hits, int total) {
        if (IsDisposed) return;
        list.Items.Add(new ListViewItem(new string[] { table, hits.ToString(), total.ToString() }));
        found++;
    }

    public void AddError(string table, string error) {
        if (IsDisposed) return;
        ListViewItem item = new ListViewItem(new string[] { table, "не открылась", error });
        item.ForeColor = Look.Hint;
        item.Tag = "error";
        list.Items.Add(item);
    }

    public void Finish() {
        scanning = false;
        if (IsDisposed) return;
        stop.Enabled = false;
        info.Text = (Cancelled ? "Поиск остановлен. " : "Поиск закончен. ")
            + (found == 0 ? "Ничего не найдено." : "Таблиц с совпадениями: " + found + ". Двойной щелчок - открыть таблицу с найденным.");
    }

    void OpenSelected() {
        if (scanning) { info.Text = "Дождитесь конца поиска или нажмите \"Стоп\"."; return; }
        if (list.SelectedItems.Count == 0 || list.SelectedItems[0].Tag != null) return;
        viewer.OpenTable(list.SelectedItems[0].Text, query);
    }
}

// Подписи полей таблицы абонентов - как на карточке "АБОНЕНТ" в старой программе
public static class FieldNames {
    static Dictionary<string, string> names;

    public static Dictionary<string, string> Excel;      // режим Excel: поле копии -> заголовок выгрузки

    public static string Label(string field) {
        if (names == null) {
            names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string[] pairs = {
                "NAB", "№ абонента", "FIO", "Ф.И.О.", "UL", "Улица", "DOM", "Дом", "KOR", "Корпус", "KV", "Квартира",
                "TEL", "Телефон", "KNIGA", "№ книги", "LGI", "Код льготы", "SKID", "% скидки", "KTAR", "Код тарифа",
                "GIL", "Жильцов", "KLG", "Льготных жильцов", "TPO", "Тип помещения", "ROZ", "Розеток",
                "TOS", "Точек освещения", "NCH", "№ счётчика", "TIPCH", "Тип счётчика", "RAS", "Разрядность",
                "GODPR", "Год поверки", "KVP", "Квартал поверки", "DZA", "Дата замены счётчика",
                "PZS", "Показание при замене", "NSC", "№ снятого счётчика", "TSC", "Тип снятого счётчика",
                "NPOK", "Показание при установке", "DPR", "Дата проверки", "POK", "Показание", "PPR", "Пр. проверки",
                "OPOK", "Оплаченное показание", "PRA", "Признак архива", "DOT", "Дата отключения", "PRP", "Пр. пл.",
                "DUC", "Дата учёта без пр.", "DOK", "Дата окончания", "N_UCH", "№ участка", "N_F", "№ фидера",
                "LS_ERIP", "Л/С ЕРИП" };
            for (int i = 0; i + 1 < pairs.Length; i += 2) names[pairs[i]] = pairs[i + 1];
        }
        string label;
        if (names.TryGetValue(field, out label)) return label;
        if (Excel != null && Excel.TryGetValue(field, out label) && label.Length > 0) return label;
        return null;
    }

    public static string Title(string field) {
        string label = Label(field);
        return label == null ? field : label + " (" + field + ")";
    }
}

// Карточка записи: все поля целиком, с русскими подписями, где они известны
// Как перейти к соседнему абоненту из списка найденного (PgUp/PgDn в карточке): false - дальше некуда
public delegate bool CardMove(int delta, out SearchResult res, out int row);

// Справочник "код -> название" для карточки (тарифы, льготы, место установки счётчика):
// маленькая таблица базы, читается целиком один раз
public class CodeBook {
    readonly Dictionary<string, string> names = new Dictionary<string, string>();
    public string Note = "";
    static readonly Dictionary<string, CodeBook> cache = new Dictionary<string, CodeBook>(StringComparer.OrdinalIgnoreCase);

    public static CodeBook Get(string folder, string table, string[] keys) {
        string id = folder + "|" + table;
        CodeBook b;
        lock (cache) if (cache.TryGetValue(id, out b)) return b;
        b = new CodeBook();
        try { b.Load(folder, table, keys); }
        catch (Exception ex) { b.Note = "не прочитался: " + ex.Message; }
        Report.Line("Справочник для карточки " + table + ": " + b.Note);
        lock (cache) cache[id] = b;
        return b;
    }

    void Load(string folder, string table, string[] keys) {
        string path = null;
        foreach (string f in Directory.GetFiles(folder))
            if (string.Compare(Path.GetFileName(f), table, StringComparison.OrdinalIgnoreCase) == 0) path = f;
        if (path == null) { Note = "таблицы нет"; return; }
        DbfTable h = DbfTable.LoadHeader(path);
        if (h.Expected > 20000) { Note = "слишком большая (" + h.Expected + " записей)"; return; }
        int key = -1;
        foreach (string k in keys) if (key < 0) key = h.FieldIndex(k);
        for (int i = 0; i < h.Fields.Count && key < 0; i++) if (h.Fields[i].Type == 'N') key = i;
        // название - текстовое поле, лучше длинное и с "говорящим" именем (NAIM..., N...)
        int name = -1, best = 0;
        for (int i = 0; i < h.Fields.Count; i++) {
            DbfField f = h.Fields[i];
            if (i == key || f.Type != 'C') continue;
            string n = f.Name.ToUpperInvariant();
            int score = f.Length >= 10 ? 2 : 1;
            if (n.Contains("NAIM") || n.Contains("NAME") || n.StartsWith("N")) score += 2;
            if (score > best) { best = score; name = i; }
        }
        if (key < 0 || name < 0) { Note = "не понятно, где код и где название"; return; }
        DbfTable t = DbfTable.Load(path, null, null, 20000);
        for (int row = 0; row < t.Count; row++) {
            string k = Code(DbfTable.Format(t.GetValue(row, key, null), true));
            if (k.Length > 0 && !names.ContainsKey(k)) names[k] = DbfTable.Format(t.GetValue(row, name, null), true).Trim();
        }
        Note = "код - поле " + h.Fields[key].Name + ", название - поле " + h.Fields[name].Name + ", кодов " + names.Count;
    }

    static string Code(string s) {
        s = s.Trim();
        decimal d;
        if (decimal.TryParse(s.Replace(',', '.'), NumberStyles.Number, CultureInfo.InvariantCulture, out d))
            return d.ToString("0.##########", CultureInfo.InvariantCulture);
        return s.ToUpperInvariant();
    }

    public string Name(string code) {
        string s;
        return names.TryGetValue(Code(code), out s) ? s : "";
    }
}

// Карточка абонента как в программе базы: те же надписи и поля на тех же местах (экран в 80 знаков).
// Ctrl+D - доп. сведения, F2 - все поля списком, PgUp/PgDn - соседний абонент из списка, Esc - закрыть.
public class BaseCard : Form {
    public static readonly Color Back = Color.FromArgb(0, 0, 160);
    static readonly Color LabelColor = Color.White;
    static readonly Color BoxColor = Color.FromArgb(0, 128, 168);
    static readonly Color TitleColor = Color.FromArgb(255, 255, 85);
    static readonly Color MarkColor = Color.FromArgb(255, 130, 130);
    const int Cols = 80;

    // Экран "АБОНЕНТ" из программы базы. {ПОЛЕ,ширина} - значение поля, {#...} - из справочников,
    // {@N} - с колонки N, {-} - черта. Надпись перед полем показывается, только если поле есть в таблице.
    static readonly string[] MainScreen = {
        "№ Абонента:{NAB,10}{@35}{#T1,6}{@43}{#T2,6}{@51}{#T3,6}",
        "Ф.И.О.:{FIO,71}",
        "Н.П.:{#NP,32}{@44}{#TNP,4}{@50}с/с:{#SS,24}",
        "Код:{UL,5} Ул.:{#ULN,32}{@59}Л\\С:{LS_ERIP,14}",
        "Дом:{DOM,7}{@14}Кор.:{KOR,3}{@24}Кв.:{KV,5}{@34}Тел.:{TEL,7}{@50}№ Книги:{KNIGA,4}",
        " Код лг.:{LGI,3} Наимен.:{#LGN,30}{@57}% Ск.:{SKID,3}",
        " Код тар.:{KTAR,2} {#TARN,34}{@58}Жил.:{GIL,3} Лг.Жил.:{KLG,3}",
        " Тип пом.:{TPO,3} Розеток:{ROZ,3} Точек осв.:{TOS,3}",
        "{-}",
        "Сч.:{NCH,20}{@28}{TIPCH,30}{@60}Разр.:{RAS,1} Г.пов.:{GODPR,4}",
        "Кв.пов.:{KVP,2}",
        "{@26}Место уст.ПУ:{#MESTO,30}",
        "Пок.уст.:{NPOK,8} Д.пр.:{DPR,10} Пок.:{POK,8} Пр.пров.:{PPR,3} Опл.:{OPOK,8}",
        "{-}",
        "Дата зам.:{DZA,10} Пок.зам.сч.:{PZS,8} № Сч.:{NSC,20}",
        "{@43}Тип:{TSC,30}",
        "Пр.архива:{PRA,3} Дата откл.:{DOT,10} Пр.пл.:{PRP,5}{@62}№ уч-ка:{N_UCH,4}",
        "Дата уч.без пр.:{DUC,10} Дата оконч.:{DOK,10} № Фидера:{N_F,15}",
        "{-}",
        "Мощность:{#POWER,8}",
    };

    // экран "ДОПОЛНИТЕЛЬНЫЕ СВЕДЕНИЯ" (Ctrl+D): сверху - абонент, ниже - поля таблиц DOP и DOGOVOR
    static readonly string[] ExtraTop = { "№ Абонента:{NAB,10}", "Ф.И.О.:{FIO,71}" };

    class CardValue {
        public string Text = "";
        public bool Right, Mark;
    }

    SearchResult res;
    int row;
    object[] values;
    List<ExtraRecord> extra;
    Dictionary<int, bool> used = new Dictionary<int, bool>();
    bool extraPage;
    readonly LiveBase live;
    readonly CardMove move;
    readonly ScreenPanel screen;
    readonly Button prevButton, nextButton, extraButton, closeButton;
    readonly FlowLayoutPanel bar;

    public BaseCard(SearchResult r, int row, LiveBase live, CardMove move) {
        this.live = live;
        this.move = move;
        Text = "Карточка абонента";
        BackColor = Back;
        StartPosition = FormStartPosition.CenterScreen;
        KeyPreview = true;
        MinimizeBox = false;
        screen = new ScreenPanel(PickFont(11f));
        screen.Dock = DockStyle.Fill;
        bar = new FlowLayoutPanel();
        bar.Dock = DockStyle.Bottom;
        bar.Height = 36;
        bar.WrapContents = false;
        bar.Padding = new Padding(4, 4, 4, 0);
        bar.BackColor = Look.Back;
        prevButton = AddButton("< Пред. (PgUp)", delegate { Step(-1); });
        nextButton = AddButton("След. (PgDn) >", delegate { Step(1); });
        extraButton = AddButton("Доп. сведения (Ctrl+D)", delegate { ToggleExtra(); });
        AddButton("Все поля (F2)", delegate { ResultColumns.ShowList(this, res, this.row, live == null ? null : live.Extra); });
        bool excel = live != null && live.Mem != null;      // режим Excel-выгрузки: оплат и обходов нет
        if (!excel) AddButton("Оплаты (F6)", delegate { ShowOplaty(); });
        AddButton("Наряды (Ctrl+Z)", delegate { ShowNaryady(); });
        if (!excel) AddButton("Обходы (Ctrl+O)", delegate { ShowObhody(); });
        closeButton = AddButton("Закрыть (Esc)", delegate { Close(); });
        prevButton.Enabled = nextButton.Enabled = move != null;
        Controls.Add(bar);
        Controls.Add(screen);
        screen.BringToFront();
        FormClosed += delegate { screen.CellFont.Dispose(); };
        Open(r, row);
    }

    Button AddButton(string text, EventHandler click) {
        Button b = new Button();
        b.Text = text;
        b.AutoSize = true;
        b.Font = Look.Base;
        Look.Button(b);           // кнопки под синим окном - как в остальных окнах программы
        b.Click += click;
        bar.Controls.Add(b);
        return b;
    }

    static Font PickFont(float size) {
        foreach (string name in new string[] { "Consolas", "Lucida Console", "Courier New" }) {
            Font f = new Font(name, size);
            if (string.Compare(f.Name, name, StringComparison.OrdinalIgnoreCase) == 0) return f;
            f.Dispose();
        }
        return new Font(FontFamily.GenericMonospace, size);
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
        switch (keyData) {
            case Keys.Escape: if (extraPage) ToggleExtra(); else Close(); return true;
            case Keys.Control | Keys.D: ToggleExtra(); return true;
            case Keys.F2: ResultColumns.ShowList(this, res, row, live == null ? null : live.Extra); return true;
            case Keys.F6: ShowOplaty(); return true;
            case Keys.Control | Keys.Z: ShowNaryady(); return true;
            case Keys.Control | Keys.O: ShowObhody(); return true;
            case Keys.PageUp: Step(-1); return true;
            case Keys.PageDown: Step(1); return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    // как в программе базы: Ctrl+Z - наряды лицевого, Ctrl+O - обходы (таблицы - в папке базы, только чтение)
    internal Form LastWindow;

    string Who() {
        string adr = Field("UL").Length > 0 && res.Table.FieldIndex("UL") >= 0 ? ResultColumns.Text(res, row, res.Table.FieldIndex("UL")).Trim() : "";
        string dom = Field("DOM"), kor = Field("KOR"), kv = Field("KV");
        adr = (adr + " " + dom + (kor.Length > 0 || kv.Length > 0 ? "/" + kor + (kv.Length > 0 ? "/" + kv : "") : "")).Trim();
        return (Field("FIO") + (adr.Length > 0 ? "  >" + adr : "")).Trim();
    }

    internal void ShowNaryady() {
        if (live != null && live.Mem != null) { MessageBox.Show(this, (Istochnik.Missing("нарядов", Istochnik.NaryadyPath) ?? "Наряды из выгрузки нарядов подключим, когда будет образец выгрузки."), Text); return; }
        if (live == null || Field("NAB").Length == 0) { System.Media.SystemSounds.Beep.Play(); return; }
        LastWindow = new NaryadLsForm(Path.GetDirectoryName(live.FilePath), Field("NAB"), Who());
        LastWindow.Show(this);
    }

    // F6 - оплаты лицевого (за текущий год, стрелки вверх / вниз - другой год)
    internal void ShowOplaty() {
        if (live != null && live.Mem != null) { MessageBox.Show(this, "В Excel-выгрузке быта оплат и обходов нет.", Text); return; }
        if (live == null || Field("NAB").Length == 0) { System.Media.SystemSounds.Beep.Play(); return; }
        LastWindow = new OplataForm(Path.GetDirectoryName(live.FilePath), Field("NAB"), Who());
        LastWindow.Show(this);
    }

    internal void ShowObhody() {
        if (live != null && live.Mem != null) { MessageBox.Show(this, "В Excel-выгрузке быта оплат и обходов нет.", Text); return; }
        if (live == null || Field("NAB").Length == 0) { System.Media.SystemSounds.Beep.Play(); return; }
        LastWindow = new ObhodForm(Path.GetDirectoryName(live.FilePath), Field("NAB"), Who());
        LastWindow.Show(this);
    }

    public void Step(int delta) {
        SearchResult r;
        int rw;
        if (move != null && move(delta, out r, out rw)) Open(r, rw);
        else System.Media.SystemSounds.Beep.Play();
    }

    public void ToggleExtra() {
        extraPage = !extraPage;
        Build();
    }

    void Open(SearchResult r, int rw) {
        res = r;
        row = rw;
        using (MemoReader memo = r.Table.OpenMemo()) values = r.Table.GetRow(rw, memo);
        extra = null;
        Build();
    }

    void Build() {
        screen.Begin(extraPage ? "ДОПОЛНИТЕЛЬНЫЕ СВЕДЕНИЯ" : "АБОНЕНТ");
        used = new Dictionary<int, bool>();
        if (extraPage) BuildExtra(); else BuildMain();
        screen.End();
        extraButton.Text = extraPage ? "Карточка (Ctrl+D)" : "Доп. сведения (Ctrl+D)";
        Text = "Абонент " + Field("NAB") + (extraPage ? " - доп. сведения" : "") + " (только просмотр)";
        if (WindowState == FormWindowState.Normal) {
            Size content = screen.ContentSize;
            Rectangle area = Screen.FromControl(this).WorkingArea;
            // кнопки внизу - все видны: окно шире экрана карточки, а на узком экране - в два ряда
            bar.WrapContents = false;
            int need = bar.GetPreferredSize(Size.Empty).Width;
            int w = Math.Min(Math.Max(content.Width + SystemInformation.VerticalScrollBarWidth, need), area.Width - 40);
            bar.WrapContents = need > w;
            bar.Height = need > w ? 68 : 36;
            int h = Math.Min(content.Height + bar.Height, area.Height - 60);
            if (h == content.Height + bar.Height) w = Math.Min(Math.Max(content.Width, need), area.Width - 40);
            ClientSize = new Size(w, h);
        }
        ActiveControl = closeButton;
    }

    void BuildMain() {
        int r = 0;
        bool line = false;
        foreach (string t in MainScreen) {
            if (t == "{-}") { line = r > 0; continue; }
            int at = line ? r + 1 : r;
            if (!Template(t, at)) continue;
            if (line) screen.Line(r, null);
            r = at + 1;
            line = false;
        }
        // поля таблицы, которых нет на экране базы
        List<int> rest = new List<int>();
        for (int j = 0; j < values.Length; j++) if (!used.ContainsKey(j)) rest.Add(j);
        if (rest.Count > 0) r = Flow(r, res.Table, values, rest);
        List<string> notes = Notes();
        if (notes.Count > 0) {
            screen.Line(r++, null);
            foreach (string n in notes) screen.Label(r++, 0, n, TitleColor);
        }
    }

    void BuildExtra() {
        int r = 0;
        foreach (string t in ExtraTop) if (Template(t, r)) r++;
        ExtraInfo x = live == null ? null : live.Extra;
        if (x == null || x.Tables.Count == 0) {
            screen.Line(r++, null);
            screen.Label(r++, 0, "Таблиц доп. сведений (DOP.DBF, DOGOVOR.DBF) рядом с базой нет", LabelColor);
            return;
        }
        if (extra == null) {
            Cursor old = Cursor.Current;
            Cursor.Current = Cursors.WaitCursor;
            try { extra = x.Records(Field("NAB")); }
            catch (Exception ex) {
                extra = new List<ExtraRecord>();
                ExtraRecord e = new ExtraRecord();
                e.Name = "Доп. сведения";
                e.Problem = "не прочитались: " + ex.Message;
                extra.Add(e);
            }
            finally { Cursor.Current = old; }
        }
        foreach (ExtraRecord e in extra) {
            screen.Line(r++, Path.GetFileNameWithoutExtension(e.Name).ToUpperInvariant());
            if (e.Problem != null) { screen.Label(r++, 0, e.Problem, LabelColor); continue; }
            List<int> fields = new List<int>();
            for (int j = 0; j < e.Values.Length; j++)
                if (string.Compare(e.Table.Fields[j].Name, "NAB", StringComparison.OrdinalIgnoreCase) != 0) fields.Add(j);
            r = Flow(r, e.Table, e.Values, fields);
        }
    }

    List<string> Notes() {
        List<string> l = new List<string>();
        string why;
        if (res.Related.TryGetValue(row, out why)) l.Add("Добавлен к найденному: " + why);
        else if (res.Added.ContainsKey(row)) l.Add("Добавлен к найденному: другой тариф того же счётчика");
        if (!res.Related.ContainsKey(row) && res.Orange.ContainsKey(row)) l.Add("Оранжевым: на адресе больше одного счётчика");
        int t;
        if (res.Tariff.TryGetValue(row, out t)) l.Add("Тариф T" + t + ": у счётчика несколько лицевых (таблица ABDIF_T)");
        return l;
    }

    // одна строка экрана по шаблону; false - на ней ничего не оказалось (полей нет в таблице)
    bool Template(string line, int r) {
        bool placed = false;
        int col = 0, textCol = 0, i = 0;
        StringBuilder text = new StringBuilder();
        while (i < line.Length) {
            if (line[i] != '{') {
                if (text.Length == 0) textCol = col;
                text.Append(line[i]);
                col++;
                i++;
                continue;
            }
            int end = line.IndexOf('}', i);
            string tok = line.Substring(i + 1, end - i - 1);
            i = end + 1;
            string label = text.ToString().TrimEnd();
            text.Length = 0;
            if (tok[0] == '@') {
                if (label.Trim().Length > 0) { screen.Label(r, textCol, label, LabelColor); placed = true; }
                col = int.Parse(tok.Substring(1));
                continue;
            }
            int comma = tok.IndexOf(',');
            int w = int.Parse(tok.Substring(comma + 1));
            CardValue v = Resolve(tok.Substring(0, comma));
            if (v != null) {
                if (label.Trim().Length > 0) screen.Label(r, textCol, label, LabelColor);
                screen.Box(r, col, w, v.Text, v.Right, v.Mark);
                placed = true;
            }
            col += w;
        }
        if (text.ToString().Trim().Length > 0) { screen.Label(r, textCol, text.ToString().TrimEnd(), LabelColor); placed = true; }
        return placed;
    }

    // поля одно за другим, по строкам ("Надпись:[значение]")
    int Flow(int r, DbfTable t, object[] vals, List<int> fields) {
        int col = 0;
        foreach (int j in fields) {
            DbfField f = t.Fields[j];
            string label = (FieldNames.Label(f.Name) ?? f.Name) + ":";
            CardValue v = FieldValue(f, vals[j]);
            int w = BoxWidth(f);
            if (label.Length + w > Cols) w = Cols - label.Length;
            if (col > 0 && col + label.Length + w > Cols) { r++; col = 0; }
            screen.Label(r, col, label, LabelColor);
            screen.Box(r, col + label.Length, w, v.Text, v.Right);
            col += label.Length + w + 2;
        }
        return col > 0 ? r + 1 : r;
    }

    static int BoxWidth(DbfField f) {
        switch (f.Type) {
            case 'D': return 10;
            case 'T': return 19;
            case 'L': return 3;
            case 'M': case 'G': return Cols;
            case 'C': return Math.Max(1, Math.Min(f.Length, 60));
            default: return Math.Max(1, f.Length);
        }
    }

    CardValue Resolve(string key) {
        if (key[0] == '#') return Computed(key.Substring(1));
        int i = res.Table.FieldIndex(key);
        if (i < 0) return null;
        used[i] = true;
        return FieldValue(res.Table.Fields[i], values[i]);
    }

    static CardValue FieldValue(DbfField f, object v) {
        CardValue c = new CardValue();
        c.Right = f.Type == 'N' || f.Type == 'F' || f.Type == 'I' || f.Type == 'Y' || f.Type == 'B';
        if (v is bool) c.Text = (bool)v ? "да" : "нет";
        else c.Text = DbfTable.Format(v, true).Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Trim();
        return c;
    }

    string Field(string name) {
        int i = res.Table.FieldIndex(name);
        return i < 0 ? "" : DbfTable.Format(values[i], true).Trim();
    }

    static CardValue Plain(string text) {
        CardValue c = new CardValue();
        c.Text = text ?? "";
        return c;
    }

    CardValue Computed(string key) {
        StreetDirectory dir = live == null ? null : live.Dir;
        string ul = Field("UL");
        switch (key) {
            case "T1": case "T2": case "T3": {
                int t;
                res.Tariff.TryGetValue(row, out t);
                CardValue c = Plain((t == key[1] - '0' ? "(•) " : "( ) ") + key);
                c.Mark = true;
                return c;
            }
            case "NP": case "TNP": case "SS": case "ULN": {
                if (res.Table.FieldIndex("UL") < 0) return null;
                if (dir == null) return Plain("");
                if (key == "SS") return Plain(dir.Selsovet(ul));
                if (key == "ULN") return Plain(dir.Street(ul));
                string town = dir.Town(ul) ?? "", type = "", name = town;
                int sp = town.IndexOf(' ');
                if (sp > 0 && town[sp - 1] == '.') { type = town.Substring(0, sp); name = town.Substring(sp + 1); }
                return Plain(key == "NP" ? name : type);
            }
            case "LGN": return Lookup("LGI", "SPRLGOT.DBF", new string[] { "LGI", "KODLG", "KOD", "KLG", "KL" });
            case "TARN": return Lookup("KTAR", "SPRTAR.DBF", new string[] { "KTAR", "KOD", "KT" });
            case "MESTO": return Lookup("IDTPSCH", "TPSCH.DBF", new string[] { "IDTPSCH", "ID", "KOD" });
            case "POWER": {
                ExtraInfo x = live == null ? null : live.Extra;
                if (x == null || x.PowerBase == null) return null;
                string p = res.PowerText(row);
                if (p.Length == 0)
                    try {
                        Dictionary<string, string> d = x.Power(new List<string>(new string[] { Field("NAB") }));
                        if (!d.TryGetValue(ExtraInfo.Nab(Field("NAB")), out p)) p = "";
                    } catch (Exception) { p = ""; }
                CardValue c = Plain(p);
                c.Right = true;
                return c;
            }
        }
        return null;
    }

    // название по коду из справочника базы; не нашлось - пусто (а поле с кодом показывается среди прочих)
    CardValue Lookup(string field, string table, string[] keys) {
        int i = res.Table.FieldIndex(field);
        if (i < 0) return null;
        string code = Field(field);
        if (code.Length == 0 || live == null) return Plain("");
        string name = CodeBook.Get(Path.GetDirectoryName(live.FilePath), table, keys).Name(code);
        if (name.Length > 0) used[i] = true;
        return Plain(name);
    }

    // Экран в знакоместах: надписи рисуются, значения - поля только для чтения (можно выделить и скопировать)
    class ScreenPanel : Panel {
        public readonly Font CellFont;
        readonly float charW;
        readonly int lineH;
        string title = "";
        int rows;
        readonly List<KeyValuePair<Point, KeyValuePair<string, Color>>> texts = new List<KeyValuePair<Point, KeyValuePair<string, Color>>>();
        readonly List<KeyValuePair<int, string>> lines = new List<KeyValuePair<int, string>>();
        // значения полей (для «Копировать всю карточку»)
        readonly List<KeyValuePair<Point, string>> boxes = new List<KeyValuePair<Point, string>>();
        const int Edge = 2;

        public ScreenPanel(Font font) {
            CellFont = font;
            DoubleBuffered = true;
            ResizeRedraw = true;
            AutoScroll = true;
            BackColor = Back;
            charW = TextRenderer.MeasureText(new string('Ж', 40), font, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding).Width / 40f;
            lineH = font.Height + 7;
        }

        int X(int col) { return (int)Math.Round((Edge + col) * charW); }
        int Y(int row) { return lineH + lineH / 2 + row * lineH; }

        public Size ContentSize { get { return new Size(X(Cols + Edge), Y(rows) + lineH); } }

        public void Begin(string caption) {
            SuspendLayout();
            AutoScrollPosition = new Point(0, 0);
            while (Controls.Count > 0) { Control c = Controls[0]; Controls.RemoveAt(0); c.Dispose(); }
            texts.Clear();
            lines.Clear();
            boxes.Clear();
            rows = 0;
            title = caption;
            if (ContextMenuStrip == null) {
                ContextMenuStrip = new ContextMenuStrip();
                ToolStripMenuItem all = new ToolStripMenuItem("Копировать всю карточку");
                all.Click += delegate { CopyText.Put(AllText()); };
                ContextMenuStrip.Items.Add(all);
            }
        }

        public void End() {
            AutoScrollMinSize = ContentSize;
            ResumeLayout();
            Invalidate();
        }

        public void Label(int row, int col, string text, Color color) {
            texts.Add(new KeyValuePair<Point, KeyValuePair<string, Color>>(new Point(col, row), new KeyValuePair<string, Color>(text, color)));
            rows = Math.Max(rows, row + 1);
        }

        public void Line(int row, string caption) {
            lines.Add(new KeyValuePair<int, string>(row, caption));
            rows = Math.Max(rows, row + 1);
        }

        public void Box(int row, int col, int width, string value, bool right) { Box(row, col, width, value, right, false); }

        // значение поля: щелчок выделяет его целиком (протянуть мышью - часть), Ctrl+C копирует выделенное, ничего не выделено -
        // всё поле; правая кнопка - «Копировать «значение»» / «Копировать всю карточку». Красные (mark) - тоже выделяются
        public void Box(int row, int col, int width, string value, bool right, bool mark) {
            TextBox b = new TextBox();
            b.ReadOnly = true;
            b.BorderStyle = BorderStyle.None;
            b.BackColor = mark ? Back : BoxColor;
            b.ForeColor = mark ? MarkColor : Color.White;
            b.Font = CellFont;
            b.Text = value;
            b.MouseUp += delegate(object s, MouseEventArgs e) { if (e.Button == MouseButtons.Left && b.SelectionLength == 0) b.SelectAll(); };
            b.KeyDown += delegate(object s, KeyEventArgs e) {
                if (e.Control && (e.KeyCode == Keys.C || e.KeyCode == Keys.Insert)) {
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    CopyText.Put(b.SelectionLength > 0 ? b.SelectedText.Trim() : b.Text.Trim());
                }
            };
            ContextMenuStrip m = new ContextMenuStrip();
            string shown = value.Trim().Length > 40 ? value.Trim().Substring(0, 40) + "…" : value.Trim();
            ToolStripMenuItem one = new ToolStripMenuItem(shown.Length > 0 ? "Копировать «" + shown + "»" : "Копировать значение");
            one.Enabled = shown.Length > 0;
            one.Click += delegate { CopyText.Put(b.SelectionLength > 0 && b.SelectionLength < b.TextLength ? b.SelectedText.Trim() : b.Text.Trim()); };
            ToolStripMenuItem all = new ToolStripMenuItem("Копировать всю карточку");
            all.Click += delegate { CopyText.Put(AllText()); };
            m.Items.Add(one);
            m.Items.Add(all);
            m.Opening += delegate { b.Focus(); if (b.SelectionLength == 0) b.SelectAll(); };
            b.ContextMenuStrip = m;
            boxes.Add(new KeyValuePair<Point, string>(new Point(col, row), value));
            b.TextAlign = right ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            b.Width = (int)Math.Ceiling(width * charW) + 3;
            b.Location = new Point(X(col) - 1, Y(row) + (lineH - b.Height) / 2);
            Controls.Add(b);
            rows = Math.Max(rows, row + 1);
        }

        // вся карточка текстом: строка экрана - строка текста (надписи и значения на своих местах), черта - «-----»
        public string AllText() {
            List<char[]> rowsText = new List<char[]>();
            for (int i = 0; i < rows; i++) { char[] c = new char[Cols + 40]; for (int k = 0; k < c.Length; k++) c[k] = ' '; rowsText.Add(c); }
            foreach (KeyValuePair<Point, KeyValuePair<string, Color>> t in texts) Put(rowsText, t.Key.Y, t.Key.X, t.Value.Key);
            foreach (KeyValuePair<Point, string> b in boxes) Put(rowsText, b.Key.Y, b.Key.X, b.Value);
            foreach (KeyValuePair<int, string> l in lines) {
                string bar = new string('-', Cols);
                if (l.Value != null) { string cap = " " + l.Value + " "; int at = Math.Max(0, (Cols - cap.Length) / 2); bar = bar.Substring(0, at) + cap + bar.Substring(Math.Min(Cols, at + cap.Length)); }
                Put(rowsText, l.Key, 0, bar);
            }
            StringBuilder sb = new StringBuilder();
            if (title.Length > 0) sb.Append(title).Append("\r\n");
            foreach (char[] c in rowsText) sb.Append(new string(c).TrimEnd()).Append("\r\n");
            return sb.ToString().TrimEnd();
        }

        static void Put(List<char[]> rowsText, int row, int col, string text) {
            if (row < 0 || row >= rowsText.Count || text == null) return;
            char[] c = rowsText[row];
            for (int k = 0; k < text.Length && col + k < c.Length; k++) if (col + k >= 0) c[col + k] = text[k];
        }

        protected override void OnScroll(ScrollEventArgs se) {
            base.OnScroll(se);
            Invalidate();
        }

        protected override void OnMouseWheel(MouseEventArgs e) {
            base.OnMouseWheel(e);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e) {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            int dx = AutoScrollPosition.X, dy = AutoScrollPosition.Y;
            Size size = ContentSize;
            using (Pen pen = new Pen(Color.FromArgb(220, 220, 220))) {
                Rectangle frame = new Rectangle(dx + (int)(charW * 0.7f), dy + lineH / 2, size.Width - (int)(charW * 1.4f), size.Height - lineH / 2 - lineH / 3);
                g.DrawRectangle(pen, frame);
                frame.Inflate(-3, -3);
                g.DrawRectangle(pen, frame);
                foreach (KeyValuePair<int, string> l in lines) {
                    int y = dy + Y(l.Key) + lineH / 2;
                    g.DrawLine(pen, dx + X(0), y, dx + X(Cols), y);
                    if (l.Value != null) Caption(g, " " + l.Value + " ", dx + size.Width / 2, y);
                }
            }
            Caption(g, " " + title + " ", dx + size.Width / 2, dy + lineH / 2);
            int pad = (lineH - CellFont.Height) / 2;
            foreach (KeyValuePair<Point, KeyValuePair<string, Color>> t in texts)
                TextRenderer.DrawText(g, t.Value.Key, CellFont, new Point(dx + X(t.Key.X), dy + Y(t.Key.Y) + pad), t.Value.Value, TextFormatFlags.NoPadding);
        }

        void Caption(Graphics g, string text, int centerX, int centerY) {
            Size s = TextRenderer.MeasureText(text, CellFont, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);
            Rectangle r = new Rectangle(centerX - s.Width / 2, centerY - s.Height / 2, s.Width, s.Height);
            using (SolidBrush b = new SolidBrush(Back)) g.FillRectangle(b, r);
            TextRenderer.DrawText(g, text, CellFont, r.Location, TitleColor, TextFormatFlags.NoPadding);
        }
    }
}

public static class Card {
    public static void Show(IWin32Window owner, DbfTable table, int row) {
        Show(owner, table, row, null);
    }

    // extra - пары "подпись, значение", показываются первыми
    public static void Show(IWin32Window owner, DbfTable table, int row, string[] extra) {
        Show(owner, table, row, extra, null);
    }

    // after - пары, которые показываются после полей записи (доп. сведения из других таблиц)
    public static void Show(IWin32Window owner, DbfTable table, int row, string[] extra, List<string> after) {
        object[] values;
        using (MemoReader memo = table.OpenMemo()) values = table.GetRow(row, memo);
        Form card = new Form();
        card.Font = Look.Base;
        Look.Wear(card);
        card.Text = "Карточка - " + Path.GetFileName(table.FilePath);
        card.Size = new Size(650, 650);
        card.StartPosition = FormStartPosition.CenterScreen;
        DataGridView g = new DataGridView();
        g.Dock = DockStyle.Fill;
        g.ReadOnly = true;
        g.AllowUserToAddRows = false;
        g.AllowUserToDeleteRows = false;
        g.RowHeadersVisible = false;
        g.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        g.ColumnCount = 2;
        g.Columns[0].HeaderText = "Поле";
        g.Columns[1].HeaderText = "Значение";
        g.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        g.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        g.Columns[1].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        g.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
        CopyText.Grid(g);
        if (extra != null)
            for (int i = 0; i + 1 < extra.Length; i += 2) g.Rows.Add(extra[i], extra[i + 1]);
        for (int j = 0; j < values.Length; j++)
            g.Rows.Add(FieldNames.Title(table.Fields[j].Name), DbfTable.Format(values[j], true));
        if (after != null)
            for (int i = 0; i + 1 < after.Count; i += 2) {
                int r = g.Rows.Add(after[i], after[i + 1]);
                if (after[i].StartsWith("---")) {
                    g.Rows[r].DefaultCellStyle.BackColor = Look.Header;
                    g.Rows[r].DefaultCellStyle.Font = new Font(g.Font, FontStyle.Bold);
                }
            }
        card.Controls.Add(g);
        card.Show(owner);
    }
}

public static class Places {
    public const string Network = @"\\fs-dos\communal\BASAFOX";

    // Батник базы подключает \\fs-dos\communal как диск O:, но только пока база запущена,
    // поэтому пробуем и диск, и прямой сетевой путь
    public static string FindFolder(string saved) {
        string[] candidates = { saved, @"O:\BASAFOX", Network };
        foreach (string c in candidates) {
            try { if (c != null && Directory.Exists(c)) return c; }
            catch (Exception) { }
        }
        return saved != null ? saved : Network;
    }

    public static string[] DbfFiles(string folder) {
        List<string> list = new List<string>();
        foreach (string f in Directory.GetFiles(folder))
            if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) == 0) list.Add(f);
        string[] files = list.ToArray();
        Array.Sort(files, StringComparer.OrdinalIgnoreCase);
        return files;
    }

    public static string ReadSetting(string file, int line) {
        try {
            if (!File.Exists(file)) return null;
            string[] lines = File.ReadAllLines(file, Encoding.UTF8);
            return line < lines.Length && lines[line].Trim().Length > 0 ? lines[line].Trim() : null;
        } catch (Exception) {
            return null;
        }
    }

    public static void SaveSettings(string file, string[] lines) {
        try { File.WriteAllLines(file, lines, Encoding.UTF8); }
        catch (Exception) { }   // папка может быть только для чтения - тогда просто не запоминаем
    }
}

public class TableInfo {
    public string Name;
    public int Records;
    public bool Abonents;

    public override string ToString() {
        return Name + "   (" + Records + " записей)";
    }

    // Таблицы папки, похожие на таблицу абонентов - первыми; архивы (ARC...) - после основных
    public static List<TableInfo> List(string folder, LoadProgress progress) {
        List<TableInfo> list = new List<TableInfo>();
        string[] files = Places.DbfFiles(folder);
        for (int i = 0; i < files.Length; i++) {
            if (progress != null) progress(i, files.Length);
            TableInfo info = new TableInfo();
            info.Name = Path.GetFileName(files[i]);
            try {
                DbfTable h = DbfTable.LoadHeader(files[i]);
                info.Records = h.Expected;
                info.Abonents = h.FieldIndex("NAB") >= 0 && h.FieldIndex("FIO") >= 0
                    && (h.FieldIndex("DOM") >= 0 || h.FieldIndex("UL") >= 0);
            } catch (Exception) {
                continue;
            }
            list.Add(info);
        }
        list.Sort(delegate(TableInfo a, TableInfo b) {
            if (a.Abonents != b.Abonents) return a.Abonents ? -1 : 1;
            bool aa = a.Name.ToUpperInvariant().StartsWith("ARC"), ba = b.Name.ToUpperInvariant().StartsWith("ARC");
            if (aa != ba) return aa ? 1 : -1;
            if (a.Records != b.Records) return b.Records.CompareTo(a.Records);
            return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
        });
        return list;
    }
}

// Отчёт для настройки: что из какой таблицы взялось и как прошёл поиск.
// Данных абонентов в нём нет: только имена таблиц и полей, вид значений
// (буквы заменены на А/а, цифры на 9) и количества.
public static class Report {
    static string path;
    static int searches;
    static readonly string[] Keep = {
        "ул", "улица", "пер", "пр", "пр-т", "пл", "б-р", "ш", "д", "дом", "кв", "к", "корп", "г", "аг", "п", "пос",
        "гп", "рп", "дер", "с/с", "р-н", "обл", "х", "мкр" };

    public static string FilePath { get { return path; } }

    public static void Start(string file) {
        path = file;
        searches = 0;
        try { File.WriteAllText(file, "", Encoding.UTF8); }
        catch (Exception) { path = null; }
        Line("=== Поиск абонента: запуск " + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss") + " ===");
        Line("В отчёте нет данных абонентов: только имена таблиц и полей, вид значений");
        Line("(буквы заменены на А/а, цифры на 9) и количества.");
        Line("Windows " + Environment.OSVersion.Version + ", .NET " + Environment.Version);
    }

    static readonly object sync = new object();

    public static void Line(string text) {
        if (path == null) return;
        lock (sync) {
            try { File.AppendAllText(path, text + "\r\n", Encoding.UTF8); }
            catch (Exception) { }
        }
    }

    public static void Search(string text) {
        if (++searches > 1000) return;
        Line(DateTime.Now.ToString("HH:mm:ss") + "  " + text);
    }

    // вид значения: "Заводская ул. 18а" -> "Ааааааааа ул. 99а"
    public static string Shape(string value, bool keepWords) {
        StringBuilder sb = new StringBuilder();
        foreach (string token in value.Split(' ')) {
            if (token.Length == 0) continue;
            if (sb.Length > 0) sb.Append(' ');
            string core = token.Trim('.', ',', ';', ':').ToLowerInvariant();
            if (keepWords && Array.IndexOf(Keep, core) >= 0) { sb.Append(token.ToLowerInvariant()); continue; }
            foreach (char c in token) sb.Append(char.IsDigit(c) ? '9' : char.IsLetter(c) ? (char.IsUpper(c) ? 'А' : 'а') : c);
            if (sb.Length > 60) { sb.Append("..."); break; }
        }
        return sb.ToString();
    }

    // список полей таблицы: тип, длина, сколько заполнено и как обычно выглядит значение
    public static void Fields(DbfTable t, string indent) {
        int sample = Math.Min(t.Count, 5000);
        for (int j = 0; j < t.Fields.Count; j++) {
            DbfField f = t.Fields[j];
            string label = FieldNames.Label(f.Name);
            string head = indent + (f.Name + "           ").Substring(0, 11) + (f.Type.ToString() + f.Length + "    ").Substring(0, 5)
                + (label == null ? "" : "(" + label + ") ");
            if (f.Type == 'M') { Line(head + "примечание (длинный текст)"); continue; }
            bool isName = string.Compare(f.Name, "FIO", StringComparison.OrdinalIgnoreCase) == 0;
            Dictionary<string, int> shapes = new Dictionary<string, int>();
            int filled = 0;
            for (int r = 0; r < sample; r++) {
                string v = DbfTable.Format(t.GetValue(r, j, null), true).Trim();
                if (v.Length == 0 || v == "0") continue;
                filled++;
                string sh = Shape(v, !isName);
                int n;
                shapes.TryGetValue(sh, out n);
                shapes[sh] = n + 1;
            }
            string top = "";
            int best = 0;
            foreach (KeyValuePair<string, int> kv in shapes) if (kv.Value > best) { best = kv.Value; top = kv.Key; }
            Line(head + "заполнено " + (sample == 0 ? 0 : filled * 100 / sample) + "%"
                + (top.Length == 0 ? "" : ", обычно: " + top + (shapes.Count > 1 ? "  (разных видов: " + shapes.Count + ")" : "")));
        }
    }
}

// Справочник улиц. У абонента в поле UL хранится код улицы. Название улицы берём из справочника
// улиц (у вас STREET.DBF), а населённый пункт и сельсовет - из справочников, на которые он ссылается
// своими кодами (IDNP -> таблица населённых пунктов, IDSS -> таблица сельсоветов). Их ищем сами:
// таблица, где есть поле с тем же именем, каждый код встречается один раз и при нём есть текст.
public class StreetDirectory {
    public string TableName;
    public string KeyField;
    public Dictionary<string, string> Links = new Dictionary<string, string>();   // поле-ссылка -> таблица (IDNP -> SPRNP.DBF)
    readonly Dictionary<string, string> names = new Dictionary<string, string>();
    readonly Dictionary<string, string> lowerNames = new Dictionary<string, string>();
    readonly Dictionary<string, string> ssOf = new Dictionary<string, string>();  // код улицы -> сельсовет
    readonly Dictionary<string, string> townOf = new Dictionary<string, string>();    // код улицы -> населённый пункт ("аг. Боровляны")
    readonly Dictionary<string, string> streetOf = new Dictionary<string, string>();  // код улицы -> своё название ("Заводская ул.")

    public int Count { get { return names.Count; } }

    public string Name(string code) {
        string s;
        return names.TryGetValue(NormalizeCode(code), out s) ? s : null;
    }

    public string LowerName(string code) {
        string s;
        return lowerNames.TryGetValue(NormalizeCode(code), out s) ? s : null;
    }

    // для карточки: населённый пункт ("аг. Боровляны"), улица ("Заводская ул."), сельсовет
    public string Town(string code) {
        string s;
        return townOf.TryGetValue(NormalizeCode(code), out s) ? s : null;
    }

    public string Street(string code) {
        string s;
        return streetOf.TryGetValue(NormalizeCode(code), out s) ? s : null;
    }

    public string Selsovet(string code) {
        string s;
        return ssOf.TryGetValue(NormalizeCode(code), out s) ? s : null;
    }

    public double Coverage(List<string> codes) {
        if (codes.Count == 0) return 0;
        int hit = 0;
        foreach (string c in codes) if (names.ContainsKey(c)) hit++;
        return (double)hit / codes.Count;
    }

    // сельсоветы, к которым относятся улицы справочника
    public List<string> Selsovety {
        get {
            List<string> list = new List<string>();
            foreach (string v in ssOf.Values) if (v.Length > 0 && !list.Contains(v)) list.Add(v);
            list.Sort(StringComparer.CurrentCultureIgnoreCase);
            return list;
        }
    }

    // улица в одном из выбранных сельсоветов (selected = null - выбраны все; сельсовет неизвестен - показываем)
    public bool InSelsovety(string code, Dictionary<string, bool> selected) {
        if (selected == null) return true;
        string ss;
        if (!ssOf.TryGetValue(NormalizeCode(code), out ss) || ss.Length == 0) return true;
        return selected.ContainsKey(ss);
    }

    // Улицы, в названии которых (с населённым пунктом и сельсоветом) больше всего слов адреса
    public List<string> BestStreets(List<string> words, Dictionary<string, bool> selected, out int best) {
        best = 0;
        List<string> codes = new List<string>();
        List<string> norm = new List<string>();
        foreach (string w in words) norm.Add(w.ToLowerInvariant().Replace('ё', 'е'));
        foreach (KeyValuePair<string, string> kv in lowerNames) {
            int score = 0;
            foreach (string w in norm) if (kv.Value.IndexOf(w, StringComparison.Ordinal) >= 0) score++;
            if (score == 0 || score < best || !InSelsovety(kv.Key, selected)) continue;
            if (score > best) { best = score; codes.Clear(); }
            codes.Add(kv.Key);
        }
        return codes;
    }

    static string CleanSs(string ss) {
        string s = ss.Trim();
        foreach (string tail in new string[] { "с/с", "сельсовет", "с/с.", "сс" })
            if (s.EndsWith(" " + tail, StringComparison.OrdinalIgnoreCase)) s = s.Substring(0, s.Length - tail.Length - 1).Trim();
        return s;
    }

    public static string NormalizeCode(string s) {
        s = s.Trim();
        string t = s.TrimStart('0');
        return t.Length == 0 && s.Length > 0 ? "0" : t;
    }

    static bool IsDigits(string s) {
        if (s.Length == 0) return false;
        foreach (char c in s) if (c < '0' || c > '9') return false;
        return true;
    }

    static bool HasLetter(string s) {
        foreach (char c in s) if (char.IsLetter(c)) return true;
        return false;
    }

    static string Value(DbfTable t, int row, int field) {
        return DbfTable.Format(t.GetValue(row, field, null), true).Trim();
    }

    // Коды улиц у абонентов, если в UL почти везде числа; иначе null (там названия)
    public static List<string> Codes(DbfTable abon, int ul) {
        if (ul < 0) return null;
        Dictionary<string, bool> codes = new Dictionary<string, bool>();
        int filled = 0, numeric = 0;
        for (int r = 0; r < abon.Count; r++) {
            string v = Value(abon, r, ul);
            if (v.Length == 0) continue;
            filled++;
            if (!IsDigits(v.Replace(",00", "").Replace(".00", ""))) continue;
            numeric++;
            codes[NormalizeCode(v)] = true;
        }
        Report.Line("Поле улицы (UL) в первых " + abon.Count + " записях: заполнено " + filled + ", из них чисел " + numeric + ", разных чисел " + codes.Count
            + (filled > 0 && numeric >= filled * 0.9 ? " -> в UL коды улиц, нужен справочник" : " -> в UL названия, справочник не нужен"));
        if (filled == 0 || numeric < filled * 0.9) return null;
        return new List<string>(codes.Keys);
    }

    // строка таблицы-ссылки: её текст и (на один уровень глубже) тексты её собственных ссылок
    class LinkRow {
        public string Text;
        public Dictionary<string, string> Nested = new Dictionary<string, string>();
    }

    // Где искать таблицы-ссылки: сначала запомненная с прошлого раза, потом все таблицы папки
    class TableSource {
        readonly string folder;
        readonly Dictionary<string, string> hints;
        List<TableInfo> all;
        public readonly Dictionary<string, string> Found = new Dictionary<string, string>();

        public TableSource(string folder, Dictionary<string, string> hints) {
            this.folder = folder;
            this.hints = hints;
        }

        public IEnumerable<TableInfo> Candidates(string field) {
            string name = null;
            if (hints != null && hints.TryGetValue(field.ToUpperInvariant(), out name) && File.Exists(Path.Combine(folder, name))) {
                TableInfo info = null;
                try {
                    info = new TableInfo();
                    info.Name = name;
                    info.Records = DbfTable.LoadHeader(Path.Combine(folder, name)).Expected;
                } catch (Exception) {
                    info = null;
                }
                if (info != null) yield return info;
            }
            if (all == null) all = TableInfo.List(folder, null);
            foreach (TableInfo info in all)
                if (name == null || string.Compare(info.Name, name, StringComparison.OrdinalIgnoreCase) != 0) yield return info;
        }
    }

    // Найти таблицу, где поле field - уникальный код с текстом при нём (например, IDNP в таблице населённых пунктов)
    static Dictionary<string, LinkRow> FindLink(string folder, TableSource tables, string field, List<string> needed,
                                                string exclude, bool nested, out string found) {
        found = null;
        foreach (TableInfo info in tables.Candidates(field)) {
            if (info.Records < 1 || info.Records > 50000) continue;
            if (string.Compare(info.Name, exclude, StringComparison.OrdinalIgnoreCase) == 0) continue;
            string path = Path.Combine(folder, info.Name);
            DbfTable t;
            int k;
            try {
                DbfTable h = DbfTable.LoadHeader(path);
                k = h.FieldIndex(field);
                if (k < 0) continue;
                bool text = false;
                foreach (DbfField f in h.Fields) if (f.Type == 'C' && f.Length >= 3) text = true;
                if (!text) continue;
                t = DbfTable.Load(path, false);
            } catch (Exception) {
                continue;
            }
            Dictionary<string, LinkRow> map = new Dictionary<string, LinkRow>();
            int filled = 0, withText = 0;
            for (int r = 0; r < t.Count; r++) {
                string code = NormalizeCode(Value(t, r, k));
                if (code.Length == 0 || code == "0") continue;
                filled++;
                if (map.ContainsKey(code)) continue;
                LinkRow row = new LinkRow();
                // сокращения ("аг.", "д.", "г.") - вперёд: "аг. Боровляны", а не "Боровляны аг."
                List<string> words = new List<string>();
                int front = 0;
                for (int j = 0; j < t.Fields.Count; j++) {
                    if (j == k || t.Fields[j].Type != 'C') continue;
                    string v = Value(t, r, j);
                    if (v.Length == 0 || !HasLetter(v)) continue;
                    if (v.Length <= 5 && v.EndsWith(".")) words.Insert(front++, v);
                    else words.Add(v);
                }
                row.Text = string.Join(" ", words.ToArray());
                if (row.Text.Length > 0) withText++;
                map[code] = row;
            }
            if (filled == 0 || map.Count < filled * 0.95 || withText < map.Count * 0.5) continue;   // код должен быть уникальным, с текстом
            int hit = 0;
            foreach (string c in needed) if (map.ContainsKey(c)) hit++;
            if (needed.Count > 0 && hit < needed.Count * 0.9) continue;                            // и покрывать почти все коды
            found = info.Name;
            tables.Found[field.ToUpperInvariant()] = info.Name;
            Report.Line("    поле " + field + " -> " + info.Name + " (записей " + t.Count + ", кодов нашлось " + hit + " из " + needed.Count + "). Поля:");
            Report.Fields(t, "        ");
            if (nested) {
                // ссылки самой этой таблицы (например, у населённого пункта - его сельсовет)
                for (int j = 0; j < t.Fields.Count; j++) {
                    if (j == k || t.Fields[j].Type != 'N') continue;
                    List<string> codes = new List<string>();
                    Dictionary<string, bool> seen = new Dictionary<string, bool>();
                    for (int r = 0; r < t.Count; r++) {
                        string c = NormalizeCode(Value(t, r, j));
                        if (c.Length > 0 && c != "0" && !seen.ContainsKey(c)) { seen[c] = true; codes.Add(c); }
                    }
                    if (codes.Count == 0) continue;
                    string inner;
                    Dictionary<string, LinkRow> sub = FindLink(folder, tables, t.Fields[j].Name, codes, info.Name, false, out inner);
                    if (sub == null) continue;
                    for (int r = 0; r < t.Count; r++) {
                        string code = NormalizeCode(Value(t, r, k));
                        LinkRow row, target;
                        if (!map.TryGetValue(code, out row)) continue;
                        if (sub.TryGetValue(NormalizeCode(Value(t, r, j)), out target) && target.Text.Length > 0)
                            row.Nested[t.Fields[j].Name.ToUpperInvariant()] = target.Text;
                    }
                }
            }
            return map;
        }
        return null;
    }

    public static StreetDirectory Load(string folder, string tableName, string keyField) {
        return Load(folder, tableName, keyField, null);
    }

    // links - запомненные с прошлого раза таблицы-ссылки (чтобы не перебирать все таблицы папки)
    public static StreetDirectory Load(string folder, string tableName, string keyField, Dictionary<string, string> links) {
        string path = Path.Combine(folder, tableName);
        DbfTable d = DbfTable.Load(path, false);
        int key = d.FieldIndex(keyField);
        if (key < 0) return null;
        StreetDirectory dir = new StreetDirectory();
        dir.TableName = Path.GetFileName(path);
        dir.KeyField = d.Fields[key].Name;
        Report.Line("Справочник улиц " + dir.TableName + ": код - поле " + dir.KeyField + ", записей " + d.Count + ". Поля:");
        Report.Fields(d, "    ");

        // числовые поля справочника - ссылки на другие справочники (населённый пункт, сельсовет)
        TableSource tables = new TableSource(folder, links);
        Dictionary<int, Dictionary<string, LinkRow>> found = new Dictionary<int, Dictionary<string, LinkRow>>();
        for (int j = 0; j < d.Fields.Count; j++) {
            if (j == key || d.Fields[j].Type != 'N') continue;
            List<string> codes = new List<string>();
            Dictionary<string, bool> seen = new Dictionary<string, bool>();
            for (int r = 0; r < d.Count; r++) {
                string c = NormalizeCode(Value(d, r, j));
                if (c.Length > 0 && c != "0" && !seen.ContainsKey(c)) { seen[c] = true; codes.Add(c); }
            }
            if (codes.Count == 0) continue;
            string table;
            Dictionary<string, LinkRow> map = FindLink(folder, tables, d.Fields[j].Name, codes, dir.TableName, true, out table);
            if (map != null) found[j] = map;
            else Report.Line("    поле " + d.Fields[j].Name + ": справочник к нему не нашёлся");
        }
        dir.Links = tables.Found;

        for (int r = 0; r < d.Count; r++) {
            string code = NormalizeCode(Value(d, r, key));
            if (code.Length == 0 || dir.names.ContainsKey(code)) continue;
            // своё: название улицы
            StringBuilder own = new StringBuilder();
            for (int j = 0; j < d.Fields.Count; j++) {
                if (j == key || d.Fields[j].Type != 'C') continue;
                string v = Value(d, r, j);
                if (v.Length == 0 || !HasLetter(v)) continue;
                if (own.Length > 0) own.Append(", ");
                own.Append(v);
            }
            // по ссылкам: населённый пункт, сельсовет и прочее
            Dictionary<string, string> parts = new Dictionary<string, string>();
            List<string> order = new List<string>();
            foreach (KeyValuePair<int, Dictionary<string, LinkRow>> link in found) {
                LinkRow row;
                if (!link.Value.TryGetValue(NormalizeCode(Value(d, r, link.Key)), out row) || row.Text.Length == 0) continue;
                string name = d.Fields[link.Key].Name.ToUpperInvariant();
                parts[name] = row.Text;
                order.Add(name);
                foreach (KeyValuePair<string, string> n in row.Nested)
                    if (!parts.ContainsKey(n.Key)) { parts[n.Key] = n.Value; order.Add(n.Key); }
            }
            // если своя ссылка пустая, а у населённого пункта она есть - берём оттуда (сельсовет улицы через её деревню)
            string town = "", ss = "", other = "";
            foreach (string name in order) {
                string text = parts[name];
                if (name.Contains("NP")) { if (town.Length == 0) town = text; }
                else if (name.Contains("SS")) { if (ss.Length == 0) ss = text; }
                else other += (other.Length > 0 ? ", " : "") + text;
            }
            StringBuilder display = new StringBuilder();
            if (town.Length > 0) display.Append(town);
            if (own.Length > 0) display.Append((display.Length > 0 ? ", " : "") + own);
            if (ss.Length > 0) {
                string l = ss.ToLowerInvariant();
                display.Append((display.Length > 0 ? ", " : "") + ss + (l.Contains("с/с") || l.Contains("сельсовет") ? "" : " с/с"));
            }
            if (other.Length > 0) display.Append((display.Length > 0 ? ", " : "") + other);
            dir.names[code] = display.ToString();
            dir.lowerNames[code] = display.ToString().ToLowerInvariant().Replace('ё', 'е');
            dir.ssOf[code] = CleanSs(ss);
            dir.townOf[code] = town;
            dir.streetOf[code] = own.ToString();
        }
        return dir;
    }

    // ---- точный адрес ----

    class NameEntry {
        public string[] Words;
        public string Key;
        public List<string> Codes = new List<string>();
    }

    List<NameEntry> towns;                                        // населённые пункты: слова названия -> их улицы
    Dictionary<string, string> streetKey;                    // код улицы -> слова названия улицы
    Dictionary<string, NameEntry> streets;                        // название улицы -> улицы с таким названием (во всех нас. пунктах)

    void PrepareMatch() {
        lock (names) {
            if (towns != null) return;
            Dictionary<string, NameEntry> t = new Dictionary<string, NameEntry>();
            streets = new Dictionary<string, NameEntry>();
            streetKey = new Dictionary<string, string>();
            foreach (string code in names.Keys) {
                string town;
                if (townOf.TryGetValue(code, out town) && town.Length > 0) Add(t, AddressText.NameWords(town), code);
                string own;
                string[] sw = streetOf.TryGetValue(code, out own) ? AddressText.NameWords(own) : new string[0];
                streetKey[code] = string.Join(" ", sw);
                Add(streets, sw, code);
            }
            towns = new List<NameEntry>(t.Values);
        }
    }

    static void Add(Dictionary<string, NameEntry> map, string[] words, string code) {
        if (words.Length == 0) return;
        string key = string.Join(" ", words);
        NameEntry n;
        if (!map.TryGetValue(key, out n)) { n = new NameEntry(); n.Words = words; n.Key = key; map[key] = n; }
        n.Codes.Add(code);
    }

    // слова, которые могут быть названием: подряд, ещё не узнанные
    static List<int> NameSlots(List<AddrToken> toks) {
        List<int> list = new List<int>();
        for (int i = 0; i < toks.Count; i++) if (toks[i].Kind == 'w' && !toks[i].Ss && !toks[i].Bound) list.Add(i);
        return list;
    }

    // где в адресе стоит название целиком (все его слова подряд); -1 - нет
    static int Find(List<AddrToken> toks, List<int> slots, string[] words, bool[] used) {
        for (int p = 0; p + words.Length <= slots.Count; p++) {
            bool ok = true;
            for (int k = 0; k < words.Length && ok; k++) {
                int i = slots[p + k];
                if (used[p + k] || toks[i].Text != words[k]) ok = false;
                if (k > 0 && slots[p + k] - slots[p + k - 1] > 2) ok = false;   // между словами - не больше одного служебного ("аг.", "ул.")
            }
            if (ok) return p;
        }
        return -1;
    }

    class Reading {
        public NameEntry Town, Street;
        public int TownAt = -1, StreetAt = -1;
        public double Score;
    }

    // сколько слов узнано; рядом стоящее "ул." или "аг." подсказывает, улица это или населённый пункт
    static double Score(Reading r, List<AddrToken> toks, List<int> slots) {
        double score = 0;
        if (r.Town != null) {
            score += r.Town.Words.Length;
            if (Near(toks, slots[r.TownAt], slots[r.TownAt + r.Town.Words.Length - 1], 's')) score -= 0.5;
        }
        if (r.Street != null) {
            score += r.Street.Words.Length;
            if (Near(toks, slots[r.StreetAt], slots[r.StreetAt + r.Street.Words.Length - 1], 't')) score -= 0.5;
        }
        return score;
    }

    static bool Near(List<AddrToken> toks, int first, int last, char kind) {
        return (first > 0 && toks[first - 1].Kind == kind) || (last + 1 < toks.Count && toks[last + 1].Kind == kind);
    }

    // самое длинное название улицы из списка, которое есть в адресе
    static void BestStreet(List<AddrToken> toks, List<int> slots, bool[] used, IEnumerable<NameEntry> list, Reading r) {
        foreach (NameEntry n in list) {
            if (r.Street != null && n.Words.Length <= r.Street.Words.Length) continue;
            int p = Find(toks, slots, n.Words, used);
            if (p >= 0) { r.Street = n; r.StreetAt = p; }
        }
    }

    // Адрес как его вписали -> улицы (коды), дом, корпус, квартира.
    // Сначала населённый пункт, потом улица именно в нём, потом дом, корпус, квартира.
    public AddressMatch Match(string query) {
        PrepareMatch();
        AddressMatch m = new AddressMatch();
        List<AddrToken> toks = AddressText.Tokens(query);
        List<int> slots = NameSlots(toks);

        // все прочтения: каждый найденный в адресе населённый пункт + улица в нём; или только улица
        List<Reading> readings = new List<Reading>();
        Reading none = new Reading();
        BestStreet(toks, slots, new bool[slots.Count], streets.Values, none);
        readings.Add(none);
        foreach (NameEntry town in towns) {
            int p = Find(toks, slots, town.Words, new bool[slots.Count]);
            if (p < 0) continue;
            Reading r = new Reading();
            r.Town = town;
            r.TownAt = p;
            bool[] used = new bool[slots.Count];
            for (int k = 0; k < town.Words.Length; k++) used[p + k] = true;
            List<NameEntry> inTown = new List<NameEntry>();
            Dictionary<string, NameEntry> byKey = new Dictionary<string, NameEntry>();
            foreach (string code in town.Codes) {
                string key = streetKey[code];
                if (key.Length == 0) continue;
                NameEntry n;
                if (!byKey.TryGetValue(key, out n)) { n = new NameEntry(); n.Key = key; n.Words = key.Split(' '); byKey[key] = n; inTown.Add(n); }
                n.Codes.Add(code);
            }
            BestStreet(toks, slots, used, inTown, r);
            readings.Add(r);
        }
        // лучшее прочтение: узнано больше слов; при равенстве - с населённым пунктом, потом - что раньше в строке
        foreach (Reading r in readings) r.Score = Score(r, toks, slots);
        Reading best = none;
        foreach (Reading r in readings) {
            if (r == none) continue;
            if (r.Score > best.Score || (r.Score == best.Score && (best.Town == null || r.TownAt < best.TownAt))) best = r;
        }
        if (best.Town != null) for (int k = 0; k < best.Town.Words.Length; k++) toks[slots[best.TownAt + k]].Used = true;
        if (best.Street != null) for (int k = 0; k < best.Street.Words.Length; k++) toks[slots[best.StreetAt + k]].Used = true;

        // сельсовет: перед "с/с" или просто его название среди оставшихся слов
        List<string> ssWanted = new List<string>();
        List<string> leftover = new List<string>();
        int firstName = int.MaxValue;
        if (best.Town != null) firstName = Math.Min(firstName, slots[best.TownAt]);
        if (best.Street != null) firstName = Math.Min(firstName, slots[best.StreetAt]);
        for (int i = 0; i < toks.Count; i++) {
            AddrToken t = toks[i];
            if (t.Kind != 'w' || t.Used || t.Digit || t.Bound) continue;
            string ss = SsByWord(t.Text);
            if (ss != null) { if (!ssWanted.Contains(ss)) ssWanted.Add(ss); t.Used = true; continue; }
            if (t.Ss) { leftover.Add(t.Text); continue; }
            if (t.Text.Length == 1 && i > 0 && toks[i - 1].Digit && !toks[i - 1].Used) continue;   // буква дома: "18 а"
            leftover.Add(t.Text);
        }

        // дом, корпус, квартира
        string[] slot = new string[3];   // 0 - дом, 1 - корпус, 2 - квартира
        List<int> bare = new List<int>();
        List<string> values = new List<string>();
        int pending = -1, lastValue = -1;
        bool hasName = best.Town != null || best.Street != null;
        for (int i = 0; i < toks.Count; i++) {
            AddrToken t = toks[i];
            if (t.Kind == 'h') { pending = 0; continue; }
            if (t.Kind == 'k') { pending = 1; continue; }
            if (t.Kind == 'f') { pending = 2; continue; }
            if (t.Kind != 'w' || t.Used) continue;
            if (!t.Digit) {
                // буква дома, написанная отдельно: "18 а"
                if (t.Text.Length == 1 && lastValue >= 0 && i > 0 && toks[i - 1].Digit) values[lastValue] += t.Text;
                continue;
            }
            bool longNumber = t.Text.Length >= 5 && IsDigits(t.Text);
            if (longNumber || (!t.Bound && pending < 0 && hasName && i < firstName)) { pending = -1; lastValue = -1; continue; }   // лицевой, индекс, номер строки списка
            values.Add(t.Text);
            lastValue = values.Count - 1;
            if (pending >= 0 && slot[pending] == null) slot[pending] = "#" + lastValue;
            else bare.Add(lastValue);
            pending = -1;
        }
        // числа без пояснений: первое - дом, второе - квартира, третье - корпус
        int[] order = { 0, 2, 1 };
        foreach (int b in bare) foreach (int o in order) if (slot[o] == null) { slot[o] = "#" + b; break; }
        m.House = slot[0] == null ? null : values[int.Parse(slot[0].Substring(1))];
        m.Korp = slot[1] == null ? null : values[int.Parse(slot[1].Substring(1))];
        m.Flat = slot[2] == null ? null : values[int.Parse(slot[2].Substring(1))];

        // улицы, где искать
        string townText = best.Town == null ? null : TownLabel(best.Town.Codes);
        if (best.Town != null && best.Street != null) m.Codes.AddRange(best.Street.Codes);
        else if (best.Town != null) {
            if (leftover.Count > 0) {
                m.Problem = "В " + townText + " нет улицы «" + string.Join(" ", leftover.ToArray()) + "»" + Elsewhere(leftover) + ".";
                m.Explain = "нас. пункт узнан, улица не найдена в нём";
                return m;
            }
            m.Codes.AddRange(best.Town.Codes);
        } else if (best.Street != null) m.Codes.AddRange(best.Street.Codes);
        else {
            m.Problem = leftover.Count > 0 ? "Не нашёл в справочниках улиц и населённых пунктов: «" + string.Join(" ", leftover.ToArray()) + "»."
                : m.House != null ? "Впишите улицу или населённый пункт, не только номер дома." : "Впишите адрес.";
            m.Explain = leftover.Count > 0 ? "не узнано ни нас. пункта, ни улицы" : "нет названий";
            return m;
        }
        if (leftover.Count > 0) {
            m.Codes.Clear();
            m.Problem = "Не понял в адресе: «" + string.Join(" ", leftover.ToArray()) + "» - такого нет в справочниках" + (best.Town != null ? " для " + townText : "") + ".";
            m.Explain = "лишние неузнанные слова: " + leftover.Count;
            return m;
        }
        if (ssWanted.Count > 0) {
            List<string> keep = new List<string>();
            foreach (string c in m.Codes) { string s; if (ssOf.TryGetValue(c, out s) && ssWanted.Contains(s)) keep.Add(c); }
            if (keep.Count == 0) {
                m.Codes.Clear();
                m.Problem = "В " + string.Join(", ", ssWanted.ToArray()) + " с/с такого адреса нет.";
                return m;
            }
            m.Codes = keep;
        }

        StringBuilder said = new StringBuilder();
        if (townText != null) said.Append(townText);
        if (best.Street != null) said.Append((said.Length > 0 ? " -> " : "") + StreetLabel(m.Codes, best.Town == null));
        else said.Append(" -> все улицы");
        if (m.House != null) said.Append(" -> дом " + m.House);
        if (m.Korp != null) said.Append(", корп. " + m.Korp);
        if (m.Flat != null) said.Append(", кв. " + m.Flat);
        m.Said = said.ToString();
        m.Explain = "нас. пункт: " + (best.Town == null ? "не указан" : "узнан (вариантов " + TownCount(best.Town.Codes) + ")")
            + ", улица: " + (best.Street == null ? (best.Town != null ? "не указана - весь нас. пункт" : "нет") : "узнана")
            + (ssWanted.Count > 0 ? ", сельсовет указан" : "") + ", улиц для поиска: " + m.Codes.Count
            + ", дом: " + (m.House != null ? "да" : "нет") + ", корпус: " + (m.Korp != null ? "да" : "нет") + ", квартира: " + (m.Flat != null ? "да" : "нет");
        return m;
    }

    string SsByWord(string w) {
        if (w.Length < 5) return null;
        string stem = Stem(w);
        foreach (string s in ssOf.Values) if (s.Length > 0 && Stem(s).Replace('ё', 'е') == stem) return s;
        return null;
    }

    // сколько разных населённых пунктов (одноимённые в разных сельсоветах - разные)
    int TownCount(List<string> codes) {
        Dictionary<string, bool> seen = new Dictionary<string, bool>();
        foreach (string c in codes) {
            string t, s;
            townOf.TryGetValue(c, out t);
            ssOf.TryGetValue(c, out s);
            seen[t + "|" + s] = true;
        }
        return seen.Count;
    }

    string TownLabel(List<string> codes) {
        List<string> list = new List<string>();
        foreach (string c in codes) {
            string t, s;
            townOf.TryGetValue(c, out t);
            ssOf.TryGetValue(c, out s);
            string label = t + (s != null && s.Length > 0 ? " (" + s + " с/с)" : "");
            if (!list.Contains(label)) list.Add(label);
        }
        return list.Count == 1 ? list[0].Substring(0, list[0].IndexOf(" (") > 0 ? list[0].IndexOf(" (") : list[0].Length) : string.Join(" или ", list.ToArray());
    }

    string StreetLabel(List<string> codes, bool withTown) {
        List<string> list = new List<string>();
        foreach (string c in codes) {
            string st, t;
            streetOf.TryGetValue(c, out st);
            townOf.TryGetValue(c, out t);
            string label = withTown && t != null && t.Length > 0 ? st + " (" + t + ")" : st;
            if (!list.Contains(label)) list.Add(label);
        }
        if (list.Count > 4) return list[0] + " и ещё " + (list.Count - 1);
        return string.Join(", ", list.ToArray());
    }

    // где ещё есть улица с таким названием - подсказка
    string Elsewhere(List<string> words) {
        NameEntry n;
        if (!streets.TryGetValue(string.Join(" ", words.ToArray()), out n)) return "";
        List<string> list = new List<string>();
        foreach (string c in n.Codes) { string t; if (townOf.TryGetValue(c, out t) && t.Length > 0 && !list.Contains(t)) list.Add(t); }
        if (list.Count == 0) return "";
        return " (такая улица есть в: " + string.Join(", ", list.GetRange(0, Math.Min(5, list.Count)).ToArray()) + (list.Count > 5 ? "..." : "") + ")";
    }

    // Коды улиц, в адресе которых есть одно из названий (сельсоветы). "Боровлянский" ищется как "боровлянск".
    public Dictionary<string, bool> CodesMatching(string[] wanted, out string report) {
        List<string> stems = new List<string>();
        foreach (string n in wanted) stems.Add(Stem(n));
        int[] perName = new int[stems.Count];
        Dictionary<string, bool> codes = new Dictionary<string, bool>();
        foreach (KeyValuePair<string, string> kv in lowerNames) {
            for (int i = 0; i < stems.Count; i++) {
                if (stems[i].Length == 0 || kv.Value.IndexOf(stems[i], StringComparison.Ordinal) < 0) continue;
                perName[i]++;
                codes[kv.Key] = true;
                break;
            }
        }
        StringBuilder r = new StringBuilder("Сельсоветы из списка - улиц в справочнике: ");
        for (int i = 0; i < stems.Count; i++) r.Append((i > 0 ? ", " : "") + wanted[i].Trim() + " - " + perName[i]);
        r.Append(". Всего улиц: " + codes.Count + " из " + names.Count);
        report = r.ToString();
        return codes;
    }

    public static string Stem(string name) {
        string w = name.Trim().ToLowerInvariant();
        if (w.Length > 5 && (w.EndsWith("ий") || w.EndsWith("ой") || w.EndsWith("ая") || w.EndsWith("ое"))) w = w.Substring(0, w.Length - 2);
        return w;
    }

    // режим Excel: справочник улиц своей копии выгрузки (код -> н.п., улица, сельсовет; VygruzkaByt.ReadStreets)
    public static StreetDirectory FromCopy(string file) {
        StreetDirectory dir = new StreetDirectory();
        dir.TableName = Path.GetFileName(file);
        dir.KeyField = "UL";
        foreach (KeyValuePair<string, string[]> kv in VygruzkaByt.ReadStreets(file)) {
            string code = NormalizeCode(kv.Key), town = kv.Value[0].Trim(), own = kv.Value[1].Trim(), ss = kv.Value[2].Trim();
            StringBuilder display = new StringBuilder(town);
            if (own.Length > 0) display.Append((display.Length > 0 ? ", " : "") + own);
            if (ss.Length > 0) {
                string l = ss.ToLowerInvariant();
                display.Append((display.Length > 0 ? ", " : "") + ss + (l.Contains("с/с") || l.Contains("сельсовет") ? "" : " с/с"));
            }
            dir.names[code] = display.ToString();
            dir.lowerNames[code] = display.ToString().ToLowerInvariant().Replace('ё', 'е');
            dir.ssOf[code] = CleanSs(ss);
            dir.townOf[code] = town;
            dir.streetOf[code] = own;
        }
        return dir;
    }

    public bool HasTowns {
        get { foreach (string t in townOf.Values) if (t.Length > 0) return true; return false; }
    }

    class Candidate {
        public string Table, Key;
        public double Coverage;
        public int Records;
        public bool Ss, Np;
    }

    // Ищем таблицу, где есть поле с теми же кодами (каждый код - один раз) и текстом при них.
    // Берём, только если там нашлись почти все коды улиц абонентов. Из подходящих лучше та, у которой
    // есть ссылки на сельсовет и населённый пункт (STREET.DBF -> SPRSS, SPRNP), а не просто список улиц.
    public static StreetDirectory Detect(string folder, string abonTable, List<string> codes, LoadProgress progress) {
        List<TableInfo> tables = TableInfo.List(folder, null);
        List<Candidate> found = new List<Candidate>();
        // сначала - только поля кода улицы с "UL" в имени (KUL, IDUL): так не читаются все таблицы подряд
        for (int pass = 0; pass < 2 && found.Count == 0; pass++) {
            for (int i = 0; i < tables.Count; i++) {
                if (progress != null) progress(i + pass * tables.Count, tables.Count * 2);
                TableInfo info = tables[i];
                if (info.Abonents || info.Records < 2 || info.Records > 50000) continue;
                if (string.Compare(info.Name, abonTable, StringComparison.OrdinalIgnoreCase) == 0) continue;
                if (info.Name.ToUpperInvariant().StartsWith("ARC")) continue;
                string path = Path.Combine(folder, info.Name);
                DbfTable d;
                try {
                    DbfTable h = DbfTable.LoadHeader(path);
                    bool text = false, ulField = false;
                    foreach (DbfField f in h.Fields) {
                        if (f.Type == 'C' && f.Length >= 5) text = true;
                        if ((f.Type == 'N' || f.Type == 'C') && f.Length <= 10 && f.Name.ToUpperInvariant().Contains("UL")) ulField = true;
                    }
                    if (!text || (pass == 0 && !ulField)) continue;
                    d = DbfTable.Load(path, false);
                } catch (Exception) {
                    continue;
                }
                if (d.Count < 2) continue;
                for (int k = 0; k < d.Fields.Count; k++) {
                    DbfField f = d.Fields[k];
                    if (!((f.Type == 'N' && f.Length <= 10) || (f.Type == 'C' && f.Length <= 10))) continue;
                    if (pass == 0 && !f.Name.ToUpperInvariant().Contains("UL")) continue;
                    Dictionary<string, bool> values = new Dictionary<string, bool>();
                    int filled = 0;
                    for (int r = 0; r < d.Count; r++) {
                        string v = NormalizeCode(Value(d, r, k));
                        if (v.Length == 0) continue;
                        filled++;
                        values[v] = true;
                    }
                    if (filled < 2 || values.Count < filled * 0.95) continue;   // код справочника не повторяется
                    int hit = 0;
                    foreach (string c in codes) if (values.ContainsKey(c)) hit++;
                    double coverage = (double)hit / codes.Count;
                    Candidate cand = new Candidate();
                    cand.Table = info.Name;
                    cand.Key = f.Name;
                    cand.Coverage = coverage;
                    cand.Records = d.Count;
                    foreach (DbfField g in d.Fields) {
                        string n = g.Name.ToUpperInvariant();
                        if (g.Type != 'N' || g == f) continue;
                        if (n.Contains("SS")) cand.Ss = true;
                        if (n.Contains("NP")) cand.Np = true;
                    }
                    if (hit > 0)
                        Report.Line("    кандидат " + info.Name + "." + f.Name + ": записей " + d.Count + ", кодов улиц нашлось " + hit + " из " + codes.Count
                            + " (" + (int)(coverage * 100) + "%)" + (coverage >= 0.9 ? (cand.Ss ? ", есть ссылка на сельсовет" : "") + (cand.Np ? ", есть ссылка на населённый пункт" : "") : " - мало, не подходит"));
                    if (coverage >= 0.9) found.Add(cand);
                }
            }
        }
        if (found.Count == 0) {
            Report.Line("    справочник не найден: нет таблицы, где нашлись бы 90% кодов улиц");
            return null;
        }
        found.Sort(delegate(Candidate x, Candidate y) {
            if (x.Ss != y.Ss) return x.Ss ? -1 : 1;
            if (x.Np != y.Np) return x.Np ? -1 : 1;
            if (x.Coverage != y.Coverage) return y.Coverage.CompareTo(x.Coverage);
            return y.Records.CompareTo(x.Records);
        });
        // берём лучший; если в нём не оказалось ни населённых пунктов, ни сельсоветов - следующий
        StreetDirectory first = null;
        for (int i = 0; i < found.Count && i < 3; i++) {
            Report.Line("    пробую " + found[i].Table + "." + found[i].Key);
            StreetDirectory dir = Load(folder, found[i].Table, found[i].Key);
            if (dir == null) continue;
            if (first == null) first = dir;
            if (dir.HasTowns || dir.Selsovety.Count > 0) { Report.Line("    выбран " + found[i].Table + "." + found[i].Key); return dir; }
        }
        if (first != null) Report.Line("    выбран " + first.TableName + "." + first.KeyField + " (населённых пунктов и сельсоветов в нём нет)");
        return first;
    }
}

public enum SearchMode { Account, Address, Meter, Name }

// Поиск абонента: по лицевому счёту, адресу, номеру счётчика или ФИО - что выбрано
public class AbonentQuery {
    readonly DbfTable t;
    readonly int[] accountFields, addressFields, meterFields, nameFields;
    readonly int oldMeter;   // снятый счётчик (NSC) - ищем по нему, если по текущему не нашлось
    readonly int dom, kor, kv, ul;
    public readonly int[] Columns;   // что показывать в списке найденного
    public string LastExplain = "";  // как прошёл последний поиск - для отчёта (без самих слов)
    readonly string[] street;        // адрес по справочнику улиц для каждой записи (если справочник есть)
    readonly string[] streetLower;
    readonly string streetSource;

    public AbonentQuery(DbfTable t, StreetDirectory dir) {
        this.t = t;
        accountFields = Existing(new string[] { "NAB", "LS", "LIC", "LSCH", "LS_ERIP" });
        meterFields = Existing(new string[] { "NCH" });
        oldMeter = t.FieldIndex("NSC");
        nameFields = Existing(new string[] { "FIO" });
        dom = t.FieldIndex("DOM");
        kor = t.FieldIndex("KOR");
        kv = t.FieldIndex("KV");
        ul = t.FieldIndex("UL");

        // слова адреса (населённый пункт, улица) ищем во всех текстовых полях абонента,
        // кроме ФИО и номеров - где бы ни хранился населённый пункт
        string[] notAddress = { "FIO", "NAB", "LS", "LIC", "LSCH", "NCH", "NSC", "TIPCH", "TSC", "TEL", "DOM", "KOR", "KV", "N_F", "LS_ERIP" };
        List<int> address = new List<int>();
        if (dir != null) {
            // улицы - по справочнику; из полей абонента берём только явно адресные
            address.AddRange(Existing(new string[] { "UL", "NP", "NASP", "GOROD", "ULICA", "ADRES", "ADR" }));
        } else {
            for (int i = 0; i < t.Fields.Count; i++) {
                bool skip = false;
                foreach (string n in notAddress) if (string.Compare(t.Fields[i].Name, n, StringComparison.OrdinalIgnoreCase) == 0) skip = true;
                if (!skip && (t.Fields[i].Type == 'C' || i == ul)) address.Add(i);
            }
        }
        addressFields = address.ToArray();

        if (dir != null && ul >= 0) {
            streetSource = dir.TableName;
            street = new string[t.Count];
            streetLower = new string[t.Count];
            for (int r = 0; r < t.Count; r++) {
                string code = DbfTable.Format(t.GetValue(r, ul, null), true);
                street[r] = dir.Name(code);
                streetLower[r] = dir.LowerName(code);
            }
        }
        Columns = Existing(new string[] { "NAB", "FIO", "UL", "DOM", "KOR", "KV", "NCH", "TIPCH", "TEL" });
        if (Columns.Length == 0) {
            Columns = new int[Math.Min(8, t.Fields.Count)];
            for (int i = 0; i < Columns.Length; i++) Columns[i] = i;
        }
    }

    public bool HasStreets { get { return street != null; } }

    // Записи, среди которых ищем: null - вся таблица, иначе только эти (выбранные сельсоветы)
    public int[] Scope;

    int RowCount { get { return Scope == null ? t.Count : Scope.Length; } }

    int RowAt(int i) { return Scope == null ? i : Scope[i]; }

    // Абоненты, у которых в адресе (справочник улиц или текстовые поля) есть одно из названий.
    // "Боровлянский" ищется как "боровлянск" - находится и "Боровлянский с/с", и "Боровлянского".
    public int[] FindByNames(string[] names, out string report) {
        List<string> stems = new List<string>();
        foreach (string n in names) {
            string w = n.Trim().ToLowerInvariant();
            if (w.Length > 5 && (w.EndsWith("ий") || w.EndsWith("ой") || w.EndsWith("ая") || w.EndsWith("ое"))) w = w.Substring(0, w.Length - 2);
            if (w.Length > 0) stems.Add(w);
        }
        SearchWord[] words = new SearchWord[stems.Count];
        for (int i = 0; i < words.Length; i++) words[i] = Part(stems[i]);
        int[] perName = new int[stems.Count];
        Dictionary<string, int> sources = new Dictionary<string, int>();
        List<int> rows = new List<int>();
        for (int row = 0; row < t.Count; row++) {
            for (int i = 0; i < words.Length; i++) {
                string source = null;
                if (streetLower != null && streetLower[row] != null && streetLower[row].IndexOf(stems[i], StringComparison.Ordinal) >= 0) source = "справочник улиц";
                else foreach (int f in addressFields) if (t.FieldContains(row, f, words[i])) { source = "поле " + t.Fields[f].Name; break; }
                if (source == null) continue;
                perName[i]++;
                int c;
                sources.TryGetValue(source, out c);
                sources[source] = c + 1;
                rows.Add(row);
                break;
            }
        }
        StringBuilder r = new StringBuilder();
        r.Append("Сельсоветы из списка: ");
        for (int i = 0; i < stems.Count; i++) r.Append((i > 0 ? ", " : "") + names[i].Trim() + " - " + perName[i]);
        r.Append(". Всего абонентов в них: " + rows.Count + " из " + t.Count + ". Где нашлись названия: ");
        if (sources.Count == 0) r.Append("нигде");
        bool first = true;
        foreach (KeyValuePair<string, int> kv in sources) { r.Append((first ? "" : ", ") + kv.Key + " - " + kv.Value); first = false; }
        report = r.ToString();
        return rows.ToArray();
    }

    public string FieldList(SearchMode mode) {
        int[] fields = mode == SearchMode.Account ? accountFields : mode == SearchMode.Address ? addressFields
            : mode == SearchMode.Meter ? meterFields : nameFields;
        List<string> names = new List<string>();
        foreach (int f in fields) names.Add(t.Fields[f].Name);
        string list = names.Count == 0 ? "вся запись (нужных полей нет)" : string.Join(", ", names.ToArray());
        if (mode == SearchMode.Address) {
            list += "; дом: " + (dom < 0 ? "нет поля" : t.Fields[dom].Name) + ", корпус: " + (kor < 0 ? "нет поля" : t.Fields[kor].Name)
                + ", квартира: " + (kv < 0 ? "нет поля" : t.Fields[kv].Name) + (street != null ? "; плюс справочник улиц" : "");
        }
        return list;
    }

    // адрес по справочнику для записи или null
    public string StreetOf(int row) {
        return street == null ? null : street[row];
    }

    // текст для списка: улица по справочнику вместо кода
    public string CellText(int row, int field) {
        string value = DbfTable.Format(t.GetValue(row, field, null), false);
        if (!IsStreetColumn(field)) return value;
        string s = street[row];
        return s == null ? "код " + value : s;
    }

    public string ColumnTitle(int field) {
        if (IsStreetColumn(field)) return "Населённый пункт, улица";
        string label = FieldNames.Label(t.Fields[field].Name);
        return label == null ? t.Fields[field].Name : label;
    }

    // дополнительная строка карточки: адрес по справочнику
    public string[] CardExtra(int row) {
        string s = StreetOf(row);
        return s == null ? null : new string[] { "Адрес по справочнику " + streetSource, s };
    }

    public bool IsStreetColumn(int field) {
        return field == ul && street != null;
    }

    int[] Existing(string[] names) {
        List<int> list = new List<int>();
        foreach (string n in names) {
            int i = t.FieldIndex(n);
            if (i >= 0) list.Add(i);
        }
        return list.ToArray();
    }

    public bool Partial;            // частичное совпадение; иначе - только точное
    public AddressMatch Address;    // точный адрес, узнанный по справочнику (иначе адрес ищется по словам)
    public string Miss = "";        // на чём адрес перестал совпадать ("дома 999 на этой улице нет")

    public List<int> Find(string query, SearchMode mode) {
        List<int> found;
        switch (mode) {
            case SearchMode.Account: found = Partial ? FindAccount(query) : FindAccountExact(query); break;
            case SearchMode.Address: found = !Partial && Address != null ? FindAddressExact() : FindAddress(query); break;
            case SearchMode.Meter: found = Partial ? FindMeter(query) : FindMeterExact(query); break;
            default: found = Partial ? FindWords(query, nameFields) : FindNameExact(query); break;
        }
        if (found.Count <= 20000) SortByAddress(found);
        return found;
    }

    // ---- точное совпадение ----

    string Text(int row, int field) {
        return field < 0 ? "" : DbfTable.Format(t.GetValue(row, field, null), true).Trim();
    }

    // лицевой: номер равен вписанному целиком (нули впереди не важны)
    List<int> FindAccountExact(string query) {
        List<int> found = new List<int>();
        StringBuilder digits = new StringBuilder();
        foreach (char c in query) if (c >= '0' && c <= '9') digits.Append(c);
        LastExplain = "цифр: " + digits.Length + ", только точное совпадение";
        if (digits.Length == 0) return found;
        string core = digits.ToString().TrimStart('0');
        if (core.Length == 0) core = "0";
        for (int i = 0; i < RowCount; i++) {
            int row = RowAt(i);
            foreach (int f in accountFields) {
                string v = Text(row, f);
                if (v.Length == 0) continue;
                string vc = v.TrimStart('0');
                if ((vc.Length == 0 ? "0" : vc) == core) { found.Add(row); break; }
            }
        }
        return found;
    }

    // номер счётчика для сравнения: только буквы и цифры, маленькие, без нулей впереди ("№ 0050-001" -> 50001)
    public static string MeterKey(string s) {
        StringBuilder sb = new StringBuilder();
        foreach (char c in s.ToLowerInvariant()) if (char.IsLetterOrDigit(c)) sb.Append(c);
        string r = sb.ToString().TrimStart('0');
        return r.Length == 0 && sb.Length > 0 ? "0" : r;
    }

    // номер из запроса: весь запрос и каждое его слово с цифрами ("СЕ-208BY 10011761" -> и 10011761)
    public static List<string> MeterKeys(string query) {
        List<string> keys = new List<string>();
        string q = query.Replace("№", " ");
        string all = MeterKey(q);
        if (all.Length > 0) keys.Add(all);
        foreach (string w in q.Split(new char[] { ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)) {
            int digits = 0;
            foreach (char c in w) if (char.IsDigit(c)) digits++;
            string k = MeterKey(w);
            if (digits >= 3 && k.Length >= 4 && !keys.Contains(k)) keys.Add(k);
        }
        return keys;
    }

    // счётчик: номер совпадает целиком; не нашёлся среди текущих - ищем среди снятых (NSC)
    List<int> FindMeterExact(string query) {
        List<int> found = new List<int>();
        List<string> keys = MeterKeys(query);
        LastExplain = "вариантов номера: " + keys.Count + ", только точное совпадение";
        if (keys.Count == 0) return found;
        foreach (int f in meterFields)
            for (int i = 0; i < RowCount; i++) { int row = RowAt(i); if (!found.Contains(row) && keys.Contains(MeterKey(Text(row, f)))) found.Add(row); }
        if (found.Count == 0 && oldMeter >= 0) {
            for (int i = 0; i < RowCount; i++) { int row = RowAt(i); if (keys.Contains(MeterKey(Text(row, oldMeter)))) found.Add(row); }
            if (found.Count > 0) LastExplain += ", найден по снятому счётчику (NSC)";
        }
        return found;
    }

    public static List<string> PersonWords(string s) {
        List<string> list = new List<string>();
        foreach (string w in s.ToLowerInvariant().Replace('ё', 'е').Split(new char[] { ' ', '.', ',', '\t' }, StringSplitOptions.RemoveEmptyEntries)) list.Add(w);
        return list;
    }

    // в одном поле ФИО бывает несколько человек: "ИВАНОВ И.И./ПЕТРОВА П.П."
    static readonly char[] PersonSeparators = { '/', '\\', ';', '+' };

    // частичное совпадение: каждое слово - часть ФИО
    public static bool ContainsAll(string fio, List<string> words) {
        string f = fio.ToLowerInvariant().Replace('ё', 'е');
        foreach (string w in words) if (f.IndexOf(w, StringComparison.Ordinal) < 0) return false;
        return true;
    }

    // ФИО подходит, если у кого-то из записанных людей слова идут так же: фамилия, имя, отчество - целиком;
    // инициал подходит к имени ("иванов и" - "Иванов Иван", "иванов иван" - "Иванов И.И.").
    // Двойная фамилия: "Свидлер Лишик Л.А." находится и по "лишик", и по "свидлер-лишик" - по "лишик".
    public static bool NameMatches(string fio, List<string> q) {
        if (q.Count == 0) return false;
        foreach (string person in fio.Split(PersonSeparators, StringSplitOptions.RemoveEmptyEntries)) {
            List<string> w = PersonWords(person);
            // с какого слова может начинаться фамилия: с первого; со второго - если слов много (двойная фамилия)
            for (int from = 0; from <= (w.Count >= 4 ? 1 : 0); from++) {
                if (w.Count - from < q.Count) break;
                bool ok = true;
                for (int k = 0; k < q.Count && ok; k++) {
                    string a = q[k], b = w[from + k];
                    ok = a == b || (Initial(a) && b.StartsWith(a)) || (Initial(b) && k > 0 && a.StartsWith(b))
                        || (k == 0 && Array.IndexOf(b.Split('-'), a) >= 0);
                }
                if (ok) return true;
            }
        }
        return false;
    }

    static bool Initial(string w) {
        return w.Length == 1 && char.IsLetter(w[0]);
    }

    // ФИО: вписанные слова - это фамилия, имя, отчество по порядку, каждое целиком.
    // Одна буква - инициал ("иванов и"); если в базе записан инициал ("Иванов И.И.") - он подходит к имени.
    List<int> FindNameExact(string query) {
        List<int> found = new List<int>();
        List<string> q = PersonWords(query);
        LastExplain = "слов: " + q.Count + ", только точное совпадение (с фамилии, словами целиком)";
        if (q.Count == 0 || nameFields.Length == 0) return found;
        for (int i = 0; i < RowCount; i++) {
            int row = RowAt(i);
            foreach (int f in nameFields)
                if (NameMatches(Text(row, f), q)) { found.Add(row); break; }
        }
        return found;
    }

    // адрес: улица из найденных по справочнику, дом, корпус и квартира - точно (если вписаны)
    List<int> FindAddressExact() {
        List<int> found = new List<int>();
        AddressMatch m = Address;
        Dictionary<string, bool> codes = new Dictionary<string, bool>();
        foreach (string c in m.Codes) codes[StreetDirectory.NormalizeCode(c)] = true;
        string house = m.House == null ? null : AddressMatch.Num(m.House);
        string korp = m.Korp == null ? null : AddressMatch.Num(m.Korp);
        string flat = m.Flat == null ? null : AddressMatch.Num(m.Flat);
        int onStreet = 0, inHouse = 0, inKorp = 0;
        for (int i = 0; i < RowCount; i++) {
            int row = RowAt(i);
            if (ul < 0 || !codes.ContainsKey(StreetDirectory.NormalizeCode(Text(row, ul)))) continue;
            onStreet++;
            if (house != null && (dom < 0 || AddressMatch.Num(Text(row, dom)) != house)) continue;
            inHouse++;
            if (korp != null && (kor < 0 || AddressMatch.Num(Text(row, kor)) != korp)) continue;
            inKorp++;
            if (flat != null && (kv < 0 || AddressMatch.Num(Text(row, kv)) != flat)) continue;
            found.Add(row);
        }
        // где оборвалась цепочка: улица -> дом -> корпус -> квартира
        if (found.Count == 0) {
            if (onStreet == 0) Miss = "Абонентов на этой улице нет.";
            else if (inHouse == 0) Miss = "Дома " + m.House + " здесь нет.";
            else if (inKorp == 0) Miss = "В доме " + m.House + " нет корпуса " + m.Korp + ".";
            else Miss = "В доме " + m.House + (m.Korp != null ? " корп. " + m.Korp : "") + " нет квартиры " + m.Flat + ".";
        }
        LastExplain = m.Explain + "; записей на этих улицах прочитано: " + onStreet + ", по дому: " + inHouse + ", по корпусу: " + inKorp + ", итог: " + found.Count;
        return found;
    }

    // ---- частичное совпадение (галочка "Частичное совпадение") ----

    // лицевой: берём из строки только цифры, нули впереди не важны
    List<int> FindAccount(string query) {
        List<int> found = new List<int>();
        StringBuilder digits = new StringBuilder();
        foreach (char c in query) if (c >= '0' && c <= '9') digits.Append(c);
        LastExplain = "цифр: " + digits.Length;
        if (digits.Length == 0) return found;
        string q = digits.ToString();
        SearchWord w = Part(q);
        string core = q.TrimStart('0');
        foreach (int f in accountFields) {
            for (int i = 0; i < RowCount; i++) {
                int row = RowAt(i);
                if (t.FieldEquals(row, f, w)) { found.Add(row); continue; }
                string v = DbfTable.Format(t.GetValue(row, f, null), true).Trim().TrimStart('0');
                if (core.Length > 0 && v == core) found.Add(row);
            }
        }
        if (found.Count > 0) { LastExplain += ", точное совпадение"; return found; }
        for (int i = 0; i < RowCount; i++) {
            int row = RowAt(i);
            if (InAny(row, accountFields, w)) found.Add(row);
        }
        if (found.Count > 0) { LastExplain += ", часть номера"; return found; }
        // длинный номер (Л/С) может содержать номер абонента внутри себя
        string qt = q.TrimStart('0');
        if (accountFields.Length > 0 && qt.Length >= 8) {
            int f = accountFields[0];
            for (int i = 0; i < RowCount; i++) {
                int row = RowAt(i);
                string nab = DbfTable.Format(t.GetValue(row, f, null), true).Trim().TrimStart('0');
                if (nab.Length >= 6 && nab.Length < qt.Length && qt.IndexOf(nab, StringComparison.Ordinal) >= 0) found.Add(row);
            }
            if (found.Count > 0) LastExplain += ", номер абонента внутри длинного номера";
        }
        return found;
    }

    // номер счётчика или ФИО: все слова должны быть в этом поле
    List<int> FindWords(string query, int[] fields) {
        List<int> found = new List<int>();
        List<SearchWord> words = new List<SearchWord>();
        foreach (string w in DbfTable.SplitWords(query)) words.Add(Part(w));
        LastExplain = "слов: " + words.Count;
        if (words.Count == 0) return found;

        for (int si = 0; si < RowCount; si++) {
            int row = RowAt(si);
            bool ok = true;
            foreach (SearchWord w in words) if (!InAny(row, fields, w)) { ok = false; break; }
            if (ok) found.Add(row);
        }
        return found;
    }

    // Номер счётчика: точно; потом как часть; потом по одним цифрам (без "№", пробелов, дефисов),
    // в том числе когда в списке номер длиннее или короче записанного; потом - по снятому счётчику
    List<int> FindMeter(string query) {
        List<int> found = new List<int>();
        string[] words = DbfTable.SplitWords(query);
        StringBuilder sb = new StringBuilder();
        foreach (char c in query) if (c >= '0' && c <= '9') sb.Append(c);
        string digits = sb.ToString().TrimStart('0');
        LastExplain = "слов: " + words.Length + ", цифр: " + sb.Length;
        if (words.Length == 0) return found;
        int[] where = meterFields.Length > 0 ? meterFields : new int[] { -1 };
        string how = MeterIn(where, words, digits, found);
        if (found.Count == 0 && oldMeter >= 0) {
            how = MeterIn(new int[] { oldMeter }, words, digits, found);
            if (found.Count > 0) how += ", найден по снятому счётчику (NSC)";
        }
        if (found.Count > 0) LastExplain += ", " + how;
        return found;
    }

    string MeterIn(int[] fields, string[] words, string digits, List<int> found) {
        if (words.Length == 1 && fields[0] >= 0) {
            SearchWord w = Part(words[0]);
            foreach (int f in fields)
                for (int i = 0; i < RowCount; i++) { int row = RowAt(i); if (t.FieldEquals(row, f, w)) found.Add(row); }
            if (found.Count > 0) return "точное совпадение";
        }
        List<SearchWord> parts = new List<SearchWord>();
        foreach (string w in words) parts.Add(Part(w));
        for (int i = 0; i < RowCount; i++) {
            int row = RowAt(i);
            bool ok = true;
            foreach (SearchWord w in parts) if (!InAny(row, fields, w)) { ok = false; break; }
            if (ok) found.Add(row);
        }
        if (found.Count > 0) return "часть номера";
        if (digits.Length < 5 || fields[0] < 0) return "";
        foreach (int f in fields) {
            for (int i = 0; i < RowCount; i++) {
                int row = RowAt(i);
                string v = DbfTable.Format(t.GetValue(row, f, null), true);
                StringBuilder d = new StringBuilder();
                foreach (char c in v) if (c >= '0' && c <= '9') d.Append(c);
                string nd = d.ToString().TrimStart('0');
                if (nd.Length < 5) continue;
                if (nd.IndexOf(digits, StringComparison.Ordinal) >= 0 || (nd.Length >= 6 && digits.IndexOf(nd, StringComparison.Ordinal) >= 0)) found.Add(row);
            }
        }
        return found.Count > 0 ? "по цифрам номера" : "";
    }

    // слово ищется как часть поля (и короткие числа тоже - это часть номера, а не дом)
    SearchWord Part(string word) {
        SearchWord w = t.PrepareWord(word);
        w.WholeNumber = false;
        return w;
    }

    // Адрес целиком, как его скопировали: "Острошицкий Городок Заводская ул. 18",
    // "аг. Острошицкий Городок, ул. Заводская, д. 18, кв. 5", "заводская 18 5".
    // Дом, корпус и квартира должны совпасть точно; из слов (населённый пункт, улица)
    // показываем записи, где их совпало больше всего - лишние слова не мешают.
    List<int> FindAddress(string query) {
        List<int> found = new List<int>();
        AddressParts a = AddressParts.Parse(query);
        List<SearchWord> text = new List<SearchWord>();
        List<string> textLower = new List<string>();
        foreach (string w in a.Words) { text.Add(Part(w)); textLower.Add(w.Replace('ё', 'е')); }
        SearchWord house = a.House == null ? null : t.PrepareWord(a.House);
        SearchWord korp = a.Korp == null ? null : t.PrepareWord(a.Korp);
        SearchWord flat = a.Flat == null ? null : t.PrepareWord(a.Flat);
        StringBuilder explain = new StringBuilder();
        explain.Append("слов адреса: " + text.Count + ", дом: " + (house != null ? "да" : "нет") + ", корпус: " + (korp != null ? "да" : "нет")
            + ", квартира: " + (flat != null ? "да" : "нет") + ", пропущено служебных слов и номеров: " + a.Skipped);
        if (text.Count == 0 && house == null && korp == null && flat == null) { LastExplain = explain.ToString(); return found; }

        // где нашлось каждое слово: в каком поле абонента или в справочнике
        int[,] fieldHits = new int[text.Count, addressFields.Length];
        int[] dirHits = new int[text.Count];
        int candidates = 0, best = 0;
        for (int si = 0; si < RowCount; si++) {
            int row = RowAt(si);
            if (house != null && !Is(row, dom, house)) continue;
            if (korp != null && !Is(row, kor, korp)) continue;
            if (flat != null && !Is(row, kv, flat)) continue;
            candidates++;
            int score = 0;
            for (int i = 0; i < text.Count; i++) {
                bool hit = false;
                for (int k = 0; k < addressFields.Length && !hit; k++)
                    if (t.FieldContains(row, addressFields[k], text[i])) { fieldHits[i, k]++; hit = true; }
                if (!hit && streetLower != null && streetLower[row] != null && streetLower[row].IndexOf(textLower[i], StringComparison.Ordinal) >= 0) {
                    dirHits[i]++;
                    hit = true;
                }
                if (hit) score++;
            }
            if (score < best) continue;
            if (score > best) { best = score; found.Clear(); }
            found.Add(row);
        }
        if (text.Count > 0 && best == 0) found.Clear();   // ни одно слово адреса не нашлось - улицы нет

        explain.Append("; подходят по дому/корпусу/квартире: " + candidates);
        for (int i = 0; i < text.Count; i++) {
            List<string> where = new List<string>();
            for (int k = 0; k < addressFields.Length; k++)
                if (fieldHits[i, k] > 0) where.Add("поле " + t.Fields[addressFields[k]].Name + " - " + fieldHits[i, k]);
            if (dirHits[i] > 0) where.Add("справочник - " + dirHits[i]);
            explain.Append("; слово " + (i + 1) + " (" + textLower[i].Length + " букв): " + (where.Count == 0 ? "не найдено" : string.Join(", ", where.ToArray())));
        }
        if (text.Count > 0) explain.Append("; лучшее совпадение: " + best + " из " + text.Count + " слов");
        LastExplain = explain.ToString();
        return found;
    }

    bool InAny(int row, int[] fields, SearchWord w) {
        if (fields.Length == 0) return t.FieldContains(row, -1, w);
        foreach (int f in fields) if (t.FieldContains(row, f, w)) return true;
        return false;
    }

    bool Is(int row, int field, SearchWord w) {
        return field < 0 ? t.FieldContains(row, -1, w) : t.FieldEquals(row, field, w);
    }

    class SortItem {
        public int Row;
        public string Street, House, Flat;
    }

    // по улице, дому и квартире, с числами по порядку: 2, 10, 18а
    void SortByAddress(List<int> rows) {
        if (ul < 0 && dom < 0) return;
        List<SortItem> items = new List<SortItem>(rows.Count);
        foreach (int r in rows) {
            SortItem it = new SortItem();
            it.Row = r;
            it.Street = street != null && street[r] != null ? street[r] : ul < 0 ? "" : DbfTable.Format(t.GetValue(r, ul, null), true);
            it.House = dom < 0 ? "" : DbfTable.Format(t.GetValue(r, dom, null), true);
            it.Flat = kv < 0 ? "" : DbfTable.Format(t.GetValue(r, kv, null), true);
            items.Add(it);
        }
        items.Sort(delegate(SortItem a, SortItem b) {
            int c = string.Compare(a.Street, b.Street, StringComparison.CurrentCultureIgnoreCase);
            if (c == 0) c = Natural(a.House, b.House);
            if (c == 0) c = Natural(a.Flat, b.Flat);
            return c != 0 ? c : a.Row.CompareTo(b.Row);
        });
        rows.Clear();
        foreach (SortItem it in items) rows.Add(it.Row);
    }

    static int Natural(string a, string b) {
        int na = LeadingNumber(a), nb = LeadingNumber(b);
        if (na != nb) return na.CompareTo(nb);
        return string.Compare(a, b, StringComparison.CurrentCultureIgnoreCase);
    }

    // пусто - раньше всех (частный дом без квартиры), без цифр - позже всех
    static int LeadingNumber(string s) {
        int n = 0, i = 0;
        s = s.Trim();
        if (s.Length == 0) return -1;
        while (i < s.Length && i < 9 && s[i] >= '0' && s[i] <= '9') n = n * 10 + (s[i++] - '0');
        return i == 0 ? int.MaxValue : n;
    }

    static bool IsDigitAt(string s, int i) {
        return i < s.Length && s[i] >= '0' && s[i] <= '9';
    }

    static bool IsDigits(string s) {
        foreach (char c in s) if (c < '0' || c > '9') return false;
        return s.Length > 0;
    }

    static bool HasDigit(string s) {
        foreach (char c in s) if (c >= '0' && c <= '9') return true;
        return false;
    }
}

// Главное окно: одна строка поиска. Каждый поиск идёт по индексам прямо в базе - данные всегда свежие.
public class AbonentSearch : Form {
    readonly string settingsFile;
    readonly string viewerSettings;
    string folder;
    string tableName;
    LiveBase live;                       // открытая база (null - ещё не открыта)
    bool opening;
    bool excelMode;                      // данные - из Excel-выгрузки быта (меню: «Настройки…»), а не из базы
    SearchResult current;
    bool searching, again;               // идёт поиск; пока он шёл, запрос поменялся
    bool scanning;
    volatile bool cancelScan;
    bool buildingNames;          // строится свой индекс по ФИО (в фоне)
    readonly Label namesLabel = new Label();   // состояние своего индекса по ФИО - видно всегда
    readonly LinkLabel namesLink = new LinkLabel();   // «обновить» / «построить» / «остановить»
    NameIndex namesTodo;                 // что (до)строить по кнопке: нет индекса / недостроен
    volatile bool cancelNames;
    int namesPercent;
    string namesLeft = "";
    bool cardWhenDone;                   // Enter: нашёлся один - сразу карточка
    Dictionary<string, bool> selected;   // выбранные сельсоветы (null - все)
    string baseInfo = "";

    static readonly string[] DefaultSelsovety = { "Шершунский", "Папернянский", "Юзуфовский", "Острошицкий", "Боровлянский", "Колодищанский" };
    internal SearchMode mode = SearchMode.Account;
    internal readonly RadioButton[] modeButtons = new RadioButton[4];
    readonly Label hint = new Label();
    readonly Button ssButton = new Button();
    readonly Button scanButton = new Button();
    internal readonly CheckBox partialBox = new CheckBox();

    static readonly string[] ModeNames = { "&Лицевой счёт", "&Адрес", "№ &счётчика", "&ФИО" };
    static readonly string[] Prompts = { "лицевой счёт", "адрес", "номер счётчика", "фамилию" };
    static readonly string[] Hints = {
        "Номер целиком:  044060216   (нули впереди можно не писать)",
        "Населённый пункт, улица, дом, корпус, квартира:  Острошицкий Городок Заводская ул. 18 кв 5   или  заводская 18 кв 5",
        "Номер счётчика целиком:  50001  (\"№\", пробелы и нули впереди не важны)",
        "С фамилии, словами целиком, и населённый пункт или улица:  иванов боровляны   или   иванов иван, боровляны заводская" };

    internal readonly TextBox queryBox = new TextBox();
    readonly DataGridView grid = new DataGridView();
    readonly Label status = new Label();
    readonly Panel bottom = new Panel();
    readonly Timer timer = new Timer();
    readonly Timer logTimer = new Timer();   // поиск пишем в отчёт, когда ввод успокоился

    public static void Run(string dir) {
        Run(dir, null);
    }

    // launch - как скрипт подготовил программу (готовая из кэша или собрана, за сколько секунд) - для отчёта
    public static void Run(string dir, string launch) {
        launchInfo = launch;
        Application.EnableVisualStyles();
        Application.Run(new AbonentSearch(Path.Combine(dir, "poisk.txt"), Path.Combine(dir, "nastroiki.txt")));
    }

    static string launchInfo;

    public AbonentSearch(string settingsFile, string viewerSettings) {
        this.settingsFile = settingsFile;
        // тема окон (тёмная / светлая) - седьмая строка poisk.txt, нет - тёмная; до создания элементов
        Look.Apply(Places.ReadSetting(settingsFile, 6) != "светлая");
        Font = Look.Base;
        Look.Wear(this);
        NaryadData.ProgramDir = Dir;     // окна нарядов и обходов (и из карточки) - настройка naryady.txt рядом с программой
        this.viewerSettings = viewerSettings;
        Text = "Поиск абонента (только чтение)";
        Size = new Size(1000, 650);
        StartPosition = FormStartPosition.CenterScreen;

        Panel top = new Panel();
        top.Dock = DockStyle.Top;
        top.Height = 100;
        Label caption = new Label();
        caption.Text = "Искать по:";
        caption.AutoSize = true;
        caption.Margin = new Padding(6, 9, 6, 0);
        // первая строка - в ряд, по фактической ширине надписей
        FlowLayoutPanel row = new FlowLayoutPanel();
        row.AutoSize = true;
        row.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        row.WrapContents = false;
        row.Location = new Point(4, 2);
        row.Controls.Add(caption);
        for (int i = 0; i < modeButtons.Length; i++) {
            RadioButton rb = new RadioButton();
            rb.Text = ModeNames[i];
            rb.AutoSize = true;
            rb.Margin = new Padding(3, 7, 8, 0);
            rb.Tag = (SearchMode)i;
            rb.CheckedChanged += new EventHandler(OnModeChanged);
            modeButtons[i] = rb;
            row.Controls.Add(rb);
        }
        partialBox.Text = "Частичное со&впадение";
        partialBox.AutoSize = true;
        partialBox.Margin = new Padding(10, 7, 3, 0);
        partialBox.CheckedChanged += delegate { StartSearch(); };
        new ToolTip().SetToolTip(partialBox, "Без галочки - только точное совпадение.\nС галочкой - ещё номера, которые так начинаются, ФИО по началу слов, адрес по похожим словам.");
        row.Controls.Add(partialBox);
        Button listButton = new Button();
        listButton.Text = "Поиск по списку...";
        listButton.AutoSize = true;
        listButton.Margin = new Padding(12, 3, 3, 0);
        listButton.Click += delegate { OpenBatch(); };
        row.Controls.Add(listButton);
        Button naryadButton = new Button();
        naryadButton.Text = "&Наряды...";
        naryadButton.AutoSize = true;
        naryadButton.Margin = new Padding(6, 3, 3, 0);
        naryadButton.Click += delegate { OpenNaryady(); };
        new ToolTip().SetToolTip(naryadButton, "Номер наряда (или список) - выполнен он или нет");
        row.Controls.Add(naryadButton);
        ssButton.Text = "Сельсоветы ▼";
        ssButton.AutoSize = true;
        ssButton.Margin = new Padding(6, 3, 3, 0);
        ssButton.Click += delegate { ShowSelsovety(); };
        row.Controls.Add(ssButton);
        top.Controls.Add(row);
        Load += delegate { Width = Math.Max(Width, row.PreferredSize.Width + 60 + TextRenderer.MeasureText(Look.SwitchText, Look.Small).Width + 20); };

        queryBox.Font = new Font(Font.FontFamily, 14f);
        queryBox.Location = new Point(12, 38);
        queryBox.Width = top.Width - 24;
        queryBox.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
        queryBox.TextChanged += new EventHandler(OnQueryChanged);
        queryBox.KeyDown += new KeyEventHandler(OnQueryKey);
        ResultColumns.SelectAllKey(queryBox);
        hint.ForeColor = SystemColors.GrayText;
        hint.AutoSize = true;
        hint.Location = new Point(12, 76);
        namesLabel.AutoSize = false;
        namesLabel.TextAlign = ContentAlignment.MiddleRight;
        namesLabel.Size = new Size(460, 20);
        namesLabel.Location = new Point(top.Width - 472, 74);
        namesLabel.Anchor = AnchorStyles.Right | AnchorStyles.Top;
        namesLabel.ForeColor = Look.Info;
        top.Controls.Add(queryBox);
        top.Controls.Add(namesLabel);
        // индекс ФИО: полностью заново - только кнопкой (было - сам раз в сутки, и программа тормозила)
        namesLink.AutoSize = true;
        namesLink.Anchor = AnchorStyles.Right | AnchorStyles.Top;
        namesLink.LinkBehavior = LinkBehavior.HoverUnderline;
        namesLink.Visible = false;
        namesLink.LinkClicked += delegate { NamesClick(); };
        new ToolTip().SetToolTip(namesLink, "Индекс ФИО перечитывает всю базу (минуты; поиск в это время медленнее, но работает).\n" +
            "Новые абоненты добавляются в него сами; «обновить» нужно, только если в базе исправляли Ф.И.О.");
        top.Controls.Add(namesLink);
        top.Resize += delegate { PlaceNames(); };
        top.Controls.Add(hint);

        grid.Dock = DockStyle.Fill;
        grid.VirtualMode = true;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        grid.CellValueNeeded += new DataGridViewCellValueEventHandler(OnCellValueNeeded);
        grid.CellFormatting += new DataGridViewCellFormattingEventHandler(OnCellFormatting);
        grid.CellPainting += new DataGridViewCellPaintingEventHandler(OnCellPainting);
        grid.CellDoubleClick += delegate(object s, DataGridViewCellEventArgs e) { if (e.RowIndex >= 0) OpenCard(e.RowIndex); };
        grid.KeyDown += new KeyEventHandler(OnGridKey);
        CopyText.Grid(grid);

        bottom.Dock = DockStyle.Bottom;
        bottom.Height = 34;
        status.Dock = DockStyle.Fill;
        status.TextAlign = ContentAlignment.MiddleLeft;
        bottom.Controls.Add(status);
        bottom.Controls.Add(BottomButton("В Excel", delegate { ExportResult(null); }));
        bottom.Controls.Add(BottomButton("Отчёт", delegate { OpenReport(); }));
        bottom.Controls.Add(BottomButton("Все таблицы...", delegate { new DbfViewer(this.viewerSettings).Show(); }));
        bottom.Controls.Add(BottomButton("Где искать...", delegate { ChooseBase(); }));
        bottom.Controls.Add(BottomButton("История", delegate { OpenHistory(); }));
        // тема окон - как в «Договоре»: тёмная / светлая, меняется при следующем запуске; справа в первой строке
        LinkLabel theme = Look.Switch(delegate(bool dark) { themeLine = dark ? "тёмная" : "светлая"; SaveSettings(); });
        theme.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        top.Controls.Add(theme);
        top.Resize += delegate { theme.Location = new Point(top.Width - theme.Width - 12, 10); };
        scanButton.Text = "Искать перебором";
        scanButton.Dock = DockStyle.Right;
        scanButton.Width = 150;
        scanButton.Visible = false;
        scanButton.Click += delegate { if (scanning) cancelScan = true; else StartScan(); };
        bottom.Controls.Add(scanButton);

        timer.Interval = 400;
        timer.Tick += delegate { timer.Stop(); StartSearch(); };
        logTimer.Interval = 2000;
        logTimer.Tick += delegate { logTimer.Stop(); LogSearch(); AddHistory(); };

        Controls.Add(grid);
        Controls.Add(bottom);
        Controls.Add(top);

        Shown += delegate { BringUp(); Start(); };
        FormClosing += delegate { cancelScan = true; cancelNames = true; };
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int cmd);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hWnd);

    // Запущенное из свёрнутого или скрытого окна PowerShell окно Windows показывает свёрнутым -
    // разворачиваем и выводим на передний план сами
    void BringUp() {
        try {
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            ShowWindow(Handle, 9);   // SW_RESTORE
            SetForegroundWindow(Handle);
        } catch (Exception) { }
        Activate();
        TopMost = true;
        TopMost = false;
    }

    Button BottomButton(string text, EventHandler click) {
        Button b = new Button();
        b.Text = text;
        b.Dock = DockStyle.Right;
        b.Width = 120;
        b.Click += click;
        return b;
    }

    // найденное - в Excel: те же столбцы, что в списке, цвета строк и примечание, почему строка добавлена;
    // folder - только сохранить файл туда, не открывая Excel (для проверки)
    internal void ExportResult(string folder) {
        SearchResult r = current;
        if (r == null || r.Rows.Count == 0) { MessageBox.Show(this, "Сначала найдите что-нибудь.", Text); return; }
        string[] headers = new string[kinds.Count + 1];
        for (int c = 0; c < kinds.Count; c++) headers[c] = grid.Columns[c].HeaderText;
        headers[kinds.Count] = "Примечание";
        List<string[]> rows = new List<string[]>();
        List<string> styles = new List<string>();
        foreach (int row in r.Rows) {
            string[] v = new string[headers.Length];
            for (int c = 0; c < kinds.Count; c++) v[c] = ResultColumns.Text(r, row, kinds[c]);
            v[kinds.Count] = ResultColumns.NoteText(r, row);
            rows.Add(v);
            styles.Add(ResultColumns.ExcelStyle(r, row));
        }
        try {
            if (folder != null) Spreadsheet.Write(folder, "Поиск_абонента", headers, rows, styles);
            else Spreadsheet.Open("Поиск_абонента", headers, rows, styles);
        }
        catch (Exception ex) { MessageBox.Show(this, "Не удалось выгрузить в Excel:\n" + ex.Message, Text); }
    }

    // из фонового потока - в окно
    void Post(MethodInvoker m) {
        try { if (!IsDisposed) BeginInvoke(m); } catch (Exception) { }
    }

    void PostStatus(string text) {
        Post(delegate { status.Text = text; });
    }

    // адрес, скопированный из Excel, приходит с табуляциями - показываем их пробелами
    void OnQueryChanged(object sender, EventArgs e) {
        string text = queryBox.Text;
        if (text.IndexOf('\t') >= 0 || text.IndexOf('\r') >= 0 || text.IndexOf('\n') >= 0) {
            int caret = queryBox.SelectionStart;
            queryBox.Text = text.Replace("\r\n", " ").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ').TrimEnd();
            queryBox.SelectionStart = Math.Min(caret, queryBox.Text.Length);
            return;   // смена текста вызовет этот обработчик ещё раз
        }
        timer.Stop();
        timer.Start();
    }

    void OnModeChanged(object sender, EventArgs e) {
        RadioButton rb = (RadioButton)sender;
        if (!rb.Checked) return;
        mode = (SearchMode)rb.Tag;
        hint.Text = Hints[(int)mode];
        SaveSettings();
        queryBox.Focus();
        queryBox.SelectAll();
        StartSearch();
    }

    // тема окон для poisk.txt (строка 7): выбранная сейчас или та, что уже записана
    string themeLine;
    string ThemeLine { get { return themeLine ?? (Places.ReadSetting(settingsFile, 6) ?? (Look.Dark ? "тёмная" : "светлая")); } }

    void SaveSettings() {
        if (excelMode) {
            List<string> keep = new List<string>();
            for (int i = 0; i < 6; i++) keep.Add(Places.ReadSetting(settingsFile, i) ?? "");
            keep[2] = ((int)mode).ToString();
            keep.Add(ThemeLine);
            Places.SaveSettings(settingsFile, keep.ToArray());
            return;
        }
        if (folder == null) { if (themeLine != null) SaveTheme(); return; }
        StreetDirectory d = live == null ? null : live.Dir;
        List<string> links = new List<string>();
        if (d != null) foreach (KeyValuePair<string, string> kv in d.Links) links.Add(kv.Key + "=" + kv.Value);
        Places.SaveSettings(settingsFile, new string[] {
            folder, tableName == null ? "" : tableName, ((int)mode).ToString(),
            d == null ? "" : d.TableName, d == null ? "" : d.KeyField, string.Join(";", links.ToArray()), ThemeLine });
    }

    // база ещё не открыта - тему всё равно запомнить (остальные строки - как в файле)
    void SaveTheme() {
        List<string> lines = new List<string>();
        for (int i = 0; i < 6; i++) lines.Add(Places.ReadSetting(settingsFile, i) ?? "");
        lines.Add(themeLine);
        Places.SaveSettings(settingsFile, lines.ToArray());
    }

    void OpenReport() {
        LogSearch();
        if (Report.FilePath == null || !File.Exists(Report.FilePath)) {
            MessageBox.Show(this, "Отчёт не получилось записать (папка программы только для чтения?).", Text);
            return;
        }
        try { Process.Start("notepad.exe", "\"" + Report.FilePath + "\""); }
        catch (Exception ex) { MessageBox.Show(this, "Отчёт лежит здесь:\n" + Report.FilePath + "\n\n" + ex.Message, Text); }
    }

    string lastLogged;

    void LogSearch() {
        logTimer.Stop();
        SearchResult r = current;
        if (r == null) return;
        string line = "Поиск по: " + Prompts[(int)r.Mode] + (r.Partial ? " (частичное совпадение)" : "") + (r.Scanned ? " (перебором)" : "") + "; "
            + (r.NoIndex ? "нет подходящего индекса" : r.How) + (r.Query != null && r.Query.LastExplain.Length > 0 ? "; " + r.Query.LastExplain : "")
            + (r.Note.Length > 0 ? "; " + r.Note : "") + " -> найдено " + r.Searched + (r.Added.Count > 0 ? " (+" + (r.Added.Count - r.Related.Count) + " других тарифов, +" + r.Related.Count + " по адресу/ФИО)" : "") + (r.Hidden > 0 ? ", скрыто (другие сельсоветы) " + r.Hidden : "")
            + (r.TooMany ? ", показана часть" : "") + ", " + r.Seconds.ToString("0.00") + " с";
        if (line == lastLogged) return;
        lastLogged = line;
        Report.Search(line);
    }

    string Dir { get { return Path.GetDirectoryName(Path.GetFullPath(settingsFile)); } }

    void Start() {
        Report.Start(Path.Combine(Dir, "otchet.txt"));
        if (launchInfo != null) Report.Line("Подготовка программы: " + launchInfo);
        // выборка абонентов прошлой версии больше не нужна (в ней были данные абонентов)
        foreach (string old in new string[] { "kesh_abonenty.dbf", "kesh_abonenty.txt", "kesh_abonenty.dbf.tmp" }) {
            try { if (File.Exists(Path.Combine(Dir, old))) File.Delete(Path.Combine(Dir, old)); } catch (Exception) { }
        }
        int saved;
        if (int.TryParse(Places.ReadSetting(settingsFile, 2), out saved) && saved >= 0 && saved < modeButtons.Length) mode = (SearchMode)saved;
        modeButtons[(int)mode].Checked = true;
        hint.Text = Hints[(int)mode];
        queryBox.Focus();
        // меню программ: «Настройки…» -> «Excel-выгрузки» - данные из своей копии выгрузки быта, база не открывается
        if (Istochnik.UseExcel) { OpenExcel(); return; }
        SetBusy(true, "Ищу папку базы...");
        folder = Places.FindFolder(Places.ReadSetting(settingsFile, 0));
        Report.Line("Папка базы: " + folder);
        tableName = Places.ReadSetting(settingsFile, 1);
        if (tableName != null && File.Exists(Path.Combine(folder, tableName))) {
            Report.Line("Таблица абонентов: " + tableName + " (запомнена с прошлого раза)");
        } else {
            tableName = null;
            try {
                List<TableInfo> tables = TableInfo.List(folder, delegate(int done, int total) {
                    if (IsDisposed) throw new OperationCanceledException();
                    status.Text = "Ищу таблицу абонентов: проверено " + done + " из " + total + " таблиц...";
                    Application.DoEvents();
                });
                if (tables.Count > 0 && tables[0].Abonents) tableName = tables[0].Name;
                Report.Line("Таблиц в папке: " + tables.Count + ". Похожие на таблицу абонентов (есть NAB, FIO и DOM или UL):");
                int shown = 0;
                foreach (TableInfo info in tables) if (info.Abonents && shown++ < 10) Report.Line("    " + info);
                if (shown == 0) Report.Line("    таких нет");
                Report.Line("Таблица абонентов: " + (tableName == null ? "не выбрана" : tableName + " (выбрана сама: не архив, больше всех записей)"));
            } catch (OperationCanceledException) {
                return;
            } catch (Exception ex) {
                SetBusy(false, "Не удалось открыть папку " + folder + ": " + ex.Message + "   Нажмите \"Где искать...\".");
                return;
            }
        }
        SetBusy(false, null);
        if (tableName == null) {
            status.Text = "Не нашёл таблицу абонентов в папке " + folder + ". Нажмите \"Где искать...\" и выберите её.";
            return;
        }
        OpenBase();
    }

    // ---- режим Excel: своя копия выгрузки быта (создаётся в меню: «Настройки…» -> «Обновить индексы»), целиком в памяти ----
    internal void OpenExcel() {
        excelMode = true;
        Report.Line("Источник данных: Excel-выгрузка (меню программ, «Настройки…»): " + Istochnik.BytPath);
        string problem = Istochnik.BytCacheProblem();
        if (problem != null) {
            Report.Line("    " + problem);
            status.Text = problem;
            status.ForeColor = Look.Bad;
            return;
        }
        if (opening) return;
        opening = true;
        live = null;
        current = null;
        grid.RowCount = 0;
        SetBusy(true, "Открываю " + Istochnik.BytAbout() + "...");
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            LiveBase b = null;
            string error = null;
            Dictionary<string, bool> sel = null;
            DateTime t0 = DateTime.Now;
            try {
                b = LiveBase.OpenMemory(Istochnik.BytTable, StreetDirectory.FromCopy(Istochnik.BytStreets));
                FieldNames.Excel = VygruzkaByt.Labels();
                sel = LoadSelection(b);
                Report.Line("Выгрузка быта: записей " + b.Mem.Count + ", улиц " + b.Dir.Count + ", прочитана за " + (DateTime.Now - t0).TotalSeconds.ToString("0.0") + " с");
                Report.Line("--- поиски (сами слова не записываются) ---");
            } catch (Exception ex) {
                error = ex.Message;
                Report.Line("ОШИБКА открытия выгрузки: " + ex.Message);
            }
            double seconds = (DateTime.Now - t0).TotalSeconds;
            Post(delegate {
                AfterOpen(b, sel, error == null ? null : error + " (меню программ: «Настройки…» -> «Обновить индексы»)", seconds);
                if (error == null) {
                    baseInfo = Istochnik.BytAbout();
                    status.Text = "Открыта " + baseInfo + " за " + seconds.ToString("0.0") + " с. Наряды, обходы и оплаты в режиме выгрузки не показываются.";
                }
            });
        });
        th.IsBackground = true;
        th.Start();
    }

    // ---- открытие базы: заголовок, индексы и справочники; самих абонентов не читаем ----

    internal void OpenBase() {
        if (opening || tableName == null) return;
        opening = true;
        live = null;
        current = null;
        grid.RowCount = 0;
        string path = Path.Combine(folder, tableName);
        string dirTable = Places.ReadSetting(settingsFile, 3), dirKey = Places.ReadSetting(settingsFile, 4);
        Dictionary<string, string> links = new Dictionary<string, string>();
        string linkLine = Places.ReadSetting(settingsFile, 5);
        if (linkLine != null)
            foreach (string pair in linkLine.Split(';')) {
                int eq = pair.IndexOf('=');
                if (eq > 0) links[pair.Substring(0, eq).Trim().ToUpperInvariant()] = pair.Substring(eq + 1).Trim();
            }
        string table = tableName, dirFolder = folder;
        string namesFile = Path.Combine(Dir, "indeks_fio.dat");
        SetBusy(true, "Открываю базу " + tableName + "...");
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            LiveBase b = null;
            string error = null;
            Dictionary<string, bool> sel = null;
            DateTime t0 = DateTime.Now;
            try {
                b = LiveBase.Open(path);
                b.NamesFile = namesFile;
                double opened = (DateTime.Now - t0).TotalSeconds;
                ReportBase(b);
                PostStatus("Читаю справочники улиц...");
                DateTime t1 = DateTime.Now;
                b.Dir = PrepareDirectory(b, dirFolder, table, dirTable, dirKey, links);
                double dirs = (DateTime.Now - t1).TotalSeconds;
                Report.Line("Время открытия: таблица и индексы - " + opened.ToString("0.0") + " с, справочники - " + dirs.ToString("0.0") + " с");
                sel = LoadSelection(b);
            } catch (Exception ex) {
                error = ex.Message;
                Report.Line("ОШИБКА открытия " + path + ": " + ex.Message);
            }
            double seconds = (DateTime.Now - t0).TotalSeconds;
            Post(delegate { AfterOpen(b, sel, error, seconds); });
            if (error != null) return;
            // индекса по ФИО в базе нет - свой (файл в папке программы): прочитать, дочитать новое или построить в фоне
            try { if (b.NamesNeeded) Post(delegate { StartNames(b); }); }
            catch (Exception ex) { Report.Line("Свой индекс ФИО: " + ex.Message); }
            // тарифы (T1, T2...) и доп. сведения - уже когда окно работает: искать можно сразу
            DateTime t2 = DateTime.Now;
            try { b.Extra = ExtraInfo.Open(dirFolder); }
            catch (Exception ex) { Report.Line("Тарифы и доп. сведения не прочитались: " + ex.Message); }
            Report.Line("Тарифы и доп. сведения прочитаны в фоне за " + (DateTime.Now - t2).TotalSeconds.ToString("0.0") + " с");
            Post(delegate { ExtraReady(b); });
            // заранее проверяем индексы по нужным полям - итог в отчёт
            try {
                b.VerifyMain();
                Report.Line("Проверка индексов (ищем по индексу записи из разных мест таблицы):");
                foreach (IndexTag t in b.Tags)
                    if (t.State != 0 || t.Check.Length > 0) Report.Line("    " + t.Label + ": " + t.Check + (t.Learned.Length > 0 ? "; " + t.Learned : ""));
                string learned = b.WeightsReport();
                if (learned.Length > 0) Report.Line(learned);
                if (b.Extra != null)
                    foreach (LiveBase x in b.Extra.Tables) {
                        IndexTag t = x.TagFor("NAB");
                        Report.Line("    доп. сведения " + Path.GetFileName(x.FilePath) + ": индекс по NAB - "
                            + (t == null ? "нет подходящего" : t.Label + ": " + t.Check + (t.Learned.Length > 0 ? "; " + t.Learned : "")));
                    }
                Report.Line("Чем ищется: лицевой - " + TagName(b, "NAB", false) + ", Л/С ЕРИП - " + TagName(b, "LS_ERIP", false)
                    + ", счётчик - " + TagName(b, "NCH", false) + ", снятый счётчик - " + TagName(b, "NSC", false)
                    + ", ФИО - " + (b.NamesNeeded ? "в базе индекса нет - свой индекс indeks_fio.dat" : TagName(b, "FIO", false)) + ", адрес - " + TagName(b, "UL", true));
                Report.Line("--- поиски (сами слова не записываются) ---");
            } catch (Exception ex) {
                Report.Line("Проверка индексов прервалась: " + ex.Message);
            }
        });
        th.IsBackground = true;
        th.Start();
    }

    static string TagName(LiveBase b, string field, bool preferLong) {
        if (b.Header.FieldIndex(field) < 0) return "нет поля";
        IndexTag t = b.TagFor(field, preferLong);
        return t == null ? "нет индекса (только перебором)" : t.Label;
    }

    void ReportBase(LiveBase b) {
        long size = 0;
        try { size = new FileInfo(b.FilePath).Length; } catch (Exception) { }
        Report.Line("Таблица абонентов " + Path.GetFileName(b.FilePath) + ": записей по заголовку " + b.Header.Expected + ", длина записи "
            + b.Header.RecordLength + " байт, файл " + (size / 1048576.0).ToString("0") + " МБ");
        Report.Line("Поля (по первым " + b.Sample.Count + " записям):");
        Report.Fields(b.Sample, "    ");
        List<string> files = b.IndexFiles;
        Report.Line("Индексных файлов (.CDX, .IDX) в папке: " + files.Count + (files.Count > 0 ? ": " + string.Join(", ", files.GetRange(0, Math.Min(files.Count, 80)).ToArray())
            + (files.Count > 80 ? "..." : "") : ""));
        Report.Line("Индексы, подходящие к таблице " + Path.GetFileName(b.FilePath) + " (" + b.Tags.Count + "):");
        if (b.Tags.Count == 0) Report.Line("    нет - поиск возможен только перебором всей таблицы");
        foreach (IndexTag t in b.Tags) {
            StringBuilder sb = new StringBuilder("    " + t.Label + (t.Structural ? " (свой .CDX)" : "") + "  ключ: " + t.Expr
                + "  (длина " + t.KeyLen + ", тип " + t.KeyType + (t.Compact ? "" : ", обычный .IDX") + (t.Descending ? ", по убыванию" : "") + ")");
            if (t.ForText != null) sb.Append("  FOR " + t.ForText);
            if (t.Collated) sb.Append("  сортировка " + t.Collation);
            if (t.Problem != null) sb.Append("  - не годится: " + t.Problem);
            else {
                List<string> fields = new List<string>();
                foreach (string f in t.TermFields) fields.Add(f == null ? "?" : f);
                sb.Append("  -> поля " + string.Join("+", fields.ToArray()));
            }
            Report.Line(sb.ToString());
        }
    }

    // Справочник улиц: запомненный с прошлого раза или ищем по кодам улиц из начала базы
    StreetDirectory PrepareDirectory(LiveBase b, string dirFolder, string table, string savedTable, string savedKey, Dictionary<string, string> links) {
        int ul = b.Header.FieldIndex("UL");
        if (ul < 0) { Report.Line("Поля UL (улица) в таблице нет - справочник улиц не нужен"); return null; }
        if (savedTable != null && savedKey != null && File.Exists(Path.Combine(dirFolder, savedTable))) {
            try {
                Report.Line("Справочник улиц с прошлого раза: " + savedTable + "." + savedKey);
                StreetDirectory d = StreetDirectory.Load(dirFolder, savedTable, savedKey, links);
                if (d != null && d.Count > 0 && (d.HasTowns || d.Selsovety.Count > 0)) return d;
                Report.Line("    в нём нет населённых пунктов и сельсоветов - ищу справочник заново");
            } catch (Exception ex) {
                Report.Line("    не открылся: " + ex.Message);
            }
        }
        // коды улиц - из записей по всей таблице (в начале таблицы улиц мало)
        PostStatus("Смотрю, как записаны улицы...");
        DbfTable sample = b.SpreadSample(300);
        List<string> codes = StreetDirectory.Codes(sample, sample.FieldIndex("UL"));
        if (codes == null) return null;
        Report.Line("Ищу справочник улиц среди таблиц папки:");
        try {
            return StreetDirectory.Detect(dirFolder, table, codes, delegate(int done, int total) {
                PostStatus("В поле улицы - коды. Ищу справочник улиц: проверено " + done + " из " + total + " таблиц...");
            });
        } catch (Exception ex) {
            Report.Line("    ошибка: " + ex.Message);
            return null;
        }
    }

    void AfterOpen(LiveBase b, Dictionary<string, bool> sel, string error, double seconds) {
        opening = false;
        SetBusy(false, null);
        if (error != null) {
            status.Text = "Не удалось открыть " + Path.Combine(folder, tableName) + ": " + error + "   Нажмите \"Где искать...\".";
            return;
        }
        live = b;
        baseInfo = tableName + ", " + b.Header.Expected.ToString("#,0") + " записей";
        selected = sel;
        UpdateSsButton();
        SaveSettings();
        BuildColumns();
        status.Text = "База открыта за " + seconds.ToString("0.0") + " с.";
        if (DbfTable.SplitWords(queryBox.Text).Length > 0) StartSearch();
        else UpdateStatus();
    }

    // тарифы и доп. сведения дочитаны: появляются столбцы "Т" и "Мощность", найденное ищется заново
    void ExtraReady(LiveBase b) {
        if (b != live || b.Extra == null) return;
        BuildColumns();
        if (current != null && DbfTable.SplitWords(queryBox.Text).Length > 0) StartSearch();
        else Show(current);
    }

    void SetBusy(bool busy, string text) {
        foreach (Control c in bottom.Controls) if (c is Button && c != scanButton) c.Enabled = !busy;
        Cursor = busy ? Cursors.AppStarting : Cursors.Default;
        if (text != null) { status.Text = text; status.Refresh(); }
    }

    AbonentQuery columns;

    List<int> kinds = new List<int>();

    void BuildColumns() {
        columns = new AbonentQuery(DbfTable.CreateLike(live.Header), live.Dir);
        kinds = ResultColumns.Kinds(columns, live.Extra);
        grid.RowCount = 0;
        grid.Columns.Clear();
        foreach (int k in kinds) {
            DataGridViewTextBoxColumn c = new DataGridViewTextBoxColumn();
            c.HeaderText = ResultColumns.Title(columns, k);
            c.SortMode = DataGridViewColumnSortMode.NotSortable;
            c.FillWeight = ResultColumns.Weight(live.Header, k);
            grid.Columns.Add(c);
        }
    }

    // ---- поиск (в фоне, чтобы окно не замирало, пока читается сеть) ----

    internal void StartSearch() {
        timer.Stop();
        if (live == null) return;
        if (scanning) { cancelScan = true; again = true; return; }
        if (searching) { again = true; return; }
        string text = queryBox.Text;
        if (DbfTable.SplitWords(text).Length == 0) { Show(null); return; }
        if (!cardWhenDone && !EnoughTyped(text, mode)) { Show(null); status.Text = "Впишите дальше или нажмите Enter."; return; }
        searching = true;
        SearchMode m = mode;
        Dictionary<string, bool> ss = selected;
        LiveBase b = live;
        bool partial = partialBox.Checked;
        status.Text = "Ищу...";
        Cursor = Cursors.AppStarting;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            SearchResult r = b.Search(text, m, ss, partial);
            Post(delegate { SearchDone(r, b); });
        });
        th.IsBackground = true;
        th.Start();
    }

    // пока набирается одна-две буквы, не ищем (иначе по сети читается очень много лишнего)
    static bool EnoughTyped(string text, SearchMode m) {
        int digits = 0, letters = 0;
        foreach (char c in text) { if (char.IsDigit(c)) digits++; else if (char.IsLetter(c)) letters++; }
        switch (m) {
            case SearchMode.Account: return digits >= 4;
            case SearchMode.Meter: return digits + letters >= 4;
            case SearchMode.Name: return letters >= 3;
            default: return letters >= 3;
        }
    }

    void SearchDone(SearchResult r, LiveBase b) {
        searching = false;
        Cursor = Cursors.Default;
        if (b != live) return;
        if (again || r.Text != queryBox.Text || r.Mode != mode || r.Partial != partialBox.Checked) { again = false; StartSearch(); return; }
        Show(r);
        if (cardWhenDone) {
            cardWhenDone = false;
            LogSearch();
            // нашёлся один (кроме добавленных тарифов того же счётчика) - сразу его карточка
            if (r.Searched == 1) { for (int i = 0; i < r.Rows.Count; i++) if (!r.Added.ContainsKey(r.Rows[i])) { grid.CurrentCell = grid.Rows[i].Cells[0]; OpenCard(i); break; } }
            else if (r.Rows.Count > 0) grid.Focus();
        }
    }

    internal void StartScan() {
        if (live == null || searching || scanning) return;
        string text = queryBox.Text;
        if (DbfTable.SplitWords(text).Length == 0) return;
        scanning = true;
        cancelScan = false;
        scanButton.Text = "Остановить перебор";
        SearchMode m = mode;
        Dictionary<string, bool> ss = selected;
        LiveBase b = live;
        bool partial = partialBox.Checked;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            SearchResult r = null;
            DateTime started = DateTime.Now;
            int shown = -1;
            try {
                r = b.Scan(text, m, ss, delegate(int done, int expected) {
                    if (cancelScan) throw new OperationCanceledException();
                    int pct = (int)(done * 100L / Math.Max(expected, 1));
                    if (pct == shown) return;
                    shown = pct;
                    double spent = (DateTime.Now - started).TotalSeconds;
                    string left = pct > 0 ? ", осталось примерно " + Math.Max(1, (int)(spent * (100 - pct) / pct / 60)) + " мин" : "";
                    PostStatus("Перебираю всю базу: " + pct + "%" + left + "...   Можно остановить кнопкой справа.");
                }, partial);
            } catch (OperationCanceledException) {
                r = null;
            } catch (Exception ex) {
                r = new SearchResult();
                r.Text = text;
                r.Mode = m;
                r.Error = ex.Message;
            }
            Post(delegate { ScanDone(r, b); });
        });
        th.IsBackground = true;
        th.Start();
    }

    // Свой индекс по ФИО: прочитать файл; нет его, недостроен или старше суток - (до)строить в фоне.
    // Поиск при этом работает; по ФИО до готовности индекса - только с адресом ("Иванов Боровляны").
    // индекс ФИО при открытии базы: готовый - рабочий сразу, новые абоненты дочитываются (только конец таблицы);
    // нет / недостроен - строится только по кнопке «построить» («Поиск» больше ничего тяжёлого сам не запускает)
    void StartNames(LiveBase b) {
        if (buildingNames || b != live) return;
        buildingNames = true;
        NamesLabel("Индекс ФИО: открываю...", false, null);
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            string error = null;
            NameIndex todo = null;
            int added = 0;
            try {
                todo = b.OpenNames();
                if (b.NamesReady) {
                    Post(delegate { if (b == live) NamesReadyLabel(b, ""); });
                    added = b.CatchUpNames();
                }
            } catch (Exception ex) {
                error = ex.Message;
                Report.Line("Свой индекс ФИО не открылся: " + ex.GetType().Name + ": " + ex.Message);
            }
            Post(delegate {
                buildingNames = false;
                if (b != live) return;
                if (added > 0) Report.Line("Свой индекс ФИО: дочитано новых записей " + added);
                namesTodo = b.NamesReady ? null : todo;
                if (error != null) NamesLabel("Индекс ФИО: ошибка - " + error, true, "построить");
                else NamesState(b);
                if (b.NamesReady && mode == SearchMode.Name && DbfTable.SplitWords(queryBox.Text).Length > 0 && !searching && (current == null || current.NoIndex)) StartSearch();
                else UpdateStatus();
            });
        });
        th.IsBackground = true;
        th.Start();
    }

    // надпись и кнопка по состоянию индекса
    void NamesState(LiveBase b) {
        if (b.NamesReady) { NamesReadyLabel(b, ""); return; }
        if (namesTodo != null && namesTodo.Scanned > 0 && namesTodo.Total > 0)
            NamesLabel("Индекс ФИО: построен на " + (int)(namesTodo.Scanned * 100L / Math.Max(namesTodo.Total, 1)) + "%", true, "достроить");
        else NamesLabel("Индекс ФИО: не построен (нужен для поиска по ФИО)", true, "построить");
    }

    void NamesReadyLabel(LiveBase b, string extra) {
        DateTime t = b.NamesBuilt;
        NamesLabel("Индекс ФИО: готов" + (t > DateTime.MinValue ? " (собран " + t.ToString("dd.MM.yyyy") + ")" : "") + extra, false, "обновить");
    }

    void NamesClick() {
        LiveBase b = live;
        if (b == null) return;
        if (buildingNames) { cancelNames = true; namesLink.Enabled = false; return; }
        BuildNamesNow(b, b.NamesReady || namesTodo == null ? b.NewNames() : namesTodo);
    }

    // (до)строить в фоне; уступает поискам (идёт поиск - ждёт) и не гонит диск без передышки
    void BuildNamesNow(LiveBase b, NameIndex todo) {
        if (buildingNames || b != live) return;
        buildingNames = true;
        cancelNames = false;
        namesPercent = 0;
        namesLeft = "";
        bool update = b.NamesReady;
        NamesLabel(update ? "Индекс ФИО: обновляется..." : "Индекс ФИО: строится...", false, "остановить");
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            string error = null;
            try {
                DateTime started = DateTime.Now;
                int from = todo.Scanned, shown = -1;
                b.BuildNames(todo, delegate(int done, int expected) {
                    if (cancelNames || b != live) throw new OperationCanceledException();
                    while (LiveBase.Searching && !cancelNames) System.Threading.Thread.Sleep(50);
                    System.Threading.Thread.Sleep(15);
                    int pct = (int)(done * 100L / Math.Max(expected, 1));
                    if (pct == shown) return;
                    shown = pct;
                    double spent = (DateTime.Now - started).TotalSeconds;
                    string left = done - from > 0 && spent > 3 ? TimeLeft(spent * (expected - done) / (done - from)) : "";
                    Post(delegate {
                        namesPercent = pct;
                        namesLeft = left;
                        NamesLabel((update ? "Индекс ФИО: готов, обновляется " : "Индекс ФИО: строится ") + pct + "%" + (left.Length > 0 ? ", осталось ~" + left : ""), false, "остановить");
                        if (mode == SearchMode.Name && !searching && (current == null || current.NoIndex)) UpdateStatus();
                    });
                }, !update);
            } catch (OperationCanceledException) {
                Report.Line("Свой индекс ФИО: сборку остановили");
            } catch (Exception ex) {
                error = ex.Message;
                Report.Line("Свой индекс ФИО не построился: " + ex.GetType().Name + ": " + ex.Message);
            }
            Post(delegate {
                buildingNames = false;
                namesLink.Enabled = true;
                if (b != live) return;
                // остановили первую сборку - недостроенное сохранено, «достроить» продолжит с того же места
                namesTodo = b.NamesReady ? null : todo;
                if (error != null) NamesLabel("Индекс ФИО: ошибка - " + error, true, b.NamesReady ? "обновить" : "построить");
                else NamesState(b);
                if (mode == SearchMode.Name && DbfTable.SplitWords(queryBox.Text).Length > 0 && !searching) StartSearch();
                else UpdateStatus();
            });
        });
        th.IsBackground = true;
        th.Priority = System.Threading.ThreadPriority.BelowNormal;
        th.Start();
    }

    // для проверки
    internal string NamesText { get { return namesLabel.Text + (namesLink.Visible ? " [" + namesLink.Text + "]" : ""); } }
    internal void NamesButton() { NamesClick(); }
    internal bool NamesBusy { get { return buildingNames; } }
    internal bool SearchBusy { get { return searching; } }

    void PlaceNames() {
        Control top = namesLabel.Parent;
        if (top == null) return;
        int right = top.ClientSize.Width - 12;
        if (namesLink.Visible) { namesLink.Location = new Point(right - namesLink.Width, 76); right = namesLink.Left - 4; }
        namesLabel.SetBounds(right - 460, 74, 460, 20);
    }

    void NamesLabel(string text, bool problem, string action) {
        namesLabel.Text = text;
        namesLabel.ForeColor = problem ? Look.Bad : Look.Info;
        namesLink.Visible = action != null;
        if (action != null) namesLink.Text = action;
        PlaceNames();
    }

    static string TimeLeft(double seconds) {
        return seconds < 60 ? Math.Max(5, (int)(seconds / 5) * 5) + " с" : Math.Max(1, (int)Math.Round(seconds / 60)) + " мин";
    }

    void ScanDone(SearchResult r, LiveBase b) {
        scanning = false;
        scanButton.Text = "Искать перебором";
        if (b != live) return;
        if (again) { again = false; StartSearch(); return; }
        if (r == null) { UpdateStatus(); return; }
        Show(r);
    }

    void Show(SearchResult r) {
        current = r;
        grid.RowCount = 0;
        grid.RowCount = r == null ? 0 : r.Rows.Count;
        grid.Invalidate();
        scanButton.Visible = scanning || (r != null && r.NoIndex);
        logTimer.Stop();
        if (r != null) logTimer.Start();
        UpdateStatus();
    }

    string HistoryFile { get { return Path.Combine(Dir, "istoriya.txt"); } }

    // поиск - в историю (30 последних): что искали и найденные строки, как в списке
    internal void AddHistory() {
        SearchResult r = current;
        if (r == null || r.Error != null || DbfTable.SplitWords(r.Text ?? "").Length == 0) return;
        try {
            SearchHistory.Entry e = new SearchHistory.Entry();
            e.When = DateTime.Now;
            e.Mode = (int)r.Mode;
            e.Query = r.Text;
            e.Found = r.Rows.Count == 0 ? "не найдено" : r.Searched + (r.Added.Count > 0 ? " (+" + r.Added.Count + ")" : "");
            string[] titles = new string[grid.Columns.Count];
            for (int c = 0; c < titles.Length; c++) titles[c] = grid.Columns[c].HeaderText;
            e.Titles = titles;
            for (int i = 0; i < r.Rows.Count && i < SearchHistory.RowsPerSearch; i++) {
                string[] cells = new string[kinds.Count];
                for (int c = 0; c < kinds.Count; c++) { object v = ResultColumns.Text(r, r.Rows[i], kinds[c]); cells[c] = v == null ? "" : v.ToString(); }
                e.Rows.Add(cells);
            }
            SearchHistory.Add(HistoryFile, e);
        } catch (Exception ex) { Report.Line("История поисков не записалась: " + ex.Message); }
    }

    internal HistoryForm LastHistory;

    internal void OpenHistory() {
        LogSearch();
        AddHistory();
        string[] titles = new string[grid.Columns.Count];
        for (int c = 0; c < titles.Length; c++) titles[c] = grid.Columns[c].HeaderText;
        HistoryForm h = new HistoryForm(HistoryFile, titles);
        h.OnRepeat = delegate(int m, string q) {
            if (m >= 0 && m < modeButtons.Length) modeButtons[m].Checked = true;
            queryBox.Text = q;
            StartSearch();
        };
        LastHistory = h;
        h.Show(this);
    }

    void UpdateStatus() {
        if (live == null) return;
        string where = "База: " + baseInfo;
        if (selected != null) where += ", сельсоветов выбрано " + selected.Count + " из " + live.Dir.Selsovety.Count;
        SearchResult r = current;
        string took = r == null ? "" : "   (" + r.Seconds.ToString("0.0") + " с)";
        // как понят адрес: "аг. Боровляны -> Заводская ул. -> дом 18"
        if (r != null && r.Address != null && r.Address.Said.Length > 0) took = "   Искал: " + r.Address.Said + "." + took;
        string tip = r != null && !r.Partial && r.Mode != SearchMode.Address ? " Нужны и похожие номера - поставьте галочку \"Частичное совпадение\"." : "";
        string building = buildingNames && !live.NamesReady
            ? "Строю свой индекс по ФИО (это один раз, дальше по ФИО будет искаться сразу): " + namesPercent + "%"
              + (namesLeft.Length > 0 ? ", осталось примерно " + namesLeft : "") + ". Пока по ФИО ищется только с адресом: \"Иванов Боровляны\"; остальной поиск работает."
            : null;
        if (r == null && mode == SearchMode.Name && building != null)
            status.Text = building;
        else if (r == null)
            status.Text = "Впишите " + Prompts[(int)mode] + ".   " + where;
        else if (r.Error != null)
            status.Text = "Ошибка при поиске: " + r.Error + "   Нажмите \"Отчёт\" и пришлите его.";
        else if (r.NoIndex && r.Mode == SearchMode.Name && building != null)
            status.Text = building;
        else if (r.NoIndex && r.Mode == SearchMode.Name && live.NamesNeeded && !live.NamesReady)
            status.Text = "Индекс ФИО не построен - справа вверху \"" + namesLink.Text + "\" (один раз, минут 5-10; остальной поиск в это время работает). Или допишите населённый пункт: \"Иванов Боровляны\" - найдётся сразу.";
        else if (r.NoIndex && r.Mode == SearchMode.Name)
            status.Text = "Допишите населённый пункт или улицу: \"Иванов Боровляны\" - тогда найдётся сразу. По одной фамилии - только перебором всей базы (кнопка справа, это долго): индекса по ФИО в базе нет.";
        else if (r.NoIndex)
            status.Text = "Для поиска по полю \"" + Prompts[(int)r.Mode] + "\" в базе нет подходящего индекса. Можно искать перебором всей базы - это долго (минуты). Кнопка справа.";
        else if (r.Note.Length > 0 && r.Rows.Count == 0)
            status.Text = r.Note + "   " + where;
        else if (r.Rows.Count == 0)
            status.Text = (r.Hidden > 0 ? "В выбранных сельсоветах не найдено, а в других нашлось: " + r.Hidden + " - отметьте их в списке \"Сельсоветы\"."
                : "Ничего не найдено. " + (!r.TooMany && r.Query != null ? r.Query.Miss : "") + tip) + took + "   " + where;
        else
            status.Text = "Найдено: " + r.Searched + (r.TooMany ? " (нашлось очень много, показана часть - уточните запрос)" : "")
                + (r.Added.Count - r.Related.Count > 0 ? ", ещё " + (r.Added.Count - r.Related.Count) + " - другие тарифы тех же счётчиков" : "")
                + (r.Related.Count > 0 ? ", ещё " + r.Related.Count + " - на том же адресе или с тем же ФИО в доме" : "")
                + (r.Added.Count > 0 ? " (их номер красным)" : "")
                + (r.Hidden > 0 ? ", ещё " + r.Hidden + " в других сельсоветах скрыто" : "")
                + ". Enter или двойной щелчок - карточка." + took + "   " + where;
    }

    void OnCellValueNeeded(object sender, DataGridViewCellValueEventArgs e) {
        SearchResult r = current;
        if (r == null || e.RowIndex >= r.Rows.Count || e.ColumnIndex >= kinds.Count) return;
        e.Value = ResultColumns.Text(r, r.Rows[e.RowIndex], kinds[e.ColumnIndex]);
    }

    string GroupAt(int i) {
        SearchResult r = current;
        return r == null || i < 0 || i >= r.Rows.Count ? null : r.GroupOf(r.Rows[i]);
    }

    void OnCellPainting(object sender, DataGridViewCellPaintingEventArgs e) {
        if (e.RowIndex < 0) return;
        ResultColumns.PaintGroup(grid, e, GroupAt(e.RowIndex - 1), GroupAt(e.RowIndex), GroupAt(e.RowIndex + 1));
    }

    // лицевые тарифов (T1, T2...) - зеленоватым; не искавшиеся тарифы того же счётчика - номер красным
    void OnCellFormatting(object sender, DataGridViewCellFormattingEventArgs e) {
        SearchResult r = current;
        if (r == null || e.RowIndex < 0 || e.RowIndex >= r.Rows.Count || e.ColumnIndex >= kinds.Count) return;
        ResultColumns.Format(r, r.Rows[e.RowIndex], kinds[e.ColumnIndex], e.CellStyle);
    }

    void OnQueryKey(object sender, KeyEventArgs e) {
        if (e.KeyCode == Keys.Enter) {
            e.Handled = true;
            e.SuppressKeyPress = true;
            cardWhenDone = true;
            StartSearch();
        } else if (e.KeyCode == Keys.Down && current != null && current.Rows.Count > 0) {
            e.Handled = true;
            grid.Focus();
        }
    }

    void OnGridKey(object sender, KeyEventArgs e) {
        if (e.KeyCode == Keys.Enter && grid.CurrentCell != null) {
            e.Handled = true;
            e.SuppressKeyPress = true;
            OpenCard(grid.CurrentCell.RowIndex);
        }
    }

    internal void OpenCard(int index) {
        SearchResult r = current;
        if (r == null || index < 0 || index >= r.Rows.Count) return;
        int pos = index;
        // PgUp/PgDn в карточке - соседний абонент этого же списка
        CardMove move = delegate(int delta, out SearchResult rr, out int row) {
            rr = null;
            row = -1;
            if (current != r || pos + delta < 0 || pos + delta >= r.Rows.Count) return false;
            pos += delta;
            rr = r;
            row = r.Rows[pos];
            if (pos < grid.RowCount) grid.CurrentCell = grid.Rows[pos].Cells[0];
            return true;
        };
        ResultColumns.ShowCard(this, r, r.Rows[index], live, move);
    }

    // ---- сельсоветы: выпадающий список с галочками, только отбирает показанное ----

    string SelsovetyFile { get { return Path.Combine(Dir, "selsovety.txt"); } }

    // список сельсоветов из файла selsovety.txt (если его нет - ваши шесть)
    string[] ReadSelsovety() {
        string file = SelsovetyFile;
        if (!File.Exists(file)) return DefaultSelsovety;
        List<string> names = new List<string>();
        try {
            foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
                string n = line.Trim();
                if (n.Length > 0 && !n.StartsWith("#")) names.Add(n);
            }
        } catch (Exception) {
            return DefaultSelsovety;
        }
        return names.ToArray();
    }

    void SaveSelsovety(ICollection<string> names) {
        List<string> lines = new List<string>();
        lines.Add("# Сельсоветы, абоненты которых показываются в поиске - по одному в строке (пусто - все)");
        lines.AddRange(names);
        Places.SaveSettings(SelsovetyFile, lines.ToArray());
    }

    // названия из файла -> сельсоветы справочника ("Боровлянский" находит "Боровлянский с/с")
    Dictionary<string, bool> LoadSelection(LiveBase b) {
        if (b.Dir == null) return null;
        List<string> all = b.Dir.Selsovety;
        string[] wanted = ReadSelsovety();
        Dictionary<string, bool> sel = new Dictionary<string, bool>();
        List<string> missing = new List<string>();
        foreach (string w in wanted) {
            string stem = StreetDirectory.Stem(w);
            bool hit = false;
            foreach (string name in all) {
                string l = name.ToLowerInvariant();
                if (stem.Length > 0 && (l.Contains(stem) || stem.Contains(StreetDirectory.Stem(name)))) { sel[name] = true; hit = true; }
            }
            if (!hit) missing.Add(w);
        }
        Report.Line("Сельсоветы в справочниках (" + all.Count + "): " + string.Join(", ", all.ToArray()));
        Report.Line("Выбраны для показа: " + (sel.Count == 0 || sel.Count == all.Count ? "все" : string.Join(", ", new List<string>(sel.Keys).ToArray()))
            + (missing.Count > 0 ? "; не нашлись в справочниках: " + string.Join(", ", missing.ToArray()) : ""));
        if (sel.Count == 0 || sel.Count == all.Count) return null;
        return sel;
    }

    void UpdateSsButton() {
        if (live == null || live.Dir == null || live.Dir.Selsovety.Count == 0) {
            ssButton.Text = "Сельсоветы ▼";
            return;
        }
        int total = live.Dir.Selsovety.Count;
        ssButton.Text = selected == null ? "Сельсоветы: все ▼" : "Сельсоветы: " + selected.Count + " из " + total + " ▼";
    }

    internal void ShowSelsovety() {
        if (live == null) { MessageBox.Show(this, "Подождите, пока откроется база.", Text); return; }
        if (live.Dir == null || live.Dir.Selsovety.Count == 0) {
            MessageBox.Show(this, "В справочниках улиц не нашлось сельсоветов - отбирать не по чему. Нажмите \"Отчёт\" и пришлите его.", Text);
            return;
        }
        List<string> all = live.Dir.Selsovety;
        ToolStripDropDown dd = new ToolStripDropDown();
        Panel panel = new Panel();
        panel.Font = Font;
        CheckedListBox list = new CheckedListBox();
        list.Font = Font;
        list.CheckOnClick = true;
        list.IntegralHeight = false;
        foreach (string name in all) list.Items.Add(name, selected == null || selected.ContainsKey(name));
        int listHeight = Math.Min(all.Count, 20) * list.ItemHeight + 6;
        int width = 240;
        foreach (string name in all) width = Math.Max(width, TextRenderer.MeasureText(name, Font).Width + 50);
        list.Location = new Point(0, 0);
        list.Size = new Size(width, listHeight);
        Button allButton = new Button();
        allButton.Font = Font;
        allButton.Text = "Все";
        allButton.Location = new Point(4, listHeight + 4);
        allButton.Size = new Size(80, 26);
        Button noneButton = new Button();
        noneButton.Font = Font;
        noneButton.Text = "Снять все";
        noneButton.Location = new Point(90, listHeight + 4);
        noneButton.Size = new Size(100, 26);
        panel.Size = new Size(width, listHeight + 34);
        panel.Controls.Add(list);
        panel.Controls.Add(allButton);
        panel.Controls.Add(noneButton);
        bool bulk = false;
        list.ItemCheck += delegate { if (!bulk) BeginInvoke(new MethodInvoker(delegate { ApplySelection(list); })); };
        EventHandler setAll = delegate(object s, EventArgs e) {
            bulk = true;
            for (int i = 0; i < list.Items.Count; i++) list.SetItemChecked(i, s == allButton);
            bulk = false;
            ApplySelection(list);
        };
        allButton.Click += setAll;
        noneButton.Click += setAll;
        ToolStripControlHost host = new ToolStripControlHost(panel);
        host.Margin = Padding.Empty;
        host.Padding = Padding.Empty;
        host.AutoSize = false;
        host.Size = panel.Size;
        dd.Padding = Padding.Empty;
        dd.Items.Add(host);
        dd.BackColor = Look.Back;
        Look.Dress(panel);
        dd.Show(ssButton, new Point(0, ssButton.Height));
        list.Focus();
    }

    void ApplySelection(CheckedListBox list) {
        List<string> names = new List<string>();
        foreach (object item in list.CheckedItems) names.Add((string)item);
        Dictionary<string, bool> sel = new Dictionary<string, bool>();
        foreach (string n in names) sel[n] = true;
        selected = sel.Count == 0 || sel.Count == list.Items.Count ? null : sel;
        SaveSelsovety(names);
        UpdateSsButton();
        Report.Search("Сельсоветы для показа: " + (selected == null ? "все" : string.Join(", ", names.ToArray())));
        if (current != null) StartSearch(); else UpdateStatus();
    }

    internal BatchSearch LastBatch;

    internal void OpenBatch() {
        if (live == null) {
            MessageBox.Show(this, "Подождите, пока откроется база.", Text);
            return;
        }
        LastBatch = new BatchSearch(live, selected, mode, columns, kinds);
        LastBatch.Show(this);
    }

    internal NaryadForm LastNaryad;

    // окно нарядов: по номеру - выполнен или нет (таблица нарядов - в папке базы)
    internal void OpenNaryady() {
        if (excelMode) {
            MessageBox.Show(this, "Сейчас данные берутся из Excel-выгрузки (меню программ: «Настройки…»).\n\n" +
                (Istochnik.Missing("нарядов", Istochnik.NaryadyPath) ?? "Наряды из выгрузки нарядов подключим, когда будет образец выгрузки."), Text);
            return;
        }
        if (folder == null || !Directory.Exists(folder)) {
            MessageBox.Show(this, "Папка базы не найдена. Нажмите \"Где искать...\" и выберите её.", Text);
            return;
        }
        if (LastNaryad != null && !LastNaryad.IsDisposed) { LastNaryad.Activate(); return; }
        LastNaryad = new NaryadForm(Dir, folder, live);
        LastNaryad.Show(this);
    }

    // Выбор папки и таблицы абонентов, если сама не нашлась или нашлась не та
    void ChooseBase() {
        if (excelMode) {
            MessageBox.Show(this, "Сейчас данные берутся из Excel-выгрузки: " + Istochnik.BytPath + "\n\nПоменять файл или вернуться к базе - меню программ: «Настройки…» (потом закройте и откройте «Поиск»).", Text);
            return;
        }
        Form d = new Form();
        d.Font = Look.Base;
        Look.Wear(d);
        d.Text = "Где искать абонентов";
        d.Size = new Size(560, 420);
        d.StartPosition = FormStartPosition.CenterParent;
        d.MinimizeBox = false;
        d.MaximizeBox = false;

        TextBox folderBox = new TextBox();
        folderBox.Text = folder;
        folderBox.Location = new Point(12, 30);
        folderBox.Width = 330;
        Button browse = new Button();
        browse.Text = "Обзор...";
        browse.Location = new Point(350, 28);
        Button show = new Button();
        show.Text = "Показать";
        show.Location = new Point(430, 28);
        Label l1 = new Label();
        l1.Text = "Папка с таблицами базы:";
        l1.AutoSize = true;
        l1.Location = new Point(12, 10);
        Label l2 = new Label();
        l2.Text = "Таблица абонентов (подходящие - вверху):";
        l2.AutoSize = true;
        l2.Location = new Point(12, 62);
        ListBox list = new ListBox();
        list.Location = new Point(12, 82);
        list.Size = new Size(520, 250);
        Button ok = new Button();
        ok.Text = "OK";
        ok.Location = new Point(370, 345);
        ok.DialogResult = DialogResult.OK;
        Button cancel = new Button();
        cancel.Text = "Отмена";
        cancel.Location = new Point(455, 345);
        cancel.DialogResult = DialogResult.Cancel;
        d.AcceptButton = ok;
        d.CancelButton = cancel;
        d.Controls.AddRange(new Control[] { l1, folderBox, browse, show, l2, list, ok, cancel });

        EventHandler fill = delegate {
            list.Items.Clear();
            d.Cursor = Cursors.WaitCursor;
            try {
                foreach (TableInfo info in TableInfo.List(folderBox.Text.Trim(), null)) {
                    list.Items.Add(info);
                    if (string.Compare(info.Name, tableName, StringComparison.OrdinalIgnoreCase) == 0) list.SelectedItem = info;
                }
                if (list.SelectedIndex < 0 && list.Items.Count > 0) list.SelectedIndex = 0;
            } catch (Exception ex) {
                MessageBox.Show(d, "Не удалось открыть папку:\n" + ex.Message, d.Text);
            } finally {
                d.Cursor = Cursors.Default;
            }
        };
        show.Click += fill;
        browse.Click += delegate {
            FolderBrowserDialog fb = new FolderBrowserDialog();
            if (Directory.Exists(folderBox.Text)) fb.SelectedPath = folderBox.Text;
            if (fb.ShowDialog(d) == DialogResult.OK) { folderBox.Text = fb.SelectedPath; fill(null, EventArgs.Empty); }
        };
        list.DoubleClick += delegate { if (list.SelectedItem != null) d.DialogResult = DialogResult.OK; };
        d.Shown += delegate { fill(null, EventArgs.Empty); };

        if (d.ShowDialog(this) != DialogResult.OK || list.SelectedItem == null) return;
        string newFolder = folderBox.Text.Trim(), newTable = ((TableInfo)list.SelectedItem).Name;
        if (string.Compare(newFolder, folder, StringComparison.OrdinalIgnoreCase) != 0 || string.Compare(newTable, tableName, StringComparison.OrdinalIgnoreCase) != 0) {
            folder = newFolder;
            tableName = newTable;
            Places.SaveSettings(settingsFile, new string[] { folder, tableName, ((int)mode).ToString(), "", "", "", ThemeLine });   // справочник искать заново
        }
        OpenBase();
    }
}

// Столбцы списка найденного: тариф (T1, T2...), поля абонента, мощность (из доп. сведений)
public static class ResultColumns {
    public const int Tariff = -1, Power = -2;
    public static Color TariffColor { get { return Look.RowGood; } }

    public static List<int> Kinds(AbonentQuery q, ExtraInfo x) {
        List<int> list = new List<int>();
        list.Add(Tariff);
        list.AddRange(q.Columns);
        if (x != null && x.PowerBase != null) list.Add(Power);
        return list;
    }

    public static string Title(AbonentQuery q, int kind) {
        if (kind == Tariff) return "Т";
        if (kind == Power) return "Мощность";
        return q.ColumnTitle(kind);
    }

    public static int Weight(DbfTable h, int kind) {
        if (kind == Tariff) return 30;
        if (kind == Power) return 70;
        string n = h.Fields[kind].Name.ToUpperInvariant();
        return n == "FIO" ? 300 : n == "UL" ? 200 : (n == "NAB" || n == "NCH" || n == "TIPCH") ? 130 : 70;
    }

    public static Color AddedColor { get { return Look.Bad; } }

    // строка - другой тариф того же счётчика (её не искали): номер абонента красным
    public static Color OrangeColor { get { return Look.RowWarn; } }

    public static void Format(SearchResult r, int row, int kind, DataGridViewCellStyle style) {
        if (r.Tariff.ContainsKey(row)) style.BackColor = TariffColor;
        else if (r.Orange.ContainsKey(row)) style.BackColor = OrangeColor;
        if (r.Added.ContainsKey(row) && kind >= 0 && string.Compare(r.Table.Fields[kind].Name, "NAB", StringComparison.OrdinalIgnoreCase) == 0) {
            style.ForeColor = AddedColor;
            style.SelectionForeColor = Color.FromArgb(255, 190, 190);
        }
    }

    // Жирная чёрная рамка вокруг группы тарифов одного счётчика (T1, T2, T3), чтобы группы не сливались.
    // prev, cur, next - группа предыдущей, этой и следующей строки (null - строка не в группе)
    public static void PaintGroup(DataGridView g, DataGridViewCellPaintingEventArgs e, string prev, string cur, string next) {
        if (cur == null || e.RowIndex < 0 || e.ColumnIndex < 0) return;
        e.Paint(e.ClipBounds, DataGridViewPaintParts.All);
        Rectangle b = e.CellBounds;
        const int w = 3;
        using (SolidBrush frame = new SolidBrush(Look.Strong)) {
            if (prev != cur) e.Graphics.FillRectangle(frame, b.Left, b.Top, b.Width, w);
            if (next != cur) e.Graphics.FillRectangle(frame, b.Left, b.Bottom - w, b.Width, w);
            if (e.ColumnIndex == 0) e.Graphics.FillRectangle(frame, b.Left, b.Top, w, b.Height);
            if (e.ColumnIndex == g.Columns.Count - 1) e.Graphics.FillRectangle(frame, b.Right - w, b.Top, w, b.Height);
        }
        e.Handled = true;
    }

    // примечание для выгрузки в Excel (цвета там есть, но почему строка в списке - видно только так)
    public static string NoteText(SearchResult r, int row) {
        string why;
        if (r.Related.TryGetValue(row, out why)) return "добавлен: " + why;
        if (r.Added.ContainsKey(row)) return "добавлен: другой тариф того же счётчика";
        if (r.Orange.ContainsKey(row)) return "на адресе больше одного счётчика";
        return "";
    }

    // цвет строки в Excel: t - тариф (зелёный), o - несколько счётчиков на адресе (оранжевый)
    public static string ExcelStyle(SearchResult r, int row) {
        if (r.Tariff.ContainsKey(row)) return "t";
        if (r.Orange.ContainsKey(row)) return "o";
        return null;
    }

    // Ctrl+A в поле ввода - выделить всё
    public static void SelectAllKey(TextBox box) {
        box.KeyDown += delegate(object s, KeyEventArgs e) {
            if (e.Control && e.KeyCode == Keys.A) { box.SelectAll(); e.Handled = true; e.SuppressKeyPress = true; }
        };
    }

    public static string Text(SearchResult r, int row, int kind) {
        if (kind == Tariff) return r.TariffText(row);
        if (kind == Power) return r.PowerText(row);
        return r.Query.CellText(row, kind);
    }

    // карточка как в программе базы; не открылась - все поля списком
    public static void ShowCard(IWin32Window owner, SearchResult r, int row, LiveBase live, CardMove move) {
        BaseCard card;
        try { card = new BaseCard(r, row, live, move); }
        catch (Exception ex) {
            Report.Line("Карточка не открылась: " + ex.Message);
            ShowList(owner, r, row, live == null ? null : live.Extra);
            return;
        }
        card.Show(owner);
    }

    // все поля списком: сначала адрес по справочнику и тариф, после полей - доп. сведения (Ctrl+D в программе базы)
    public static void ShowList(IWin32Window owner, SearchResult r, int row, ExtraInfo x) {
        List<string> first = new List<string>();
        string[] street = r.Query.CardExtra(row);
        if (street != null) first.AddRange(street);
        int t;
        if (r.Tariff.TryGetValue(row, out t)) { first.Add("Тариф"); first.Add("T" + t + " (лицевые одного счётчика: таблица ABDIF_T)"); }
        string why;
        if (r.Related.TryGetValue(row, out why)) { first.Add("Добавлен к найденному"); first.Add(why); }
        else if (r.Orange.ContainsKey(row)) { first.Add("На адресе"); first.Add("больше одного счётчика (подсвечено оранжевым)"); }
        List<string> after = null;
        int nab = r.Table.FieldIndex("NAB");
        if (x != null && nab >= 0) {
            Cursor old = Cursor.Current;
            Cursor.Current = Cursors.WaitCursor;
            try { after = x.Details(DbfTable.Format(r.Table.GetValue(row, nab, null), true)); }
            catch (Exception ex) { after = new List<string>(new string[] { "--- Доп. сведения", "не прочитались: " + ex.Message }); }
            finally { Cursor.Current = old; }
        }
        Card.Show(owner, r.Table, row, first.ToArray(), after);
    }
}

// Выгрузка таблицы строк в Excel ("Таблица XML 2003": все значения - текст, нули в начале не теряются)
public static class Spreadsheet {
    public static void Open(string name, string[] headers, List<string[]> rows) {
        Open(name, headers, rows, null);
    }

    // styles - цвет каждой строки (null - без цвета): t - зелёный, o - оранжевый, y - жёлтый, n - красный
    public static void Open(string name, string[] headers, List<string[]> rows, List<string> styles) {
        string file = Write(Path.GetTempPath(), name, headers, rows, styles);
        try { Process.Start("excel.exe", "\"" + file + "\""); }
        catch { Process.Start(file); }
    }

    public static string Write(string folder, string name, string[] headers, List<string[]> rows, List<string> styles) {
        string file = Path.Combine(folder, name + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xml");
        using (StreamWriter w = new StreamWriter(file, false, new UTF8Encoding(false))) {
            w.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            w.WriteLine("<?mso-application progid=\"Excel.Sheet\"?>");
            w.WriteLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");
            w.WriteLine("<Styles><Style ss:ID=\"h\"><Font ss:Bold=\"1\"/></Style>" + Fill("t", "#D6F5D6") + Fill("o", "#FFCD96")
                + Fill("y", "#FFF5C8") + Fill("n", "#FFDCDC") + "</Styles>");
            w.WriteLine("<Worksheet ss:Name=\"" + DbfTable.Xml(name) + "\"><Table>");
            w.Write("<Row>");
            foreach (string h in headers) w.Write("<Cell ss:StyleID=\"h\"><Data ss:Type=\"String\">" + DbfTable.Xml(h) + "</Data></Cell>");
            w.WriteLine("</Row>");
            for (int i = 0; i < rows.Count; i++) {
                string st = styles != null && i < styles.Count && styles[i] != null ? " ss:StyleID=\"" + styles[i] + "\"" : "";
                w.Write("<Row>");
                foreach (string v in rows[i])
                    w.Write(v == null || v.Length == 0 ? "<Cell" + st + "/>" : "<Cell" + st + "><Data ss:Type=\"String\">" + DbfTable.Xml(v) + "</Data></Cell>");
                w.WriteLine("</Row>");
            }
            w.WriteLine("</Table></Worksheet></Workbook>");
        }
        return file;
    }

    static string Fill(string id, string color) {
        return "<Style ss:ID=\"" + id + "\"><Interior ss:Color=\"" + color + "\" ss:Pattern=\"Solid\"/></Style>";
    }
}

// Поиск по списку: вставляете столбик лицевых, счётчиков, ФИО или адресов - получаете итог по каждой строке
public class BatchSearch : Form {
    readonly LiveBase live;
    readonly Dictionary<string, bool> selected;
    SearchMode mode;
    internal readonly RadioButton[] modeButtons = new RadioButton[4];
    internal readonly TextBox input = new TextBox();
    readonly DataGridView grid = new DataGridView();
    internal readonly Label status = new Label();
    readonly Button findButton = new Button();
    internal readonly CheckBox partialBox = new CheckBox();
    readonly List<Item> items = new List<Item>();
    bool running;
    volatile bool stop;

    class Item {
        public int Line;
        public string Text;
        public string Result;
        public SearchResult Res;  // где лежит найденная запись
        public int Row = -1;      // запись абонента или -1, если не найден
        public int Kind;          // 0 - найден один, 1 - несколько, 2 - не найден
    }

    static readonly string[] ModeNames = { "&Лицевые счета", "&Адреса", "Номера &счётчиков", "&ФИО" };

    readonly List<int> kinds;

    public BatchSearch(LiveBase live, Dictionary<string, bool> selected, SearchMode mode, AbonentQuery query, List<int> kinds) {
        Font = Look.Base;
        Look.Wear(this);
        this.kinds = kinds;
        this.live = live;
        this.selected = selected;
        this.mode = mode;
        Text = "Поиск по списку";
        Size = new Size(1000, 700);
        StartPosition = FormStartPosition.CenterScreen;

        SplitContainer split = new SplitContainer();
        split.Dock = DockStyle.Fill;
        split.Orientation = Orientation.Horizontal;

        Panel head = new Panel();
        head.Dock = DockStyle.Top;
        head.Height = 58;
        Label l1 = new Label();
        l1.Text = "В списке:";
        l1.AutoSize = true;
        l1.Location = new Point(10, 10);
        head.Controls.Add(l1);
        int x = 80;
        for (int i = 0; i < modeButtons.Length; i++) {
            RadioButton rb = new RadioButton();
            rb.Text = ModeNames[i];
            rb.AutoSize = true;
            rb.Location = new Point(x, 8);
            rb.Tag = (SearchMode)i;
            rb.Checked = i == (int)mode;
            rb.CheckedChanged += delegate(object s, EventArgs e) { if (((RadioButton)s).Checked) this.mode = (SearchMode)((RadioButton)s).Tag; };
            modeButtons[i] = rb;
            head.Controls.Add(rb);
            x += 150;
        }
        partialBox.Text = "Частичное со&впадение";
        partialBox.AutoSize = true;
        partialBox.Location = new Point(x + 20, 8);
        new ToolTip().SetToolTip(partialBox, "Без галочки - только точное совпадение.\nС галочкой - ещё номера, которые так начинаются, ФИО по началу слов, адрес по похожим словам.");
        head.Controls.Add(partialBox);
        Label l2 = new Label();
        l2.Text = "Вставьте список - по одному значению в строке (можно столбик из Excel), и нажмите \"Найти\":";
        l2.AutoSize = true;
        l2.Location = new Point(10, 36);
        head.Controls.Add(l2);

        input.Multiline = true;
        input.AcceptsReturn = true;
        input.ScrollBars = ScrollBars.Both;
        input.WordWrap = false;
        input.Dock = DockStyle.Fill;
        input.Font = new Font(FontFamily.GenericMonospace, 10f);
        ResultColumns.SelectAllKey(input);

        Panel buttons = new Panel();
        buttons.Dock = DockStyle.Right;
        buttons.Width = 130;
        findButton.Text = "Найти";
        findButton.Location = new Point(10, 6);
        findButton.Size = new Size(110, 32);
        findButton.Click += delegate { Run(); };
        Button clear = new Button();
        clear.Text = "Очистить";
        clear.Location = new Point(10, 44);
        clear.Size = new Size(110, 28);
        clear.Click += delegate { input.Clear(); input.Focus(); };
        buttons.Controls.Add(findButton);
        buttons.Controls.Add(clear);

        split.Panel1.Controls.Add(input);
        split.Panel1.Controls.Add(buttons);
        split.Panel1.Controls.Add(head);

        grid.Dock = DockStyle.Fill;
        grid.VirtualMode = true;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        grid.CellValueNeeded += new DataGridViewCellValueEventHandler(OnCellValueNeeded);
        grid.CellFormatting += new DataGridViewCellFormattingEventHandler(OnCellFormatting);
        CopyText.Grid(grid);
        grid.CellPainting += delegate(object s, DataGridViewCellPaintingEventArgs e) {
            if (e.RowIndex >= 0) ResultColumns.PaintGroup(grid, e, GroupAt(e.RowIndex - 1), GroupAt(e.RowIndex), GroupAt(e.RowIndex + 1));
        };
        grid.CellDoubleClick += delegate(object s, DataGridViewCellEventArgs e) { OpenCard(e.RowIndex); };
        AddColumn("№", 35);
        AddColumn("Искали", 200);
        AddColumn("Результат", 220);
        foreach (int k in kinds) AddColumn(ResultColumns.Title(query, k), k == ResultColumns.Tariff ? 30 : 100);

        Panel bottom = new Panel();
        bottom.Dock = DockStyle.Bottom;
        bottom.Height = 34;
        status.Dock = DockStyle.Fill;
        status.TextAlign = ContentAlignment.MiddleLeft;
        status.Text = "Найденные - белым, несколько - жёлтым, тарифы (T1, T2...) - зелёным, 2 счётчика на адресе - оранжевым, не найденные - красным; номер красным - добавлено к найденному. Двойной щелчок - карточка.";
        Button excel = new Button();
        excel.Text = "В Excel";
        excel.Dock = DockStyle.Right;
        excel.Width = 120;
        excel.Click += delegate { Export(); };
        bottom.Controls.Add(status);
        bottom.Controls.Add(excel);

        split.Panel2.Controls.Add(grid);
        split.Panel2.Controls.Add(bottom);
        Controls.Add(split);
        Shown += delegate { split.SplitterDistance = 230; input.Focus(); };
        FormClosing += delegate { stop = true; };
    }

    void AddColumn(string title, int weight) {
        DataGridViewTextBoxColumn c = new DataGridViewTextBoxColumn();
        c.HeaderText = title;
        c.FillWeight = weight;
        c.SortMode = DataGridViewColumnSortMode.NotSortable;
        grid.Columns.Add(c);
    }

    // Ищем строку за строкой в фоне; кнопка "Найти" на это время - "Стоп"
    internal void Run() {
        if (running) { stop = true; return; }
        List<string> lines = new List<string>();
        foreach (string raw in input.Text.Replace("\r\n", "\n").Split('\n')) {
            string line = raw.Replace('\t', ' ').Trim();
            if (line.Length > 0) lines.Add(line);
        }
        if (lines.Count == 0) { MessageBox.Show(this, "Вставьте список: по одному значению в строке.", Text); return; }
        running = true;
        stop = false;
        findButton.Text = "Стоп";
        items.Clear();
        grid.RowCount = 0;
        SearchMode m = mode;
        bool partial = partialBox.Checked;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            DateTime started = DateTime.Now;
            int single = 0, several = 0, none = 0, done = 0;
            for (int i = 0; i < lines.Count && !stop; i++) {
                SearchResult r = live.Search(lines[i], m, selected, partial);
                List<Item> add = new List<Item>();
                if (r.Rows.Count == 0) {
                    string why = r.Error != null ? "ошибка: " + r.Error
                        : r.NoIndex && m == SearchMode.Name ? "допишите населённый пункт или улицу (Иванов Боровляны)"
                        : r.NoIndex ? "нет индекса для поиска"
                        : r.Hidden > 0 ? "в выбранных сельсоветах нет (в других: " + r.Hidden + ")"
                        : r.Note.Length > 0 ? "не найден: " + r.Note
                        : !r.TooMany && r.Query != null && r.Query.Miss.Length > 0 ? "не найден: " + r.Query.Miss : "не найден";
                    add.Add(NewItem(i + 1, lines[i], why, null, -1, 2));
                    none++;
                } else {
                    int n = r.Searched;
                    string result = n == 1 ? "найден" : "найдено " + n + (r.TooMany ? " (очень много - показана часть)" : "");
                    if (r.Added.Count > r.Related.Count) result += " (+" + (r.Added.Count - r.Related.Count) + " др. тариф)";
                    if (r.Related.Count > 0) result += " (+" + r.Related.Count + " адрес/ФИО)";
                    if (r.Hidden > 0) result += " (+" + r.Hidden + " в других с/с)";
                    if (n == 1) single++; else several++;
                    for (int k = 0; k < r.Rows.Count; k++)
                        add.Add(NewItem(i + 1, lines[i], result, r, r.Rows[k], n == 1 ? 0 : 1));
                }
                done = i + 1;
                int line = done;
                Post(delegate {
                    items.AddRange(add);
                    grid.RowCount = items.Count;
                    status.Text = "Ищу: строка " + line + " из " + lines.Count + "...   (кнопка \"Стоп\" - прервать)";
                });
            }
            double seconds = (DateTime.Now - started).TotalSeconds;
            int s1 = single, s2 = several, s3 = none, d = done;
            Post(delegate { Finish(lines, d, s1, s2, s3, seconds, partial); });
        });
        th.IsBackground = true;
        th.Start();
    }

    void Post(MethodInvoker m) {
        try { if (!IsDisposed) BeginInvoke(m); } catch (Exception) { }
    }

    void Finish(List<string> lines, int done, int single, int several, int none, double seconds, bool partial) {
        running = false;
        findButton.Text = "Найти";
        grid.RowCount = items.Count;
        grid.Invalidate();
        status.Text = (done < lines.Count ? "Остановлено на строке " + done + " из " + lines.Count + ". " : "Строк в списке: " + lines.Count + ". ")
            + "Найдено по одному абоненту: " + single + ", по несколько: " + several + ", не найдено: " + none + ". Двойной щелчок - карточка.";
        Dictionary<int, int> lengths = new Dictionary<int, int>();
        foreach (string line in lines) {
            int digits = 0;
            foreach (char c in line) if (c >= '0' && c <= '9') digits++;
            int n;
            lengths.TryGetValue(digits, out n);
            lengths[digits] = n + 1;
        }
        List<string> shape = new List<string>();
        foreach (KeyValuePair<int, int> kv in lengths) shape.Add(kv.Key + " цифр - " + kv.Value);
        Report.Search("Поиск по списку, в списке: " + ModeNames[(int)mode].Replace("&", "").ToLowerInvariant() + (partial ? " (частичное совпадение)" : "") + "; строк " + lines.Count
            + (done < lines.Count ? " (остановлен на " + done + ")" : "") + ", найдено по одному " + single + ", по несколько " + several + ", не найдено " + none
            + ", время " + seconds.ToString("0.0") + " с; цифр в строках: " + string.Join(", ", shape.ToArray()));
    }

    static Item NewItem(int line, string text, string result, SearchResult res, int row, int kind) {
        Item it = new Item();
        it.Line = line;
        it.Text = text;
        it.Result = result;
        it.Res = res;
        it.Row = row;
        it.Kind = kind;
        return it;
    }

    string Cell(Item it, int column) {
        if (column == 0) return it.Line.ToString();
        if (column == 1) return it.Text;
        if (column == 2) return it.Result;
        if (it.Row < 0 || it.Res == null || column - 3 >= kinds.Count) return "";
        return ResultColumns.Text(it.Res, it.Row, kinds[column - 3]);
    }

    void OnCellValueNeeded(object sender, DataGridViewCellValueEventArgs e) {
        if (e.RowIndex < items.Count) e.Value = Cell(items[e.RowIndex], e.ColumnIndex);
    }

    // группа тарифов строки итога: своя для каждой строки списка
    string GroupAt(int i) {
        if (i < 0 || i >= items.Count) return null;
        Item it = items[i];
        if (it.Res == null || it.Row < 0) return null;
        string g = it.Res.GroupOf(it.Row);
        return g == null ? null : it.Line + "|" + g;
    }

    void OnCellFormatting(object sender, DataGridViewCellFormattingEventArgs e) {
        if (e.RowIndex < 0 || e.RowIndex >= items.Count) return;
        Item it = items[e.RowIndex];
        int kind = it.Kind;
        if (kind == 2) e.CellStyle.BackColor = Look.RowBad;
        else if (kind == 1) e.CellStyle.BackColor = Look.RowWarn;
        if (it.Res != null && it.Row >= 0 && e.ColumnIndex >= 3 && e.ColumnIndex - 3 < kinds.Count)
            ResultColumns.Format(it.Res, it.Row, kinds[e.ColumnIndex - 3], e.CellStyle);
        else if (it.Res != null && it.Res.Tariff.ContainsKey(it.Row)) e.CellStyle.BackColor = ResultColumns.TariffColor;
    }

    internal void OpenCardAt(int index) { OpenCard(index); }

    void OpenCard(int index) {
        if (index < 0 || index >= items.Count || items[index].Row < 0) return;
        Item it = items[index];
        int pos = index;
        // PgUp/PgDn в карточке - следующий найденный абонент итога
        CardMove move = delegate(int delta, out SearchResult rr, out int row) {
            rr = null;
            row = -1;
            int p = pos;
            do {
                p += delta;
                if (p < 0 || p >= items.Count) return false;
            } while (items[p].Row < 0 || items[p].Res == null);
            pos = p;
            rr = items[p].Res;
            row = items[p].Row;
            if (p < grid.RowCount) grid.CurrentCell = grid.Rows[p].Cells[0];
            return true;
        };
        ResultColumns.ShowCard(this, it.Res, it.Row, live, move);
    }

    void Export() {
        if (items.Count == 0) { MessageBox.Show(this, "Сначала найдите что-нибудь.", Text); return; }
        string[] headers = new string[grid.Columns.Count];
        for (int c = 0; c < headers.Length; c++) headers[c] = grid.Columns[c].HeaderText;
        List<string[]> rows = new List<string[]>();
        foreach (Item it in items) {
            string[] r = new string[headers.Length];
            for (int c = 0; c < r.Length; c++) r[c] = Cell(it, c);
            rows.Add(r);
        }
        List<string> styles = new List<string>();
        foreach (Item it in items) {
            string st = it.Res != null && it.Row >= 0 ? ResultColumns.ExcelStyle(it.Res, it.Row) : null;
            styles.Add(st ?? (it.Kind == 2 ? "n" : it.Kind == 1 ? "y" : null));
        }
        try { Spreadsheet.Open("Поиск_по_списку", headers, rows, styles); }
        catch (Exception ex) { MessageBox.Show(this, "Не удалось выгрузить в Excel:\n" + ex.Message, Text); }
    }
}


// ===================== Наряды (Н-З) =====================
// В программе базы наряды видны по Ctrl+Z (по адресу). Здесь - по номеру: ГодНомер (202620936 = 2026 год, наряд 20936)
// или просто номер за выбранный год; выполнен - заполнено «Выполнил Н-З». Индексов у таблицы нарядов нет - программа
// делает свой индекс года (номер наряда -> номер записи) в своей папке: для нового года таблица читается с конца
// (новые наряды - в конце), до старых лет; дальше индекс только дополняется новыми записями. Таблица - только чтение.

// какая таблица - наряды и какое поле что значит (naryady.txt в папке программы)
public class NaryadSetup {
    public string Table = "", Number = "", Date = "", Done = "", DoneDate = "", Work = "", Taker = "", Account = "", Meter = "", Name = "";
    public string How = "";          // «сама» - найдена программой, «вручную» - выбрана в настройке
    public string WorkBook = "", StaffBook = "";   // справочники: «таблица:код:название» (вид работы, работники)
    public string YearFrom = "";     // поле полного номера ГодНомер (UNNAR) - год наряда из него; пусто - год из даты оформления

    // поле, из которого берётся год наряда (для индексов и проверки)
    public string YearField { get { return YearFrom.Length > 0 ? YearFrom : Date; } }
    public int Year;                 // последний выбранный год
    public int Version;              // 2 - найдено новой программой (знает таблицу REGNZ); старую «сама» - найти заново
    public const int CurrentVersion = 3;

    static readonly string[] Keys = { "таблица", "номер", "дата", "выполнил", "дата_выполнения", "работа", "принял", "лицевой", "счётчик", "фио", "как", "год", "версия", "справочник_работ", "справочник_работников", "год_из" };

    string[] Values() { return new string[] { Table, Number, Date, Done, DoneDate, Work, Taker, Account, Meter, Name, How, Year > 0 ? Year.ToString() : "", Version.ToString(), WorkBook, StaffBook, YearFrom }; }

    public bool Ready { get { return Table.Length > 0 && Number.Length > 0 && Date.Length > 0 && Done.Length > 0; } }

    public static NaryadSetup Load(string file) {
        NaryadSetup s = new NaryadSetup();
        try {
            if (!File.Exists(file)) return s;
            Dictionary<string, string> d = new Dictionary<string, string>();
            foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
                int e = line.IndexOf('=');
                if (line.StartsWith("#") || e <= 0) continue;
                d[line.Substring(0, e).Trim()] = line.Substring(e + 1).Trim();
            }
            string v;
            if (d.TryGetValue("таблица", out v)) s.Table = v;
            if (d.TryGetValue("номер", out v)) s.Number = v;
            if (d.TryGetValue("дата", out v)) s.Date = v;
            if (d.TryGetValue("выполнил", out v)) s.Done = v;
            if (d.TryGetValue("дата_выполнения", out v)) s.DoneDate = v;
            if (d.TryGetValue("работа", out v)) s.Work = v;
            if (d.TryGetValue("принял", out v)) s.Taker = v;
            if (d.TryGetValue("лицевой", out v)) s.Account = v;
            if (d.TryGetValue("счётчик", out v)) s.Meter = v;
            if (d.TryGetValue("фио", out v)) s.Name = v;
            if (d.TryGetValue("как", out v)) s.How = v;
            if (d.TryGetValue("год", out v)) int.TryParse(v, out s.Year);
            if (d.TryGetValue("версия", out v)) int.TryParse(v, out s.Version);
            if (d.TryGetValue("справочник_работ", out v)) s.WorkBook = v;
            if (d.TryGetValue("справочник_работников", out v)) s.StaffBook = v;
            if (d.TryGetValue("год_из", out v)) s.YearFrom = v;
        } catch (Exception) { }
        return s;
    }

    public void Save(string file) {
        try {
            List<string> lines = new List<string>();
            lines.Add("# Наряды (окно «Наряды» программы «Поиск абонента»): таблица нарядов в папке базы и её поля. Файл можно удалить - программа найдёт таблицу заново.");
            string[] v = Values();
            for (int i = 0; i < Keys.Length; i++) lines.Add(Keys[i] + "=" + v[i]);
            File.WriteAllLines(file, lines.ToArray(), Encoding.UTF8);
        } catch (Exception) { }
    }

    public string Describe() {
        if (!Ready) return "таблица нарядов не выбрана";
        return Table + ": номер - " + Number + (YearFrom.Length > 0 ? ", год - из полного номера " + YearFrom : "") + ", дата - " + Date + ", выполнил - " + Done
            + (DoneDate.Length > 0 ? ", дата выполнения - " + DoneDate : "");
    }
}

// поля записи наряда прямо из байтов (для индекса не нужно разбирать всю запись)
public static class NaryadBytes {
    // целое число поля (номер наряда): N, F, I или текст из цифр; нет - -1
    public static long Number(byte[] r, int start, DbfField f) {
        int at = start + f.Offset;
        if (f.Type == 'I' && f.Length == 4) return BitConverter.ToInt32(r, at);
        if (f.Type != 'N' && f.Type != 'F' && f.Type != 'C') return -1;
        long n = 0;
        int digits = 0;
        for (int k = 0; k < f.Length; k++) {
            byte b = r[at + k];
            if (b >= (byte)'0' && b <= (byte)'9') {
                if (digits > 12) return -1;
                n = n * 10 + (b - (byte)'0');
                digits++;
            } else if (b == (byte)' ' || b == 0) {
                if (digits > 0) {
                    // число кончилось - дальше только пробелы
                    for (int q = k; q < f.Length; q++) if (r[at + q] != (byte)' ' && r[at + q] != 0) return -1;
                    break;
                }
            } else if (b == (byte)'.' && f.Type != 'C') {
                // дробная часть - только нули
                for (int q = k + 1; q < f.Length; q++) if (r[at + q] != (byte)'0' && r[at + q] != (byte)' ') return -1;
                break;
            } else return -1;
        }
        return digits == 0 ? -1 : n;
    }

    // цифры поля (лицевой «053300450» - как есть, с нулями); нет поля - пусто
    public static string Digits(byte[] r, int start, DbfField f) {
        if (f == null) return "";
        StringBuilder sb = new StringBuilder();
        int at = start + f.Offset;
        if (f.Type == 'I' && f.Length == 4) return BitConverter.ToInt32(r, at).ToString();
        for (int k = 0; k < f.Length; k++) {
            byte b = r[at + k];
            if (b >= (byte)'0' && b <= (byte)'9') sb.Append((char)b);
            else if (b == (byte)'.' && f.Type != 'C') break;
        }
        return sb.ToString();
    }

    // лицевой для сравнения: без нулей впереди («053300450» и «53300450» - один)
    public static string Key(string ls) { return ls.TrimStart('0'); }

    // год записи: из даты D (ГГГГММДД) или T (юлианский день), или из полного номера ГодНомер (поле N: 202655555 -> 2026); нет - 0
    public static int Year(byte[] r, int start, DbfField f) {
        int at = start + f.Offset;
        if (f.Type == 'N' || f.Type == 'I') {
            long v = Number(r, start, f);
            return v >= 200000000 && v < 210000000 ? (int)(v / 100000) : 0;
        }
        if (f.Type == 'D') {
            int y = 0;
            for (int k = 0; k < 4; k++) {
                byte b = r[at + k];
                if (b < (byte)'0' || b > (byte)'9') return 0;
                y = y * 10 + (b - (byte)'0');
            }
            return y;
        }
        if (f.Type == 'T' && f.Length == 8) {
            int day = BitConverter.ToInt32(r, at);
            if (day <= 1721426) return 0;
            try { return new DateTime(1, 1, 1).AddDays(day - 1721426).Year; } catch (ArgumentOutOfRangeException) { return 0; }
        }
        return 0;
    }
}

// Свой индекс нарядов одного года: номер -> номера записей таблицы. Файл indeks_naryady_ГГГГ.txt в папке программы.
public class NaryadIndex {
    public int Year;
    public string Table = "", NumberField = "", DateField = "", AccountField = "";
    public int RecordLength, From, To;      // просмотрены записи From..To (с 1)
    public bool Whole;                      // смотрели всю таблицу (иначе - с конца до старых лет)
    public DateTime Built, Updated;
    public double Seconds;
    readonly Dictionary<long, List<int>> map = new Dictionary<long, List<int>>();
    readonly Dictionary<int, string> account = new Dictionary<int, string>();     // запись -> лицевой (для списка нарядов лицевого)
    public int Count;

    public const int StopRun = 20000;       // столько записей старых лет подряд - дальше не смотрим

    public static string FileFor(string dir, int year) { return Path.Combine(dir, "indeks_naryady_" + year + ".txt"); }

    public void Add(long number, int recNo, string ls) {
        List<int> l;
        if (!map.TryGetValue(number, out l)) { l = new List<int>(1); map[number] = l; }
        if (!l.Contains(recNo)) { l.Add(recNo); Count++; }
        if (ls.Length > 0) account[recNo] = ls;
    }

    // наряды лицевого этого года (записи таблицы)
    public List<int> ByAccount(string ls) {
        List<int> r = new List<int>();
        string key = NaryadBytes.Key(ls);
        if (key.Length == 0) return r;
        foreach (KeyValuePair<int, string> kv in account) if (NaryadBytes.Key(kv.Value) == key) r.Add(kv.Key);
        return r;
    }

    public string AccountOf(int recNo) {
        string ls;
        return account.TryGetValue(recNo, out ls) ? ls : "";
    }

    public List<int> Find(long number) {
        List<int> l;
        return map.TryGetValue(number, out l) ? l : new List<int>();
    }

    public long MinNumber, MaxNumber;

    void Range() {
        MinNumber = long.MaxValue; MaxNumber = 0;
        foreach (long k in map.Keys) { if (k < MinNumber) MinNumber = k; if (k > MaxNumber) MaxNumber = k; }
        if (map.Count == 0) MinNumber = 0;
    }

    // индекс подходит к этой таблице и этим полям
    public bool Fits(NaryadSetup s, DbfTable h) {
        return string.Compare(Table, s.Table, StringComparison.OrdinalIgnoreCase) == 0 && string.Compare(NumberField, s.Number, StringComparison.OrdinalIgnoreCase) == 0
            && (string.Compare(DateField, s.YearField, StringComparison.OrdinalIgnoreCase) == 0 || string.Compare(DateField, s.Date, StringComparison.OrdinalIgnoreCase) == 0)
            && string.Compare(AccountField, s.Account, StringComparison.OrdinalIgnoreCase) == 0
            && RecordLength == h.RecordLength;
    }

    public static NaryadIndex Load(string file) {
        if (!File.Exists(file)) return null;
        NaryadIndex x = new NaryadIndex();
        bool data = false, v2 = false;
        foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
            if (line.Length == 0 || line.StartsWith("#")) continue;
            if (data) {
                int t = line.IndexOf('\t');
                long n;
                if (t <= 0 || !long.TryParse(line.Substring(0, t), out n)) continue;
                // «запись:лицевой,запись:лицевой»
                foreach (string rn in line.Substring(t + 1).Split(',')) {
                    int c = rn.IndexOf(':'), r;
                    if (int.TryParse(c < 0 ? rn : rn.Substring(0, c), out r)) x.Add(n, r, c < 0 ? "" : rn.Substring(c + 1));
                }
                continue;
            }
            if (line == "записи:") { data = true; continue; }
            int e = line.IndexOf('=');
            if (e <= 0) continue;
            string k = line.Substring(0, e), v = line.Substring(e + 1);
            DateTime d;
            switch (k) {
                case "год": int.TryParse(v, out x.Year); break;
                case "таблица": x.Table = v; break;
                case "номер": x.NumberField = v; break;
                case "дата": x.DateField = v; break;
                case "лицевой": x.AccountField = v; break;
                case "версия": v2 = v == "2"; break;
                case "длина_записи": int.TryParse(v, out x.RecordLength); break;
                case "с_записи": int.TryParse(v, out x.From); break;
                case "по_запись": int.TryParse(v, out x.To); break;
                case "вся_таблица": x.Whole = v == "да"; break;
                case "создан": if (DateTime.TryParseExact(v, "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) x.Built = d; break;
                case "обновлён": if (DateTime.TryParseExact(v, "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) x.Updated = d; break;
            }
        }
        if (!data || x.Year == 0 || !v2) return null;     // старый индекс (без лицевых) - создаётся заново
        x.Range();
        return x;
    }

    // запись через временный файл: свет погас при записи - старый индекс цел
    public void Save(string file) {
        StringBuilder sb = new StringBuilder();
        sb.Append("# Свой индекс нарядов программы «Поиск абонента»: номер наряда -> номера записей таблицы. Можно удалить - создастся заново.\r\n");
        sb.Append("версия=2\r\n");
        sb.Append("год=").Append(Year).Append("\r\n");
        sb.Append("таблица=").Append(Table).Append("\r\n");
        sb.Append("номер=").Append(NumberField).Append("\r\n");
        sb.Append("дата=").Append(DateField).Append("\r\n");
        sb.Append("лицевой=").Append(AccountField).Append("\r\n");
        sb.Append("длина_записи=").Append(RecordLength).Append("\r\n");
        sb.Append("с_записи=").Append(From).Append("\r\n");
        sb.Append("по_запись=").Append(To).Append("\r\n");
        sb.Append("вся_таблица=").Append(Whole ? "да" : "нет").Append("\r\n");
        sb.Append("создан=").Append(Built.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture)).Append("\r\n");
        sb.Append("обновлён=").Append(Updated.ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture)).Append("\r\n");
        sb.Append("записи:\r\n");
        List<long> keys = new List<long>(map.Keys);
        keys.Sort();
        foreach (long k in keys) {
            List<int> l = map[k];
            sb.Append(k).Append('\t');
            for (int i = 0; i < l.Count; i++) {
                if (i > 0) sb.Append(',');
                sb.Append(l[i]);
                string ls = AccountOf(l[i]);
                if (ls.Length > 0) sb.Append(':').Append(ls);
            }
            sb.Append("\r\n");
        }
        string tmp = file + ".tmp";
        File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(true));
        if (File.Exists(file)) File.Delete(file);
        File.Move(tmp, file);
    }

    // новый индекс года: с конца таблицы к началу (новые наряды - в конце), пока не пойдут подряд StopRun записей
    // прошлых лет; whole - вся таблица. stop() - прервать (вернёт null)
    public static NaryadIndex Build(string path, DbfTable h, NaryadSetup s, int year, bool whole, LoadProgress progress, StopCheck stop) {
        DateTime started = DateTime.Now;
        NaryadIndex x = new NaryadIndex();
        x.Year = year;
        x.Table = s.Table;
        x.NumberField = s.Number;
        x.DateField = s.YearField;
        x.AccountField = s.Account;
        x.RecordLength = h.RecordLength;
        x.Whole = whole;
        DbfField nf = h.Fields[h.FieldIndex(s.Number)], df = h.Fields[h.FieldIndex(s.YearField)];
        DbfField af = s.Account.Length > 0 && h.FieldIndex(s.Account) >= 0 ? h.Fields[h.FieldIndex(s.Account)] : null;
        int len = h.RecordLength;
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16)) {
            int count = NameIndex.RecordCount(fs);
            long fit = (fs.Length - h.HeaderLength) / len;
            if (fit < count) count = (int)fit;
            x.To = count;
            x.From = count + 1;
            const int chunk = 2048;
            byte[] buf = new byte[chunk * len];
            int older = 0, seen = 0;
            int end = count;          // читаем записи (end - n, end]
            while (end > 0) {
                int n = Math.Min(chunk, end);
                int first = end - n + 1;
                fs.Seek(h.HeaderLength + (long)(first - 1) * len, SeekOrigin.Begin);
                int got = DbfTable.ReadUpTo(fs, buf, n * len) / len;
                bool enough = false;
                for (int i = got - 1; i >= 0; i--) {
                    int p = i * len, recNo = first + i;
                    x.From = recNo;
                    seen++;
                    if (buf[p] == (byte)'*' || buf[p] == 0x1A) continue;
                    int y = NaryadBytes.Year(buf, p, df);
                    if (y == year) {
                        long num = NaryadBytes.Number(buf, p, nf);
                        if (num > 0) x.Add(num, recNo, NaryadBytes.Digits(buf, p, af));
                        older = 0;
                    } else if (y > year) older = 0;
                    else if (y > 0 && y < year) {
                        older++;
                        if (!whole && older >= StopRun) { enough = true; break; }
                    }
                }
                end = first - 1;
                if (progress != null) progress(seen, count);
                if (stop != null && stop()) return null;
                if (enough) break;
            }
        }
        x.Built = x.Updated = DateTime.Now;
        x.Seconds = (DateTime.Now - started).TotalSeconds;
        x.Range();
        return x;
    }

    // индексы нескольких лет сразу - один проход с конца таблицы, пока не пойдут подряд StopRun записей старше самого раннего года
    public static Dictionary<int, NaryadIndex> BuildYears(string path, DbfTable h, NaryadSetup s, List<int> years, LoadProgress progress, StopCheck stop) {
        DateTime started = DateTime.Now;
        Dictionary<int, NaryadIndex> all = new Dictionary<int, NaryadIndex>();
        int min = int.MaxValue;
        foreach (int year in years) {
            NaryadIndex x = new NaryadIndex();
            x.Year = year;
            x.Table = s.Table;
            x.NumberField = s.Number;
            x.DateField = s.YearField;
            x.AccountField = s.Account;
            x.RecordLength = h.RecordLength;
            all[year] = x;
            if (year < min) min = year;
        }
        DbfField nf = h.Fields[h.FieldIndex(s.Number)], df = h.Fields[h.FieldIndex(s.YearField)];
        DbfField af = s.Account.Length > 0 && h.FieldIndex(s.Account) >= 0 ? h.Fields[h.FieldIndex(s.Account)] : null;
        int len = h.RecordLength, from;
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16)) {
            int count = NameIndex.RecordCount(fs);
            long fit = (fs.Length - h.HeaderLength) / len;
            if (fit < count) count = (int)fit;
            from = count + 1;
            const int chunk = 2048;
            byte[] buf = new byte[chunk * len];
            int older = 0, seen = 0, end = count;
            while (end > 0) {
                int n = Math.Min(chunk, end), first = end - n + 1;
                fs.Seek(h.HeaderLength + (long)(first - 1) * len, SeekOrigin.Begin);
                int got = DbfTable.ReadUpTo(fs, buf, n * len) / len;
                bool enough = false;
                for (int i = got - 1; i >= 0; i--) {
                    int p = i * len, recNo = first + i;
                    from = recNo;
                    seen++;
                    if (buf[p] == (byte)'*' || buf[p] == 0x1A) continue;
                    int y = NaryadBytes.Year(buf, p, df);
                    NaryadIndex x;
                    if (all.TryGetValue(y, out x)) {
                        long num = NaryadBytes.Number(buf, p, nf);
                        if (num > 0) x.Add(num, recNo, NaryadBytes.Digits(buf, p, af));
                        older = 0;
                    } else if (y >= min) older = 0;
                    else if (y > 0 && ++older >= StopRun) { enough = true; break; }
                }
                end = first - 1;
                if (progress != null) progress(seen, count);
                if (stop != null && stop()) return null;
                if (enough) break;
            }
            foreach (NaryadIndex x in all.Values) { x.From = from; x.To = count; }
        }
        foreach (NaryadIndex x in all.Values) {
            x.Built = x.Updated = DateTime.Now;
            x.Seconds = (DateTime.Now - started).TotalSeconds;
            x.Range();
        }
        return all;
    }

    // дописать наряды года из новых записей таблицы (после To); -1 - таблица стала короче (её пересобрали) - индекс создать заново
    public int Update(string path, DbfTable h) {
        DbfField nf = h.Fields[h.FieldIndex(NumberField)], df = h.Fields[h.FieldIndex(DateField)];
        DbfField af = AccountField.Length > 0 && h.FieldIndex(AccountField) >= 0 ? h.Fields[h.FieldIndex(AccountField)] : null;
        int len = h.RecordLength, was = Count;
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16)) {
            int count = NameIndex.RecordCount(fs);
            long fit = (fs.Length - h.HeaderLength) / len;
            if (fit < count) count = (int)fit;
            if (count < To) return -1;
            const int chunk = 2048;
            byte[] buf = new byte[chunk * len];
            int next = To + 1;
            fs.Seek(h.HeaderLength + (long)(next - 1) * len, SeekOrigin.Begin);
            while (next <= count) {
                int n = Math.Min(chunk, count - next + 1);
                int got = DbfTable.ReadUpTo(fs, buf, n * len) / len;
                for (int i = 0; i < got; i++) {
                    int p = i * len;
                    if (buf[p] == (byte)'*' || buf[p] == 0x1A) continue;
                    if (NaryadBytes.Year(buf, p, df) != Year) continue;
                    long num = NaryadBytes.Number(buf, p, nf);
                    if (num > 0) Add(num, next + i, NaryadBytes.Digits(buf, p, af));
                }
                if (got < n) { count = next + got - 1; break; }
                next += got;
            }
            To = count;
        }
        Updated = DateTime.Now;
        Range();
        return Count - was;
    }
}

public delegate bool StopCheck();

// Какая таблица папки - наряды: смотрим последние записи каждой таблицы с датами и угадываем поля по виду значений
// (номер - целое, растёт от записи к записи; дата оформления; «выполнил» - Ф.И.О., заполнено не у всех, вместе с датой
// выполнения; принял, работа, лицевой) и по именам полей (NZ, NAR, VYP, ISP, PRIN...)
public class NaryadGuess {
    public NaryadSetup Setup = new NaryadSetup();
    public int Score, Records;
    public string Path = "", Why = "";
    public DbfTable Sample;            // последние записи (для отчёта - только вид значений)
    public bool Usable { get { return Setup.Ready; } }
}

public static class NaryadFinder {
    const int SampleSize = 600;

    public static List<NaryadGuess> Guess(string folder, LoadProgress progress) {
        List<NaryadGuess> r = new List<NaryadGuess>();
        List<string> files = new List<string>();
        foreach (string f in Directory.GetFiles(folder))
            if (string.Compare(System.IO.Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) == 0) files.Add(f);
        for (int i = 0; i < files.Count; i++) {
            if (progress != null) progress(i, files.Count);
            NaryadGuess g;
            try { g = Judge(files[i]); } catch (Exception) { g = null; }
            if (g != null) r.Add(g);
        }
        r.Sort(delegate(NaryadGuess a, NaryadGuess b) {
            if (a.Usable != b.Usable) return a.Usable ? -1 : 1;
            return b.Score.CompareTo(a.Score);
        });
        return r;
    }

    // последние записи таблицы (в порядке файла)
    public static DbfTable Tail(string path, DbfTable h, int want) {
        DbfTable part = DbfTable.CreateLike(h);
        part.FilePath = path;
        int len = h.RecordLength;
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16)) {
            int count = NameIndex.RecordCount(fs);
            long fit = (fs.Length - h.HeaderLength) / len;
            if (fit < count) count = (int)fit;
            int n = Math.Min(count, want * 2);
            if (n <= 0) return part;
            byte[] buf = new byte[n * len];
            fs.Seek(h.HeaderLength + (long)(count - n) * len, SeekOrigin.Begin);
            int got = DbfTable.ReadUpTo(fs, buf, n * len) / len;
            List<int> keep = new List<int>();
            for (int i = got - 1; i >= 0 && keep.Count < want; i--) {
                byte f = buf[i * len];
                if (f != (byte)'*' && f != 0x1A) keep.Insert(0, i);
            }
            foreach (int i in keep) part.AddRecord(buf, i * len, count - n + i + 1);
        }
        return part;
    }

    static bool Has(string name, params string[] parts) {
        string n = name.ToUpperInvariant();
        foreach (string p in parts) if (n.Contains(p)) return true;
        return false;
    }

    // похоже на Ф.И.О.: инициалы «А.С.» или два-три слова с заглавной буквы (кириллица)
    public static bool NameLike(string s) {
        s = s.Trim();
        if (s.Length < 4) return false;
        int cyr = 0, other = 0;
        foreach (char c in s) {
            if (c >= 'А' && c <= 'я' || c == 'Ё' || c == 'ё') cyr++;
            else if (!(c == ' ' || c == '.' || c == '-' || c == ',')) other++;
        }
        if (cyr < 3 || other * 4 > s.Length) return false;
        for (int i = 0; i + 3 < s.Length; i++)
            if (char.IsUpper(s[i]) && s[i + 1] == '.' && (char.IsUpper(s[i + 2]) || s[i + 2] == ' ' && char.IsUpper(s[i + 3]))) return true;
        int caps = 0, words = 0;
        foreach (string w in s.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)) {
            words++;
            if (char.IsUpper(w[0]) && (w.Length == 1 || char.IsLower(w[1]))) caps++;
        }
        return words >= 2 && caps >= 2;
    }

    static string Text(DbfTable t, int row, int j) { return DbfTable.Format(t.GetValue(row, j, null), true).Trim(); }

    public static NaryadGuess Judge(string path) {
        DbfTable h = DbfTable.LoadHeader(path);
        bool dates = false;
        foreach (DbfField f in h.Fields) if (f.Type == 'D' || f.Type == 'T') dates = true;
        if (!dates || h.Expected < 20) return null;
        DbfTable t = Tail(path, h, SampleSize);
        int n = t.Count;
        if (n < 20) return null;
        NaryadGuess g = new NaryadGuess();
        g.Path = path;
        g.Sample = t;
        g.Records = h.Expected;
        g.Setup.Table = System.IO.Path.GetFileName(path);
        g.Setup.Version = NaryadSetup.CurrentVersion;
        // наряды программы базы (REGNZ): № Н-З N_NAR, дата оф. DOF, выполнил - табельный TNRVIP (0 - не выполнен)
        if (t.FieldIndex("N_NAR") >= 0 && t.FieldIndex("DOF") >= 0 && t.FieldIndex("TNRVIP") >= 0) {
            g.Setup.Number = "N_NAR";
            g.Setup.Date = "DOF";
            g.Setup.Done = "TNRVIP";
            string[][] more = { new string[] { "DVIP", "d" }, new string[] { "KVRAB", "w" }, new string[] { "TNRPR", "t" }, new string[] { "NAB", "a" }, new string[] { "NCH", "m" } };
            foreach (string[] m in more) {
                if (t.FieldIndex(m[0]) < 0) continue;
                if (m[1] == "d") g.Setup.DoneDate = m[0];
                else if (m[1] == "w") g.Setup.Work = m[0];
                else if (m[1] == "t") g.Setup.Taker = m[0];
                else if (m[1] == "a") g.Setup.Account = m[0];
                else g.Setup.Meter = m[0];
            }
            // UNNAR = ГодНомер (202655555): год наряда - из него (совпадает с номером в последних нарядах)
            int un = t.FieldIndex("UNNAR"), nn = t.FieldIndex("N_NAR");
            if (un >= 0 && t.Fields[un].Type == 'N') {
                int same = 0;
                for (int r = 0; r < t.Count; r++) {
                    long u, k;
                    if (long.TryParse(Text(t, r, un), out u) && long.TryParse(Text(t, r, nn), out k) && u % 100000 == k && u / 100000 >= 2000 && u / 100000 < 2100) same++;
                }
                if (same * 10 >= t.Count * 9) g.Setup.YearFrom = "UNNAR";
            }
            g.Setup.How = "сама";
            g.Score = 100;
            return g;
        }
        int nf = t.Fields.Count;
        int[] filled = new int[nf];
        bool[,] has = new bool[nf, n];
        for (int j = 0; j < nf; j++)
            for (int r = 0; r < n; r++) {
                string v = Text(t, r, j);
                bool ok = v.Length > 0 && v != "0";
                has[j, r] = ok;
                if (ok) filled[j]++;
            }

        // номер наряда: целое, почти у всех, разное, растёт от записи к записи
        int bestNum = -1, numScore = 0;
        for (int j = 0; j < nf; j++) {
            DbfField f = t.Fields[j];
            if (!(f.Type == 'N' && f.Decimals == 0 && f.Length <= 10 || f.Type == 'I' || f.Type == 'C' && f.Length <= 12)) continue;
            if (Has(f.Name, "NAB", "TEL", "PHON", "KUL", "DOM", "KV", "INDEX", "ULIC") || f.Name.ToUpperInvariant() == "UL") continue;
            List<long> vals = new List<long>();
            bool bad = false;
            for (int r = 0; r < n && !bad; r++) {
                if (!has[j, r]) continue;
                string v = Text(t, r, j);
                long x;
                if (!long.TryParse(v, NumberStyles.Integer, CultureInfo.InvariantCulture, out x)) {
                    decimal d;
                    if (decimal.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d) && d == Math.Floor(d)) x = (long)d;
                    else { bad = true; break; }
                }
                if (x <= 0 || x >= 10000000) { bad = true; break; }
                vals.Add(x);
            }
            if (bad || vals.Count < n * 9 / 10) continue;
            Dictionary<long, bool> distinct = new Dictionary<long, bool>();
            foreach (long v in vals) distinct[v] = true;
            int up = 0;
            for (int i = 1; i < vals.Count; i++) if (vals[i] > vals[i - 1]) up++;
            int sc = 2;
            if (distinct.Count * 10 >= vals.Count * 9) sc += 2;
            if (distinct.Count * 100 >= vals.Count * 98) sc += 1;
            if (up * 10 >= (vals.Count - 1) * 7) sc += 3;
            if (up * 10 >= (vals.Count - 1) * 9) sc += 1;
            if (Has(f.Name, "NZ", "NAR", "NOM", "NUM", "NN") || f.Name.ToUpperInvariant().StartsWith("N_")) sc += 2;
            if (sc > numScore) { numScore = sc; bestNum = j; }
        }

        // дата оформления: почти у всех, не убывает
        int bestDate = -1, dateScore = 0;
        for (int j = 0; j < nf; j++) {
            DbfField f = t.Fields[j];
            if (f.Type != 'D' && f.Type != 'T') continue;
            if (filled[j] * 10 < n * 9) continue;
            int up = 0, pairs = 0;
            DateTime prev = DateTime.MinValue;
            for (int r = 0; r < n; r++) {
                object o = t.GetValue(r, j, null);
                if (!(o is DateTime)) continue;
                DateTime d = (DateTime)o;
                if (prev != DateTime.MinValue) { pairs++; if (d >= prev) up++; }
                prev = d;
            }
            int sc = 2;
            if (pairs > 0 && up * 10 >= pairs * 8) sc += 2;
            if (Has(f.Name, "OF", "DAT", "DT")) sc += 1;
            if (Has(f.Name, "VYP", "VIP", "ISP", "NAZ")) sc -= 2;
            if (sc > dateScore) { dateScore = sc; bestDate = j; }
        }

        // «выполнил»: Ф.И.О. (обычно), заполнено не у всех; вместе с ним заполнена дата выполнения
        int bestDone = -1, doneScore = 0, doneDate = -1;
        for (int j = 0; j < nf; j++) {
            DbfField f = t.Fields[j];
            if (f.Type != 'C' || f.Length < 6 || j == bestNum) continue;
            int names = 0;
            for (int r = 0; r < n; r++) if (has[j, r] && NameLike(Text(t, r, j))) names++;
            bool hint = Has(f.Name, "VYP", "VIP", "ISP", "IZP", "WYP", "VYPOL", "VIPOL");
            if (filled[j] == 0 && !hint) continue;
            if (filled[j] > 0 && names * 2 < filled[j] && !hint) continue;
            int sc = filled[j] > 0 ? names * 3 / Math.Max(1, filled[j]) + 1 : 0;
            if (filled[j] < n && filled[j] > 0) sc += 1;
            if (hint) sc += 4;
            if (Has(f.Name, "PRIN", "PRN", "FIO", "OFOR", "OPER")) sc -= 3;
            // дата, заполненная вместе с ним
            int dd = -1;
            for (int k = 0; k < nf; k++) {
                if (k == bestDate || t.Fields[k].Type != 'D' && t.Fields[k].Type != 'T') continue;
                int same = 0;
                for (int r = 0; r < n; r++) if (has[j, r] == has[k, r]) same++;
                if (same * 100 >= n * 85 && filled[k] < n && filled[k] > 0) { dd = k; break; }
            }
            if (dd >= 0) sc += 3;
            if (sc > doneScore) { doneScore = sc; bestDone = j; doneDate = dd; }
        }

        // остальное - для показа: принял, работа, лицевой, счётчик, ФИО абонента
        int taker = -1, work = -1, account = -1, meter = -1, fio = -1, workLen = 0;
        for (int j = 0; j < nf; j++) {
            if (j == bestNum || j == bestDate || j == bestDone || j == doneDate) continue;
            DbfField f = t.Fields[j];
            string up = f.Name.ToUpperInvariant();
            if (up == "FIO" || up == "FAM") { fio = j; continue; }
            if (up == "NAB" || up == "LS" || up == "LIC") { account = j; continue; }
            if (f.Type == 'C' && Has(up, "PRIN", "PRN")) { taker = j; continue; }
            if (Has(up, "NSCH", "NOMSC", "N_SCH", "NSC") || up.StartsWith("SCH")) { if (meter < 0) meter = j; continue; }
            // работа: длинный текст почти у всех, не Ф.И.О.; поле RAB/WORK/SOD - сразу оно
            if (f.Type == 'C' && f.Length >= 15 && filled[j] * 2 >= n) {
                int names = 0;
                for (int r = 0; r < n; r++) if (has[j, r] && NameLike(Text(t, r, j))) names++;
                int sc = Has(up, "RAB", "WORK", "SOD") ? 1000 : names * 2 > filled[j] ? -1 : f.Length;
                if (sc > workLen) { workLen = sc; work = j; }
            }
        }
        if (taker < 0)
            for (int j = 0; j < nf; j++) {
                if (j == bestDone || t.Fields[j].Type != 'C' || j == fio || j == work) continue;
                int names = 0;
                for (int r = 0; r < n; r++) if (has[j, r] && NameLike(Text(t, r, j))) names++;
                if (filled[j] * 100 >= n * 95 && names * 10 >= filled[j] * 8) { taker = j; break; }
            }

        List<string> why = new List<string>();
        if (bestNum >= 0) g.Setup.Number = t.Fields[bestNum].Name; else why.Add("нет поля номера");
        if (bestDate >= 0) g.Setup.Date = t.Fields[bestDate].Name; else why.Add("нет даты, заполненной у всех");
        if (bestDone >= 0) g.Setup.Done = t.Fields[bestDone].Name; else why.Add("нет поля «выполнил»");
        if (doneDate >= 0) g.Setup.DoneDate = t.Fields[doneDate].Name;
        if (work >= 0) g.Setup.Work = t.Fields[work].Name;
        if (taker >= 0) g.Setup.Taker = t.Fields[taker].Name;
        if (account >= 0) g.Setup.Account = t.Fields[account].Name;
        if (meter >= 0) g.Setup.Meter = t.Fields[meter].Name;
        if (fio >= 0) g.Setup.Name = t.Fields[fio].Name;
        g.Setup.How = "сама";
        g.Score = numScore + dateScore + doneScore + (taker >= 0 ? 1 : 0) + (work >= 0 ? 1 : 0) + (account >= 0 ? 2 : 0) + (meter >= 0 ? 1 : 0)
            + (Has(System.IO.Path.GetFileNameWithoutExtension(path), "NZ", "NAR", "ZAK") ? 3 : 0);
        g.Why = why.Count > 0 ? string.Join(", ", why.ToArray()) : "";
        return g;
    }
}

// Названия кодов из справочника базы: вид работы (KVRAB) -> «Определить принадлежность», табельный (TNRVIP) -> «Петров А.А.».
// Справочник ищется сам среди небольших таблиц папки: поле с теми же кодами (лучше - то же имя), у каждого кода - текст.
public class CodeNames {
    public string Table = "", KeyField = "", NameField = "", Note = "";
    readonly Dictionary<string, string> map = new Dictionary<string, string>();

    public int Count { get { return map.Count; } }

    static string Key(string v) {
        v = v.Trim();
        decimal d;
        if (decimal.TryParse(v, NumberStyles.Number, CultureInfo.InvariantCulture, out d)) return d.ToString("0.##########", CultureInfo.InvariantCulture);
        return v.ToUpperInvariant();
    }

    public string Name(string code) {
        string n;
        return map.TryGetValue(Key(code), out n) ? n : null;
    }

    // «таблица:поле кода:поле названия» - как запомнено в naryady.txt
    public string Saved { get { return Table + ":" + KeyField + ":" + NameField; } }

    public static CodeNames Load(string folder, string saved) {
        string[] p = saved.Split(':');
        if (p.Length != 3) return null;
        try {
            string path = Path.Combine(folder, p[0]);
            if (!File.Exists(path)) return null;
            DbfTable t = DbfTable.Load(path, null, null, 20000);
            int k = t.FieldIndex(p[1]), n = t.FieldIndex(p[2]);
            if (k < 0 || n < 0) return null;
            CodeNames c = new CodeNames();
            c.Table = p[0]; c.KeyField = p[1]; c.NameField = p[2];
            c.Fill(t, k, n);
            c.Note = c.Table + " (код " + c.KeyField + ", название " + c.NameField + ", кодов " + c.Count + ")";
            return c;
        } catch (Exception) { return null; }
    }

    void Fill(DbfTable t, int k, int n) {
        for (int r = 0; r < t.Count; r++) {
            string key = Key(DbfTable.Format(t.GetValue(r, k, null), true));
            string name = DbfTable.Format(t.GetValue(r, n, null), true).Trim();
            if (key.Length > 0 && key != "0" && name.Length > 0 && !map.ContainsKey(key)) map[key] = name;
        }
    }

    // field - поле кода в таблице нарядов; codes - его значения в последних нарядах; people - нужны Ф.И.О. (табельные)
    public static CodeNames Find(string folder, string field, List<string> codes, bool people, string skip) {
        Dictionary<string, bool> want = new Dictionary<string, bool>();
        foreach (string c in codes) { string k = Key(c); if (k.Length > 0 && k != "0") want[k] = true; }
        if (want.Count == 0) return null;
        CodeNames best = null;
        int bestScore = 0;
        foreach (string f in Directory.GetFiles(folder)) {
            if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) != 0) continue;
            if (string.Compare(Path.GetFileName(f), skip, StringComparison.OrdinalIgnoreCase) == 0) continue;
            DbfTable h;
            try { h = DbfTable.LoadHeader(f); } catch (Exception) { continue; }
            if (h.Expected > 20000 || h.Expected < 1) continue;
            List<int> texts = new List<int>();
            for (int j = 0; j < h.Fields.Count; j++) if (h.Fields[j].Type == 'C' && h.Fields[j].Length >= 6) texts.Add(j);
            if (texts.Count == 0) continue;
            DbfTable t;
            try { t = DbfTable.Load(f, null, null, 20000); } catch (Exception) { continue; }
            for (int k = 0; k < t.Fields.Count; k++) {
                DbfField kf = t.Fields[k];
                if (!(kf.Type == 'N' && kf.Decimals == 0 || kf.Type == 'C' && kf.Length <= 10)) continue;
                Dictionary<string, int> seen = new Dictionary<string, int>();
                for (int r = 0; r < t.Count; r++) {
                    string v = Key(DbfTable.Format(t.GetValue(r, k, null), true));
                    int c;
                    seen.TryGetValue(v, out c);
                    seen[v] = c + 1;
                }
                int hits = 0, dup = 0;
                foreach (string c in want.Keys) { int n; if (seen.TryGetValue(c, out n)) { hits++; if (n > 1) dup++; } }
                if (hits * 10 < want.Count * 6 || dup * 5 > hits) continue;
                // название: для табельных - больше всего похожих на Ф.И.О., иначе - длинный текст
                int name = -1, nameScore = -1;
                foreach (int j in texts) {
                    if (j == k) continue;
                    int nl = 0, filled = 0;
                    for (int r = 0; r < t.Count && r < 300; r++) {
                        string v = DbfTable.Format(t.GetValue(r, j, null), true).Trim();
                        if (v.Length == 0) continue;
                        filled++;
                        if (NaryadFinder.NameLike(v)) nl++;
                    }
                    if (filled == 0) continue;
                    int sc = people ? nl * 100 / filled : (nl * 2 > filled ? 0 : 50) + t.Fields[j].Length;
                    if (sc > nameScore) { nameScore = sc; name = j; }
                }
                if (name < 0 || people && nameScore < 50) continue;
                int score = hits * 100 / want.Count + (string.Compare(kf.Name, field, StringComparison.OrdinalIgnoreCase) == 0 ? 50 : 0)
                    + (people && kf.Name.ToUpperInvariant().StartsWith("T") ? 10 : 0);
                if (score <= bestScore) continue;
                bestScore = score;
                best = new CodeNames();
                best.Table = Path.GetFileName(f);
                best.KeyField = kf.Name;
                best.NameField = t.Fields[name].Name;
                best.Fill(t, k, name);
                best.Note = best.Table + " (код " + best.KeyField + ", название " + best.NameField + ", кодов " + best.Count + "; нашлось " + hits + " из " + want.Count + ")";
            }
        }
        return best;
    }
}

public delegate string ValueMap(string field, string value);

// найденный наряд (или строка списка, которая не нашлась)
public class NaryadHit {
    public int Line;
    public string Query = "", Result = "";
    public int Year;
    public long Number;
    public int RecNo;
    public int State;               // 0 - выполнен, 1 - не выполнен, 2 - не найден, 3 - не понять номер / нет индекса
    public string Account = "";     // лицевой наряда - для нарядов лицевого и обходов
    public string[] Values;         // значения показываемых полей
}

// наряд из таблицы - для списка нарядов лицевого
public class NaryadRow {
    public int RecNo, Year;
    public long Number;
    public DateTime Date = DateTime.MinValue;
    public string Work = "";
    public bool Done;
    public string[] Values;          // все поля записи текстом

    public static NaryadRow Read(FileStream fs, DbfTable h, NaryadSetup s, int recNo, ValueMap map) {
        long at = h.HeaderLength + (long)(recNo - 1) * h.RecordLength;
        if (recNo < 1 || at + h.RecordLength > fs.Length) return null;
        byte[] rec = new byte[h.RecordLength];
        fs.Seek(at, SeekOrigin.Begin);
        if (DbfTable.ReadUpTo(fs, rec, rec.Length) < rec.Length || rec[0] == (byte)'*') return null;
        DbfTable one = DbfTable.CreateLike(h);
        one.AddRecord(rec, 0, recNo);
        NaryadRow r = new NaryadRow();
        r.RecNo = recNo;
        r.Values = new string[h.Fields.Count];
        for (int j = 0; j < h.Fields.Count; j++) r.Values[j] = DbfTable.Format(one.GetValue(0, j, null), true).Trim();
        r.Number = NaryadBytes.Number(rec, 0, h.Fields[h.FieldIndex(s.Number)]);
        object d = one.GetValue(0, h.FieldIndex(s.Date), null);
        if (d is DateTime) { r.Date = (DateTime)d; r.Year = r.Date.Year; }
        if (s.YearFrom.Length > 0 && h.FieldIndex(s.YearFrom) >= 0) {
            int y = NaryadBytes.Year(rec, 0, h.Fields[h.FieldIndex(s.YearFrom)]);
            if (y > 0) r.Year = y;
        }
        if (s.Work.Length > 0 && h.FieldIndex(s.Work) >= 0) r.Work = r.Values[h.FieldIndex(s.Work)];
        string done = r.Values[h.FieldIndex(s.Done)];
        r.Done = done.Length > 0 && done != "0";
        if (map != null) for (int j = 0; j < h.Fields.Count; j++) r.Values[j] = map(h.Fields[j].Name, r.Values[j]);
        if (s.Work.Length > 0 && h.FieldIndex(s.Work) >= 0) r.Work = r.Values[h.FieldIndex(s.Work)];
        return r;
    }
}

// Таблица с индексом программы базы по лицевому (NAB в своём .CDX): все записи лицевого сразу, за все годы
public class AccountTable {
    public string Path = "", Name = "";
    public LiveBase Base;
    public bool Indexed;            // индекс NAB есть и проверен
    public string Note = "";

    // открыть и проверить индекс (в фоне - читает заголовок, первые записи и индекс)
    public static AccountTable Open(string path) {
        AccountTable t = new AccountTable();
        t.Path = path;
        t.Name = System.IO.Path.GetFileName(path);
        try {
            t.Base = LiveBase.Open(path);
            IndexTag tag = t.Base.Header.FieldIndex("NAB") >= 0 ? t.Base.TagFor("NAB") : null;
            t.Indexed = tag != null;
            t.Note = tag != null ? "индекс " + tag.Label : "нет годного индекса по NAB";
        } catch (Exception ex) { t.Note = "не открылась: " + ex.Message; }
        return t;
    }

    // записи лицевого: таблица из найденных записей и их строки (только этот лицевой)
    public DbfTable Find(string ls, out List<int> rows) {
        rows = new List<int>();
        SearchResult r = Base.Search(ls, SearchMode.Account, null, 3000, false);
        if (r.Error != null) throw new Exception(r.Error);
        int nab = r.Table.FieldIndex("NAB");
        string key = NaryadBytes.Key(OnlyDigits(ls));
        foreach (int row in r.Rows)
            if (nab >= 0 && NaryadBytes.Key(OnlyDigits(DbfTable.Format(r.Table.GetValue(row, nab, null), true))) == key) rows.Add(row);
        return r.Table;
    }

    public static string OnlyDigits(string s) {
        StringBuilder sb = new StringBuilder();
        foreach (char c in s) if (c >= '0' && c <= '9') sb.Append(c);
        return sb.ToString();
    }
}

// строка обходов (показание)
public class ObhodRow {
    public DateTime Date = DateTime.MinValue;
    public string[] Values;
    public string Table = "", Fio = "";
    public decimal Reading;
    public bool HasReading;
    public int Order, RecNo;        // таблица по порядку и запись - для одинаковых дат: позже внесённая - выше
}

// Обходы лицевого - как окно Ctrl+O программы базы: дата проверки, показание, ср. сутки, № участка, код и его название.
// Таблицы OBH (текущие) и ARCOBH... (архив) - с индексом NAB программы базы; название кода - из справочника с тем же полем.
public class ObhodSource {
    public readonly List<AccountTable> Tables = new List<AccountTable>();
    public readonly List<string> Columns = new List<string>();     // поля в столбцах (по первой таблице)
    public readonly List<string> Titles = new List<string>();
    public string CodeField = "", Note = "";
    public CodeBook Names;
    public int NameColumn = -1;                                    // столбец «Наименование» (после кода)

    public static ObhodSource Find(string folder) {
        ObhodSource o = new ObhodSource();
        List<string> files = new List<string>();
        foreach (string f in Directory.GetFiles(folder)) {
            string n = Path.GetFileNameWithoutExtension(f).ToUpperInvariant();
            if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) == 0 && n.Contains("OBH")) files.Add(f);
        }
        // сначала текущие (OBH), потом архивы по порядку
        files.Sort(delegate(string a, string b) {
            string x = Path.GetFileNameWithoutExtension(a).ToUpperInvariant(), y = Path.GetFileNameWithoutExtension(b).ToUpperInvariant();
            int ra = x == "OBH" ? 0 : x.StartsWith("ARC") ? 1 : 2, rb = y == "OBH" ? 0 : y.StartsWith("ARC") ? 1 : 2;
            return ra != rb ? ra.CompareTo(rb) : string.Compare(x, y, StringComparison.Ordinal);
        });
        List<string> notes = new List<string>();
        foreach (string f in files) {
            DbfTable h;
            try { h = DbfTable.LoadHeader(f); } catch (Exception) { continue; }
            bool date = false;
            foreach (DbfField fl in h.Fields) if (fl.Type == 'D') date = true;
            if (h.FieldIndex("NAB") < 0 || !date) continue;
            AccountTable t = AccountTable.Open(f);
            notes.Add(t.Name + " (" + h.Expected + "): " + t.Note);
            if (t.Indexed) o.Tables.Add(t);
        }
        o.Note = notes.Count > 0 ? string.Join("; ", notes.ToArray()) : "таблиц обходов (OBH, ARCOBH...) с лицевым и датой в папке нет";
        if (o.Tables.Count > 0) o.Arrange(folder);
        return o;
    }

    public const string Average = "*sr";      // столбец «Ср. сут.» - считается: (показание - предыдущее) / дней между проверками
    public string Reading = "", DateField = "", NameField = "";

    // столбцы как в окне Ctrl+O: № абонента, дата пров., показ., ср. сут., № уч., код, наименование, остальное (Ф.И.О. - в заголовок)
    void Arrange(string folder) {
        DbfTable h = Tables[0].Base.Header;
        DbfTable sample = Tables[0].Base.Sample;
        List<int> order = new List<int>();
        int nab = h.FieldIndex("NAB");
        if (nab >= 0) order.Add(nab);
        // дата проверки: DPR, иначе первая дата
        int dpr = h.FieldIndex("DPR");
        for (int j = 0; j < h.Fields.Count && dpr < 0; j++) if (h.Fields[j].Type == 'D') dpr = j;
        if (dpr >= 0) { order.Add(dpr); DateField = h.Fields[dpr].Name; }
        int pok = h.FieldIndex("POK");
        for (int j = 0; j < h.Fields.Count && pok < 0; j++) if (h.Fields[j].Name.ToUpperInvariant().StartsWith("POK")) pok = j;
        if (pok >= 0) { order.Add(pok); Reading = h.Fields[pok].Name; }
        int uch = h.FieldIndex("N_UCH");
        // код: KOD.../K_.../VID.../IST... или маленькие целые с немногими значениями
        int code = -1;
        for (int j = 0; j < h.Fields.Count && code < 0; j++) {
            string n = h.Fields[j].Name.ToUpperInvariant();
            if (j != uch && !order.Contains(j) && h.Fields[j].Type == 'N' && (n.StartsWith("KOD") || n.StartsWith("KD") || n.StartsWith("K_") || n.Contains("VID") || n.Contains("IST"))) code = j;
        }
        for (int j = 0; j < h.Fields.Count && code < 0; j++) {
            DbfField f = h.Fields[j];
            if (j == uch || order.Contains(j) || f.Type != 'N' || f.Decimals != 0 || f.Length > 4) continue;
            Dictionary<string, bool> d = new Dictionary<string, bool>();
            for (int r = 0; r < sample.Count; r++) d[DbfTable.Format(sample.GetValue(r, j, null), true)] = true;
            if (d.Count >= 2 && d.Count <= 60) code = j;
        }
        // название кода - в самой таблице (K_RESO -> N_RESO), иначе справочник
        int name = -1;
        if (code >= 0) {
            CodeField = h.Fields[code].Name;
            string cu = CodeField.ToUpperInvariant();
            string tail = cu.StartsWith("K_") ? cu.Substring(2) : cu.StartsWith("KOD") ? cu.Substring(3) : "";
            for (int j = 0; j < h.Fields.Count && name < 0; j++) {
                string n = h.Fields[j].Name.ToUpperInvariant();
                if (h.Fields[j].Type == 'C' && (tail.Length > 0 && n == "N_" + tail || n.StartsWith("NAIM") || n.StartsWith("NAME"))) name = j;
            }
            if (name >= 0) NameField = h.Fields[name].Name;
            else {
                string dir = CodeDirectory(folder, CodeField, sample, code);
                if (dir != null) Names = CodeBook.Get(folder, dir, new string[] { CodeField });
            }
        }
        int fio = h.FieldIndex("FIO");
        Add(h, nab, "№ Абонента");
        Add(h, dpr, "Дата пров.");
        Add(h, pok, "Показ.");
        if (pok >= 0 && dpr >= 0) { Columns.Add(Average); Titles.Add("Ср. сут."); }
        Add(h, uch, "№ Уч.");
        if (code >= 0) {
            Add(h, code, "Код");
            if (name >= 0) Add(h, name, "Наименование");
            else { Columns.Add(""); Titles.Add("Наименование"); NameColumn = Columns.Count - 1; }
        }
        for (int j = 0; j < h.Fields.Count; j++) if (j != fio && !Columns.Contains(h.Fields[j].Name)) Add(h, j, FieldNames.Label(h.Fields[j].Name) ?? h.Fields[j].Name);
        Columns.Add("");
        Titles.Add("Таблица");
    }

    void Add(DbfTable h, int j, string title) {
        if (j < 0 || Columns.Contains(h.Fields[j].Name)) return;
        Columns.Add(h.Fields[j].Name);
        Titles.Add(title);
    }

    // справочник кодов: небольшая таблица с полем того же имени (каждый код один раз, при нём текст), где нашлось больше кодов
    static string CodeDirectory(string folder, string field, DbfTable sample, int code) {
        Dictionary<string, bool> codes = new Dictionary<string, bool>();
        for (int r = 0; r < sample.Count; r++) {
            string v = DbfTable.Format(sample.GetValue(r, code, null), true).Trim();
            if (v.Length > 0 && v != "0") codes[v] = true;
        }
        string best = null;
        int bestHits = 0;
        foreach (string f in Directory.GetFiles(folder)) {
            if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) != 0) continue;
            if (Path.GetFileNameWithoutExtension(f).ToUpperInvariant().Contains("OBH")) continue;
            try {
                DbfTable h = DbfTable.LoadHeader(f);
                int k = h.FieldIndex(field);
                if (k < 0 || h.Expected > 5000) continue;
                bool text = false;
                foreach (DbfField fl in h.Fields) if (fl.Type == 'C' && fl.Length >= 8) text = true;
                if (!text) continue;
                DbfTable t = DbfTable.Load(f, null, null, 5000);
                Dictionary<string, int> seen = new Dictionary<string, int>();
                for (int r = 0; r < t.Count; r++) {
                    string v = DbfTable.Format(t.GetValue(r, k, null), true).Trim();
                    int c;
                    seen.TryGetValue(v, out c);
                    seen[v] = c + 1;
                }
                int hits = 0;
                bool unique = true;
                foreach (string c in codes.Keys) { int n; if (seen.TryGetValue(c, out n)) { hits++; if (n > 1) unique = false; } }
                if (unique && hits > bestHits) { bestHits = hits; best = Path.GetFileName(f); }
            } catch (Exception) { }
        }
        return codes.Count > 0 && bestHits * 10 >= codes.Count * 6 ? best : null;
    }

    // обходы лицевого из всех таблиц, новые сверху; одинаковые строки (в текущих и в архиве) - один раз
    public List<ObhodRow> Rows(string ls, out string error) {
        error = null;
        List<ObhodRow> r = new List<ObhodRow>();
        Dictionary<string, bool> seen = new Dictionary<string, bool>();
        foreach (AccountTable t in Tables) {
            List<int> rows;
            DbfTable part;
            try { part = t.Find(ls, out rows); } catch (Exception ex) { error = t.Name + ": " + ex.Message; continue; }
            int date = DateField.Length > 0 ? part.FieldIndex(DateField) : -1;
            for (int j = 0; j < part.Fields.Count && date < 0; j++) if (part.Fields[j].Type == 'D') date = j;
            int pok = Reading.Length > 0 ? part.FieldIndex(Reading) : -1, fio = part.FieldIndex("FIO");
            foreach (int row in rows) {
                ObhodRow o = new ObhodRow();
                o.Table = t.Name;
                o.Order = Tables.IndexOf(t);
                o.RecNo = part.RecNos[row];
                if (fio >= 0) o.Fio = DbfTable.Format(part.GetValue(row, fio, null), true).Trim();
                object pv = pok >= 0 ? part.GetValue(row, pok, null) : null;
                if (pv is decimal) { o.Reading = (decimal)pv; o.HasReading = true; }
                o.Values = new string[Columns.Count];
                for (int c = 0; c < Columns.Count; c++) {
                    if (Columns[c].Length == 0 || Columns[c] == Average) continue;
                    int j = part.FieldIndex(Columns[c]);
                    if (j >= 0) o.Values[c] = DbfTable.Format(part.GetValue(row, j, null), false).Trim();
                }
                if (NameColumn > 0 && Names != null) o.Values[NameColumn] = Names.Name(o.Values[NameColumn - 1] ?? "");
                if (NameColumn > 0 && Names == null) o.Values[NameColumn] = "";
                o.Values[Columns.Count - 1] = t.Name;
                object d = date >= 0 ? part.GetValue(row, date, null) : null;
                if (d is DateTime) o.Date = (DateTime)d;
                string key = o.Date.Ticks + "|" + string.Join("|", o.Values, 0, Columns.Count - 1);
                if (seen.ContainsKey(key)) continue;
                seen[key] = true;
                r.Add(o);
            }
        }
        r.Sort(delegate(ObhodRow a, ObhodRow b) {
            int c = b.Date.CompareTo(a.Date);
            if (c != 0) return c;
            if (a.Order != b.Order) return a.Order.CompareTo(b.Order);
            return b.RecNo.CompareTo(a.RecNo);
        });
        // ср. сутки: (показание - следующее ниже, более раннее) / дней между ними; один день - 0 (как в программе базы)
        int sc = Columns.IndexOf(Average);
        if (sc >= 0)
            for (int i = 0; i < r.Count; i++) {
                decimal avg = 0;
                if (i + 1 < r.Count && r[i].HasReading && r[i + 1].HasReading && r[i].Date != DateTime.MinValue && r[i + 1].Date != DateTime.MinValue) {
                    int days = (r[i].Date - r[i + 1].Date).Days;
                    if (days > 0) avg = (r[i].Reading - r[i + 1].Reading) / days;
                }
                r[i].Values[sc] = avg.ToString("0.000", CultureInfo.InvariantCulture);
            }
        return r;
    }
}

// Окно «Наряды»: номер или список номеров -> выполнен (зелёным) / не выполнен (красным)
public class NaryadForm : Form {
    readonly string dir, folder;
    readonly LiveBase live;          // база абонентов - адрес лицевого (может быть null)
    // наряды лицевого (как окно Ctrl+Z программы базы): слева список, справа все поля выбранного
    readonly Label lsHead = new Label();
    readonly ListView lsList = new ListView(), details = new ListView();
    readonly List<NaryadRow> lsRows = new List<NaryadRow>();
    // обходы лицевого (как окно Ctrl+O программы базы) и наряды лицевого по индексу NAB программы базы (все годы)
    readonly Label obHead = new Label();
    readonly ListView obList = new ListView();
    ObhodSource obhod;
    AccountTable nzByLs;
    NaryadHit shownHit;
    CodeNames workNames, staffNames;                       // вид работы и табельные -> названия, Ф.И.О.
    Dictionary<long, string> plan = new Dictionary<long, string>();   // UNNAR -> «назначено на дату» (GRAF_NZ)
    bool building, pendingRun;                             // индексы создаются в фоне; поиск - когда будут готовы
    readonly string setupFile;
    NaryadSetup setup;
    DbfTable header;                 // поля таблицы нарядов
    readonly Dictionary<int, NaryadIndex> indexes = new Dictionary<int, NaryadIndex>();
    readonly Label indexLabel = new Label(), tableLabel = new Label();
    internal readonly TextBox input = new TextBox();
    readonly DataGridView grid = new DataGridView();
    internal readonly Label status = new Label();
    readonly Button findButton = new Button();
    readonly LinkLabel setupLink = new LinkLabel();
    public const int Years = 6;      // индексы - за столько последних лет (создаются при первом поиске, дальше дополняются сами)
    readonly List<NaryadHit> hits = new List<NaryadHit>();
    readonly List<string> columns = new List<string>();     // поля таблицы в столбцах
    readonly List<string> titles = new List<string>();
    bool busy;
    volatile bool stop;

    static Color DoneColor { get { return Look.RowGood; } }
    static Color OpenColor { get { return Look.RowBad; } }
    static Color MissColor { get { return Look.RowOther; } }
    Font bold, headFont;             // «ВЫПОЛНЕН» / «НЕ ВЫПОЛНЕН» - жирным (один шрифт на все ячейки); заголовок нарядов лицевого

    public bool Busy { get { return busy || building || pendingRun; } }

    public NaryadForm(string dir, string folder) : this(dir, folder, null) { }

    public NaryadForm(string dir, string folder, LiveBase live) {
        Font = Look.Base;
        Look.Wear(this);
        this.live = live;
        if (NaryadData.ProgramDir.Length == 0) NaryadData.ProgramDir = dir;
        this.dir = dir;
        this.folder = folder;
        setupFile = Path.Combine(dir, "naryady.txt");
        setup = NaryadSetup.Load(setupFile);
        Text = "Наряды - выполнен или нет (только чтение)";
        Rectangle wa = Screen.PrimaryScreen.WorkingArea;
        Size = new Size(Math.Min(1200, wa.Width), Math.Min(900, wa.Height));
        StartPosition = FormStartPosition.CenterScreen;

        SplitContainer split = new SplitContainer();
        split.Dock = DockStyle.Fill;
        split.Orientation = Orientation.Horizontal;

        Panel head = new Panel();
        head.Dock = DockStyle.Top;
        head.Height = 72;
        indexLabel.AutoSize = false;
        indexLabel.Location = new Point(10, 8);
        indexLabel.Size = new Size(900, 20);
        indexLabel.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
        tableLabel.AutoSize = false;
        tableLabel.Location = new Point(10, 28);
        tableLabel.Size = new Size(800, 18);
        tableLabel.ForeColor = SystemColors.GrayText;
        tableLabel.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
        setupLink.Text = "таблица не та?";
        setupLink.AutoSize = true;
        setupLink.Anchor = AnchorStyles.Right | AnchorStyles.Top;
        setupLink.LinkClicked += delegate { ChooseTable(); };
        new ToolTip().SetToolTip(setupLink, "Выбрать таблицу нарядов и её поля вручную (если программа взяла не ту)");
        Label l2 = new Label();
        l2.Text = "Номера нарядов ПОЛНОСТЬЮ - год и номер: 202655555 (или 2026-55555), по одному в строке (можно столбик из Excel). Ctrl+Enter - найти.";
        l2.AutoSize = true;
        l2.Location = new Point(10, 50);
        head.Controls.AddRange(new Control[] { indexLabel, tableLabel, setupLink, l2 });
        head.Resize += delegate {
            setupLink.Location = new Point(head.ClientSize.Width - 10 - setupLink.PreferredWidth, 28);
            tableLabel.Width = Math.Max(100, setupLink.Left - 10 - tableLabel.Left);
            indexLabel.Width = Math.Max(100, head.ClientSize.Width - 20);
        };

        input.Multiline = true;
        input.AcceptsReturn = true;
        input.ScrollBars = ScrollBars.Both;
        input.WordWrap = false;
        input.Dock = DockStyle.Fill;
        input.Font = new Font(FontFamily.GenericMonospace, 11f);
        ResultColumns.SelectAllKey(input);
        input.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Control && e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Run(); } };

        Panel buttons = new Panel();
        buttons.Dock = DockStyle.Right;
        buttons.Width = 130;
        findButton.Text = "Найти";
        findButton.Location = new Point(10, 6);
        findButton.Size = new Size(110, 32);
        findButton.Click += delegate { Run(); };
        Button clear = new Button();
        clear.Text = "Очистить";
        clear.Location = new Point(10, 44);
        clear.Size = new Size(110, 28);
        clear.Click += delegate { input.Clear(); input.Focus(); };
        buttons.Controls.Add(findButton);
        buttons.Controls.Add(clear);

        split.Panel1.Controls.Add(input);
        split.Panel1.Controls.Add(buttons);
        split.Panel1.Controls.Add(head);

        grid.Dock = DockStyle.Fill;
        grid.VirtualMode = true;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        grid.CellValueNeeded += delegate(object s, DataGridViewCellValueEventArgs e) { if (e.RowIndex < hits.Count) e.Value = Cell(hits[e.RowIndex], e.ColumnIndex); };
        CopyText.Grid(grid);
        grid.CellFormatting += delegate(object s, DataGridViewCellFormattingEventArgs e) {
            if (e.RowIndex < 0 || e.RowIndex >= hits.Count) return;
            int st = hits[e.RowIndex].State;
            e.CellStyle.BackColor = st == 0 ? DoneColor : st == 1 ? OpenColor : MissColor;
            e.CellStyle.SelectionBackColor = st == 0 ? Look.SelGood : st == 1 ? Look.SelBad : Look.SelOther;
            if (e.ColumnIndex == 3 && st <= 1) {
                if (bold == null) bold = new Font(grid.Font, FontStyle.Bold);
                e.CellStyle.Font = bold;
            }
        };

        Panel bottom = new Panel();
        bottom.Dock = DockStyle.Bottom;
        bottom.Height = 40;
        status.Dock = DockStyle.Fill;
        status.TextAlign = ContentAlignment.MiddleLeft;
        status.Text = "Выполнен (заполнено «Выполнил Н-З») - зелёным, не выполнен - красным, не найден - серым.";
        Button excel = new Button();
        excel.Text = "В Excel";
        excel.Dock = DockStyle.Right;
        excel.Width = 120;
        excel.Click += delegate { Export(); };
        bottom.Controls.Add(status);
        bottom.Controls.Add(excel);

        // итог сверху, под ним - наряды лицевого выбранной строки
        SplitContainer lower = new SplitContainer();
        lower.Dock = DockStyle.Fill;
        lower.Orientation = Orientation.Horizontal;
        lower.Panel1.Controls.Add(grid);
        lower.Panel2.Controls.Add(BuildAccountPanel());
        grid.SelectionChanged += delegate {
            // окно ещё не показано (или закрывается) - списки не трогать
            if (!lsList.IsHandleCreated || IsDisposed || grid.CurrentRow == null || grid.CurrentRow.Index >= hits.Count) return;
            if (hits[grid.CurrentRow.Index] == shownHit) return;      // выделяют поля той же строки - наряды лицевого те же
            try { ShowAccount(hits[grid.CurrentRow.Index]); } catch (Exception ex) { lsHead.Text = "Наряды лицевого не показались: " + ex.Message; }
        };
        split.Panel2.Controls.Add(lower);
        split.Panel2.Controls.Add(bottom);
        Shown += delegate { lower.SplitterDistance = Math.Max(120, lower.Height * 2 / 5); };
        Controls.Add(split);
        Shown += delegate { split.SplitterDistance = 170; input.Focus(); Prepare(); };
        FormClosing += delegate { stop = true; };

    }

    protected override void Dispose(bool disposing) {
        base.Dispose(disposing);
        if (disposing) { if (bold != null) bold.Dispose(); if (headFont != null) headFont.Dispose(); }
    }

    // года индексов: последние Years лет
    static List<int> Wanted() {
        List<int> r = new List<int>();
        int now = DateTime.Today.Year;
        for (int y = now - Years + 1; y <= now; y++) r.Add(y);
        return r;
    }

    string TablePath { get { return Path.Combine(folder, setup.Table); } }

    void Post(MethodInvoker m) {
        try { if (!IsDisposed && IsHandleCreated) BeginInvoke(m); } catch (Exception) { }
    }

    void SetBusy(bool on, string text) {
        busy = on;
        findButton.Text = on ? "Стоп" : "Найти";
        setupLink.Enabled = !on;
        if (text != null) status.Text = text;
    }

    // таблица нарядов: запомненная, иначе - найти самой
    void Prepare() {
        // таблицу «сама» нашла прежняя программа - эту же таблицу посмотреть заново (новая знает больше), не та - искать среди всех
        if (setup.Ready && setup.How == "сама" && setup.Version < NaryadSetup.CurrentVersion && File.Exists(TablePath)) {
            try {
                NaryadGuess g = NaryadFinder.Judge(TablePath);
                if (g != null && g.Score >= 100) {
                    g.Setup.Year = setup.Year;
                    if (string.Compare(g.Setup.Table, setup.Table, StringComparison.OrdinalIgnoreCase) == 0) { g.Setup.WorkBook = setup.WorkBook; g.Setup.StaffBook = setup.StaffBook; }
                    setup = g.Setup;
                    setup.Save(setupFile);
                    lock (indexes) indexes.Clear();
                }
            } catch (Exception) { }
        }
        if (setup.Ready && (setup.How == "вручную" || setup.Version >= NaryadSetup.CurrentVersion) && File.Exists(TablePath)) {
            try {
                header = DbfTable.LoadHeader(TablePath);
                if (header.FieldIndex(setup.Number) >= 0 && header.FieldIndex(setup.Date) >= 0 && header.FieldIndex(setup.Done) >= 0) { Ready(); return; }
            } catch (Exception) { }
        }
        FindTable(false);
    }

    void Ready() {
        BuildColumns();
        tableLabel.Text = "Таблица нарядов " + setup.Describe() + (setup.How == "сама" ? " (найдена программой - если не та, нажмите справа)" : "");
        ShowIndex();
        OpenAccountTables();
        StartBuild();
    }

    // индексы последних лет - сразу при открытии окна, в фоне (первый раз - создать, потом - дописать новые наряды)
    void StartBuild() {
        if (building || header == null) return;
        building = true;
        stop = false;
        List<int> years = Wanted();
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            List<string> notes = new List<string>();
            string err = null;
            try { EnsureAll(years, notes); } catch (Exception ex) { err = ex.Message; }
            Post(delegate {
                building = false;
                findButton.Text = "Найти";
                ShowIndex();
                status.Text = err != null ? "Индексы нарядов не созданы: " + err : stop ? "Создание индексов остановлено - продолжится при поиске." :
                    notes.Count > 0 ? "Индексы нарядов: " + string.Join("; ", notes.ToArray()) + "." : "Индексы нарядов готовы.";
                if (pendingRun) { pendingRun = false; if (!stop) Run(); }
            });
        });
        th.IsBackground = true;
        th.Start();
    }

    public static List<string> Codes(DbfTable t, string field) {
        List<string> r = new List<string>();
        int j = t.FieldIndex(field);
        if (j < 0) return r;
        for (int i = 0; i < t.Count; i++) {
            string v = DbfTable.Format(t.GetValue(i, j, null), true).Trim();
            if (v.Length > 0 && v != "0" && !r.Contains(v)) r.Add(v);
        }
        return r;
    }

    // в фоне: таблица нарядов и таблицы обходов - по индексу NAB программы базы (лицевой -> все записи)
    void OpenAccountTables() {
        string fold = folder;
        NaryadSetup st = setup;
        obHead.Text = "Обходы лицевого (как Ctrl+O) - открываю таблицы обходов...";
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            NaryadData d = NaryadData.Load(fold, st);
            NaryadData.Share(fold, d);       // карточкам абонента (Ctrl+Z, Ctrl+O) - те же данные
            Post(delegate {
                nzByLs = d.ByLs;
                obhod = d.Obhod ?? new ObhodSource();
                workNames = d.Work;
                staffNames = d.Staff;
                plan = d.Plan;
                BuildObhodColumns();
                obHead.Text = obhod.Tables.Count > 0 ? "Обходы лицевого (как Ctrl+O) - выберите найденный наряд" : "Обходы (Ctrl+O): " + obhod.Note;
                if (shownHit != null) ShowAccount(shownHit);
            });
        });
        th.IsBackground = true;
        th.Start();
    }

    void BuildObhodColumns() {
        obList.Columns.Clear();
        if (obhod == null) return;
        for (int c = 0; c < obhod.Titles.Count; c++) {
            string t = obhod.Titles[c];
            obList.Columns.Add(t, t == "Наименование" ? 240 : t == "№ Абонента" ? 100 : t == "Таблица" ? 90 : t.Contains("Дата") ? 85 : 70);
        }
    }

    // обходы лицевого - внизу
    void ShowObhod(string ls) {
        obList.Items.Clear();
        if (obhod == null || obhod.Tables.Count == 0) return;
        if (ls.Length == 0) { obHead.Text = "Обходы лицевого - у наряда нет лицевого"; return; }
        string err;
        List<ObhodRow> rows = obhod.Rows(ls, out err);
        List<string> names = new List<string>();
        foreach (AccountTable t in obhod.Tables) names.Add(t.Name);
        string fio = rows.Count > 0 ? rows[0].Fio : "";
        obHead.Text = "Обходы лицевого " + ls + (fio.Length > 0 ? " " + fio : "") + " (как Ctrl+O): записей " + rows.Count + "  - таблицы " + string.Join(", ", names.ToArray())
            + (err != null ? "; ошибка: " + err : "");
        foreach (ObhodRow r in rows) {
            string[] v = new string[r.Values.Length];
            for (int i = 0; i < v.Length; i++) v[i] = r.Values[i] ?? "";
            obList.Items.Add(new ListViewItem(v));
        }
        if (obList.Items.Count > 0) obList.Items[0].Selected = true;
    }

    // поиск таблицы нарядов среди таблиц папки базы (в фоне)
    void FindTable(bool showChoice) {
        if (folder == null || !Directory.Exists(folder)) { tableLabel.Text = "Папка базы не найдена - откройте базу в главном окне."; return; }
        SetBusy(true, "Ищу таблицу нарядов в папке " + folder + "...");
        stop = false;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            List<NaryadGuess> list = null;
            string err = null;
            try { list = NaryadFinder.Guess(folder, delegate(int done, int total) { Post(delegate { status.Text = "Ищу таблицу нарядов: таблиц просмотрено " + done + " из " + total + "..."; }); }); }
            catch (Exception ex) { err = ex.Message; }
            Post(delegate { TableFound(list, err, showChoice); });
        });
        th.IsBackground = true;
        th.Start();
    }

    void TableFound(List<NaryadGuess> list, string err, bool showChoice) {
        SetBusy(false, "");
        if (err != null) { status.Text = "Не удалось посмотреть таблицы базы: " + err; return; }
        Report.Line("");
        Report.Line("Наряды: таблицы папки базы, похожие на наряды (по последним записям; данных нет - только поля и вид значений):");
        for (int i = 0; i < list.Count && i < 6; i++) {
            NaryadGuess g = list[i];
            Report.Line("  " + g.Setup.Table + " - записей " + g.Records + ", баллов " + g.Score + (g.Usable ? ": " + g.Setup.Describe() : ": не подходит - " + g.Why)
                + (g.Setup.Work.Length > 0 ? ", работа - " + g.Setup.Work : "") + (g.Setup.Taker.Length > 0 ? ", принял - " + g.Setup.Taker : "")
                + (g.Setup.Account.Length > 0 ? ", лицевой - " + g.Setup.Account : ""));
            if (i < 3) Report.Fields(g.Sample, "      ");
        }
        // остальные таблицы с датами - только имена полей (по ним можно найти, например, таблицу окна Ctrl+O программы базы)
        Report.Line("Наряды: все таблицы папки с датами (записей; поля):");
        foreach (NaryadGuess g in list) {
            List<string> names = new List<string>();
            foreach (DbfField f in g.Sample.Fields) names.Add(f.Name + " " + f.Type + f.Length);
            Report.Line("  " + g.Setup.Table + " (" + g.Records + "): " + string.Join(", ", names.ToArray()));
        }
        if (showChoice || list.Count == 0 || !list[0].Usable) {
            if (list.Count == 0 || !list[0].Usable)
                status.Text = "Таблица нарядов сама не нашлась - выберите её (кнопка «Таблица нарядов...»). Если не знаете какая - нажмите «Отчёт» в главном окне и пришлите otchet.txt.";
            ChooseFrom(list);
            return;
        }
        setup.Table = list[0].Setup.Table;
        NaryadSetup g0 = list[0].Setup;
        setup.Number = g0.Number; setup.Date = g0.Date; setup.Done = g0.Done; setup.DoneDate = g0.DoneDate; setup.Work = g0.Work; setup.Taker = g0.Taker;
        setup.Account = g0.Account; setup.Meter = g0.Meter; setup.Name = g0.Name; setup.How = "сама";
        setup.Version = NaryadSetup.CurrentVersion; setup.WorkBook = ""; setup.StaffBook = "";
        setup.Save(setupFile);
        try { header = DbfTable.LoadHeader(TablePath); } catch (Exception ex) { status.Text = "Таблица " + setup.Table + " не открывается: " + ex.Message; return; }
        status.Text = "Таблица нарядов найдена: " + setup.Table + ". Выполнен - зелёным, не выполнен - красным, не найден - серым.";
        Ready();
    }

    internal void ChooseTable() {
        if (busy) return;
        FindTable(true);
    }

    void ChooseFrom(List<NaryadGuess> list) {
        if (list == null || list.Count == 0) { MessageBox.Show(this, "В папке базы нет таблиц с датами - наряды не найти.", Text); return; }
        using (NaryadSetupDialog d = new NaryadSetupDialog(list, setup)) {
            if (d.ShowDialog(this) != DialogResult.OK) { if (setup.Ready) Ready(); return; }
            NaryadSetup s = d.Result;
            s.Year = setup.Year;
            s.How = "вручную";
            s.Version = NaryadSetup.CurrentVersion;
            NaryadData.Reset();
            setup = s;
            setup.Save(setupFile);
            lock (indexes) indexes.Clear();
            try { header = DbfTable.LoadHeader(TablePath); } catch (Exception ex) { status.Text = "Таблица " + setup.Table + " не открывается: " + ex.Message; return; }
            Report.Line("Наряды: таблица выбрана вручную - " + setup.Describe());
            Ready();
        }
    }

    // столбцы итога: что искали, наряд, состояние и поля таблицы
    void BuildColumns() {
        grid.Columns.Clear();
        columns.Clear();
        titles.Clear();
        AddColumn("№", 30);
        AddColumn("Искали", 90);
        AddColumn("Наряд", 85);
        AddColumn("Состояние", 110);
        string[][] fields = { new string[] { setup.Date, "Дата оф." }, new string[] { setup.Work, "Работа" }, new string[] { setup.Account, "Лицевой" },
            new string[] { setup.Name, "Ф.И.О." }, new string[] { setup.Taker, "Принял Н-З" }, new string[] { setup.Done, "Выполнил Н-З" },
            new string[] { setup.DoneDate, "Дата выпол." }, new string[] { setup.Meter, "Номер сч." } };
        foreach (string[] f in fields) {
            if (f[0].Length == 0 || header == null || header.FieldIndex(f[0]) < 0) continue;
            columns.Add(f[0]);
            titles.Add(f[1]);
            AddColumn(f[1], f[1] == "Работа" ? 200 : f[1].Contains("Дата") ? 75 : 120);
            // после лицевого - абонент из базы абонентов (Ф.И.О., адрес), если в таблице нарядов Ф.И.О. нет
            if (f[1] == "Лицевой" && live != null && setup.Name.Length == 0) { columns.Add("*abon"); titles.Add("Абонент"); AddColumn("Абонент", 220); }
        }
        grid.RowCount = hits.Count;
        grid.Invalidate();
    }

    void AddColumn(string title, int weight) {
        DataGridViewTextBoxColumn c = new DataGridViewTextBoxColumn();
        c.HeaderText = title;
        c.FillWeight = weight;
        c.SortMode = DataGridViewColumnSortMode.NotSortable;
        grid.Columns.Add(c);
    }

    string Cell(NaryadHit h, int c) {
        if (c == 0) return h.Line.ToString();
        if (c == 1) return h.Query;
        if (c == 2) return h.Number > 0 ? FullNumber(h.Year, h.Number) : "";
        if (c == 3) return h.Result;
        int k = c - 4;
        return h.Values != null && k >= 0 && k < h.Values.Length ? h.Values[k] : "";
    }

    // ---------- индекс года ----------

    NaryadIndex IndexOf(int year) {
        NaryadIndex x;
        lock (indexes) if (indexes.TryGetValue(year, out x)) return x;
        try { x = NaryadIndex.Load(NaryadIndex.FileFor(dir, year)); } catch (Exception) { x = null; }
        if (x != null && header != null && !x.Fits(setup, header)) x = null;     // от другой таблицы - не годится
        if (x != null) lock (indexes) indexes[year] = x;
        return x;
    }

    // состояние индексов последних лет
    void ShowIndex() {
        if (header == null) { indexLabel.Text = ""; return; }
        List<int> years = Wanted();
        int count = 0, have = 0;
        DateTime updated = DateTime.MinValue;
        foreach (int y in years) {
            NaryadIndex x = IndexOf(y);
            if (x == null) continue;
            have++;
            count += x.Count;
            if (x.Updated > updated) updated = x.Updated;
        }
        string span = years[0] + "-" + years[years.Count - 1];
        if (have < years.Count) {
            indexLabel.Text = "Индексы нарядов за " + span + (have > 0 ? " (есть за " + have + " из " + years.Count + " лет)" : "")
                + " создадутся при первом поиске - один раз, в папке программы; дальше дополняются сами.";
            indexLabel.ForeColor = Look.Warn;
            return;
        }
        indexLabel.Text = "Индексы нарядов за " + span + ": нарядов " + count + ", обновлены " + updated.ToString("dd.MM.yyyy HH:mm")
            + " (дополняются сами при каждом поиске; файлы indeks_naryady_ГГГГ.txt в папке программы)";
        indexLabel.ForeColor = Look.Good;
    }

    // в фоне: индексы этих лет - есть: дописать новые наряды; нет (или таблицу пересобрали): создать все недостающие за один проход
    Dictionary<int, NaryadIndex> EnsureAll(List<int> years, List<string> notes) {
        Dictionary<int, NaryadIndex> ready = new Dictionary<int, NaryadIndex>();
        List<int> missing = new List<int>();
        int added = 0;
        foreach (int y in years) {
            NaryadIndex x = IndexOf(y);
            if (x == null) { missing.Add(y); continue; }
            int a = x.Update(TablePath, header);
            if (a < 0) { lock (indexes) indexes.Remove(y); missing.Add(y); continue; }
            if (a > 0) { x.Save(NaryadIndex.FileFor(dir, y)); added += a; }
            ready[y] = x;
        }
        if (added > 0) notes.Add("в индексы добавлено новых нарядов: " + added);
        if (missing.Count == 0) return ready;
        missing.Sort();
        // «2021-2026» (подряд) или «2019, 2021, ...»
        string span = missing.Count == 1 ? missing[0].ToString() : missing[missing.Count - 1] - missing[0] == missing.Count - 1
            ? missing[0] + "-" + missing[missing.Count - 1] : JoinYears(missing);
        Dictionary<int, NaryadIndex> built = NaryadIndex.BuildYears(TablePath, header, setup, missing, delegate(int done, int total) {
            Post(delegate { status.Text = "Создаю индексы нарядов за " + span + " (один раз): просмотрено записей " + done + " из " + total + " (с конца таблицы)...   «Стоп» - прервать"; });
        }, delegate { return stop; });
        if (built == null) return ready;
        int count = 0;
        double seconds = 0;
        foreach (KeyValuePair<int, NaryadIndex> kv in built) {
            kv.Value.Save(NaryadIndex.FileFor(dir, kv.Key));
            lock (indexes) indexes[kv.Key] = kv.Value;
            ready[kv.Key] = kv.Value;
            count += kv.Value.Count;
            seconds = kv.Value.Seconds;
        }
        NaryadIndex any = built[missing[0]];
        notes.Add("созданы индексы за " + span + ": нарядов " + count);
        Report.Line("Наряды: индексы " + span + " созданы за " + seconds.ToString("0.0") + " с: нарядов " + count + ", просмотрены записи " + any.From + "-" + any.To);
        return ready;
    }

    // ---------- поиск ----------

    // только полный номер: «202620936» -> 2026 и 20936; «2026-20936», «2026 20936» тоже. Номера в каждом году свои (с 1),
    // поэтому номер без года не принимается - иначе нашёлся бы наряд другого года
    public static bool ParseNumber(string line, out int year, out long number) {
        year = 0;
        number = 0;
        string s = line.Trim().TrimStart('№', 'N', 'n').Trim();
        if (s.Length == 0) return false;
        int sep = -1;
        for (int i = 0; i < s.Length; i++) if (!char.IsDigit(s[i])) { sep = i; break; }
        int now = DateTime.Today.Year;
        if (sep == 4) {
            int y;
            string rest = s.Substring(5).Trim(' ', '-', '/', '.');
            if (int.TryParse(s.Substring(0, 4), out y) && y >= 2000 && y <= now + 1 && long.TryParse(rest, out number) && number > 0) { year = y; return true; }
        }
        StringBuilder d = new StringBuilder();
        foreach (char c in s) { if (char.IsDigit(c)) d.Append(c); else if (c != ' ' && c != '-' && c != '/') return false; }
        string digits = d.ToString();
        if (digits.Length < 6 || digits.Length > 12) return false;
        int yy = int.Parse(digits.Substring(0, 4));
        if (yy < 2000 || yy > now + 1) return false;
        year = yy;
        number = long.Parse(digits.Substring(4));
        return number > 0;
    }

    internal void Run() {
        if (building) {
            // кнопка «Стоп» во время создания индексов - остановить; иначе - найти, как только индексы будут готовы
            if (pendingRun) { stop = true; return; }
            pendingRun = true;
            findButton.Text = "Стоп";
            status.Text = "Создаются индексы нарядов (один раз) - найду сразу, как будут готовы...   «Стоп» - прервать";
            return;
        }
        if (busy) { stop = true; return; }
        if (header == null) { MessageBox.Show(this, "Таблица нарядов ещё не выбрана.", Text); return; }
        List<string> lines = new List<string>();
        foreach (string raw in input.Text.Replace("\r\n", "\n").Split('\n')) {
            string line = raw.Replace('\t', ' ').Trim();
            if (line.Length > 0) lines.Add(line);
        }
        if (lines.Count == 0) { MessageBox.Show(this, "Впишите номер наряда (или вставьте список - по одному в строке).", Text); return; }
        stop = false;
        SetBusy(true, "Ищу...");
        hits.Clear();
        grid.RowCount = 0;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            DateTime started = DateTime.Now;
            List<NaryadHit> found = new List<NaryadHit>();
            List<string> notes = new List<string>();
            Dictionary<int, NaryadIndex> ready = new Dictionary<int, NaryadIndex>();
            string err = null;
            try {
                // индексы последних лет (и лет из списка, если они старше): дописать новые наряды или создать
                List<int> years = Wanted();
                foreach (string l in lines) { int y; long n; if (ParseNumber(l, out y, out n) && !years.Contains(y)) years.Add(y); }
                ready = EnsureAll(years, notes);
                using (FileStream fs = new FileStream(TablePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.RandomAccess)) {
                    for (int i = 0; i < lines.Count && !stop; i++) found.AddRange(FindLine(fs, i + 1, lines[i], ready));
                }
            } catch (Exception ex) { err = ex.Message; }
            double seconds = (DateTime.Now - started).TotalSeconds;
            Post(delegate { Finish(found, notes, err, lines.Count, seconds); });
        });
        th.IsBackground = true;
        th.Start();
    }

    // одна строка списка -> наряды (обычно один)
    List<NaryadHit> FindLine(FileStream fs, int line, string text, Dictionary<int, NaryadIndex> ready) {
        List<NaryadHit> r = new List<NaryadHit>();
        int year;
        long number;
        NaryadHit h = new NaryadHit();
        h.Line = line;
        h.Query = text;
        if (!ParseNumber(text, out year, out number)) {
            h.State = 3;
            string dg = AccountTable.OnlyDigits(text);
            h.Result = dg.Length > 0 && dg.Length < 6 ? "впишите полностью: год и номер (" + DateTime.Today.Year + dg.PadLeft(5, '0') + ")" : "не номер наряда";
            r.Add(h);
            return r;
        }
        h.Year = year;
        h.Number = number;
        NaryadIndex x;
        if (!ready.TryGetValue(year, out x)) { h.State = 3; h.Result = "нет индекса " + year; r.Add(h); return r; }
        DbfField nf = header.Fields[header.FieldIndex(setup.Number)], df = header.Fields[header.FieldIndex(setup.YearField)];
        int doneField = header.FieldIndex(setup.Done);
        int acc = setup.Account.Length > 0 ? header.FieldIndex(setup.Account) : -1;
        // кандидаты: индекс этого года и соседних (индексы по дате оформления: наряд декабря, оформленный в январе, - в следующем)
        List<int> cand = new List<int>(x.Find(number));
        if (string.Compare(x.DateField, setup.YearField, StringComparison.OrdinalIgnoreCase) != 0)
            foreach (int y in new int[] { year - 1, year + 1 }) {
                NaryadIndex nb;
                if (ready.TryGetValue(y, out nb)) foreach (int rn in nb.Find(number)) if (!cand.Contains(rn)) cand.Add(rn);
            }
        foreach (int recNo in cand) {
            long at = header.HeaderLength + (long)(recNo - 1) * header.RecordLength;
            if (at + header.RecordLength > fs.Length) continue;
            byte[] rec = new byte[header.RecordLength];
            fs.Seek(at, SeekOrigin.Begin);
            if (DbfTable.ReadUpTo(fs, rec, rec.Length) < rec.Length || rec[0] == (byte)'*') continue;
            // запись могли поменять - сверить номер и год
            if (NaryadBytes.Number(rec, 0, nf) != number || NaryadBytes.Year(rec, 0, df) != year) continue;
            DbfTable one = DbfTable.CreateLike(header);
            one.AddRecord(rec, 0, recNo);
            NaryadHit k = new NaryadHit();
            k.Line = line;
            k.Query = text;
            k.Year = year;
            k.Number = number;
            k.RecNo = recNo;
            if (acc >= 0) k.Account = AccountTable.OnlyDigits(DbfTable.Format(one.GetValue(0, acc, null), true));
            string done = DbfTable.Format(one.GetValue(0, doneField, null), true).Trim();
            k.State = done.Length > 0 && done != "0" ? 0 : 1;
            k.Result = k.State == 0 ? "ВЫПОЛНЕН" : "НЕ ВЫПОЛНЕН";
            k.Values = new string[columns.Count];
            for (int c = 0; c < columns.Count; c++) {
                if (columns[c] == "*abon") {
                    int a = setup.Account.Length > 0 ? one.FieldIndex(setup.Account) : -1;
                    k.Values[c] = a >= 0 ? AbonentOf(DbfTable.Format(one.GetValue(0, a, null), true).Trim()) : "";
                    continue;
                }
                k.Values[c] = MapValue(columns[c], DbfTable.Format(one.GetValue(0, one.FieldIndex(columns[c]), null), false).Trim());
            }
            r.Add(k);
        }
        if (r.Count == 0) {
            h.State = 2;
            h.Result = "не найден в " + year + (x.Whole ? "" : number > x.MaxNumber && x.MaxNumber > 0 ? " (последний № " + x.MaxNumber + ")" : "");
            r.Add(h);
        } else if (r.Count > 1) foreach (NaryadHit k in r) k.Result += " (" + r.Count + " записи)";
        return r;
    }

    void Finish(List<NaryadHit> found, List<string> notes, string err, int lines, double seconds) {
        SetBusy(false, null);
        hits.Clear();
        hits.AddRange(found);
        grid.RowCount = hits.Count;
        grid.Invalidate();
        ShowIndex();
        int done = 0, open = 0, miss = 0;
        foreach (NaryadHit h in hits) { if (h.State == 0) done++; else if (h.State == 1) open++; else miss++; }
        string text = err != null ? "Ошибка: " + err : (stop ? "Остановлено. " : "") + "Строк " + lines + ": выполнено " + done + ", не выполнено " + open + ", не найдено " + miss + ".";
        if (notes.Count > 0) text += "  (" + string.Join("; ", notes.ToArray()) + ")";
        status.Text = text;
        Report.Search("Наряды: строк " + lines + ", выполнено " + done + ", не выполнено " + open + ", не найдено " + miss + ", время " + seconds.ToString("0.0") + " с");
    }

    void Export() {
        if (hits.Count == 0) { MessageBox.Show(this, "Сначала найдите наряды.", Text); return; }
        string[] headers = new string[grid.Columns.Count];
        for (int c = 0; c < headers.Length; c++) headers[c] = grid.Columns[c].HeaderText;
        List<string[]> rows = new List<string[]>();
        List<string> styles = new List<string>();
        foreach (NaryadHit h in hits) {
            string[] v = new string[headers.Length];
            for (int c = 0; c < v.Length; c++) v[c] = Cell(h, c);
            rows.Add(v);
            styles.Add(h.State == 0 ? "t" : h.State == 1 ? "n" : "y");
        }
        try { Spreadsheet.Open("Наряды", headers, rows, styles); }
        catch (Exception ex) { MessageBox.Show(this, "Не удалось выгрузить в Excel:\n" + ex.Message, Text); }
    }

    // для проверки: строки итога текстом
    public string Dump() {
        StringBuilder sb = new StringBuilder();
        foreach (NaryadHit h in hits) {
            for (int c = 0; c < grid.Columns.Count; c++) sb.Append(c > 0 ? " | " : "").Append(Cell(h, c));
            sb.Append(h.State == 0 ? "  [зелёная]" : h.State == 1 ? "  [красная]" : "  [серая]").Append('\n');
        }
        return sb.Append(status.Text).ToString();
    }
    public string IndexText { get { return indexLabel.Text + " | " + tableLabel.Text; } }

    // значение для показа: код работы -> название, табельный -> Ф.И.О. (как в программе базы), 0 - пусто
    string MapValue(string field, string value) {
        bool work = string.Compare(field, setup.Work, StringComparison.OrdinalIgnoreCase) == 0;
        bool staff = string.Compare(field, setup.Taker, StringComparison.OrdinalIgnoreCase) == 0 || string.Compare(field, setup.Done, StringComparison.OrdinalIgnoreCase) == 0;
        if (!work && !staff) return value;
        if (value == "0") return "";
        CodeNames c = work ? workNames : staffNames;
        string n = c != null && value.Length > 0 ? c.Name(value) : null;
        return n != null ? n : value.Length > 0 && staff ? "таб. № " + value : value;
    }

    // ГодНомер как в программе базы: 202620936, 202600015
    static string FullNumber(int year, long number) {
        return year <= 0 ? number.ToString() : number < 100000 ? (year * 100000L + number).ToString() : year.ToString() + number;
    }

    // ---------- наряды лицевого (как Ctrl+Z в программе базы) ----------

    Control BuildAccountPanel() {
        Panel p = new Panel();
        p.Dock = DockStyle.Fill;
        lsHead.Dock = DockStyle.Top;
        lsHead.Height = 26;
        lsHead.TextAlign = ContentAlignment.MiddleLeft;
        headFont = new Font(Font.FontFamily, 10.5f, FontStyle.Bold);
        lsHead.Font = headFont;
        lsHead.ForeColor = Look.Info;
        lsHead.Text = "Наряды лицевого - выберите строку итога";
        SplitContainer two = new SplitContainer();
        two.Dock = DockStyle.Fill;
        two.Orientation = Orientation.Vertical;
        foreach (ListView v in new ListView[] { lsList, details }) {
            v.Dock = DockStyle.Fill;
            v.View = View.Details;
            v.FullRowSelect = true;
            v.HideSelection = false;
            v.MultiSelect = false;
            v.GridLines = true;
            CopyText.List(v);
        }
        lsList.Columns.Add("№ Н-З", 95);
        lsList.Columns.Add("Дата оф.", 85);
        lsList.Columns.Add("Работа", 260);
        lsList.Columns.Add("Выполнен", 90);
        lsList.SelectedIndexChanged += delegate { if (lsList.SelectedIndices.Count > 0) ShowDetails(lsRows[lsList.SelectedIndices[0]]); };
        details.Columns.Add("", 170);
        details.Columns.Add("", 360);
        details.HeaderStyle = ColumnHeaderStyle.None;
        two.Panel1.Controls.Add(lsList);
        two.Panel2.Controls.Add(details);
        p.Controls.Add(two);
        p.Controls.Add(lsHead);
        p.Resize += delegate { if (p.Width > 300) two.SplitterDistance = Math.Max(200, p.Width * 45 / 100); };

        // снизу - обходы лицевого (как Ctrl+O)
        Panel ob = new Panel();
        ob.Dock = DockStyle.Fill;
        obHead.Dock = DockStyle.Top;
        obHead.Height = 26;
        obHead.TextAlign = ContentAlignment.MiddleLeft;
        obHead.Font = headFont;
        obHead.ForeColor = Look.Info;
        obList.Dock = DockStyle.Fill;
        obList.View = View.Details;
        obList.FullRowSelect = true;
        obList.HideSelection = false;
        obList.MultiSelect = false;
        obList.GridLines = true;
        CopyText.List(obList);
        ob.Controls.Add(obList);
        ob.Controls.Add(obHead);
        SplitContainer both = new SplitContainer();
        both.Dock = DockStyle.Fill;
        both.Orientation = Orientation.Horizontal;
        both.Panel1.Controls.Add(p);
        both.Panel2.Controls.Add(ob);
        both.SizeChanged += delegate { if (both.Height > 200) both.SplitterDistance = both.Height / 2; };
        return both;
    }

    // все наряды лицевого выбранной строки - из индексов годов (какие созданы); выбранный наряд - выделен
    void ShowAccount(NaryadHit h) {
        lsList.Items.Clear();
        details.Items.Clear();
        lsRows.Clear();
        shownHit = h;
        obList.Items.Clear();
        if (h == null || h.RecNo <= 0) { lsHead.Text = "Наряды лицевого - выберите найденный наряд"; return; }
        string ls = h.Account;
        List<int> years = new List<int>();
        List<int> recs = new List<int>();
        string from = "";
        if (ls.Length > 0 && nzByLs != null && nzByLs.Indexed) {
            // индекс программы базы по лицевому - все годы
            try {
                List<int> rows;
                DbfTable part = nzByLs.Find(ls, out rows);
                foreach (int row in rows) recs.Add(part.RecNos[row]);
                from = "все годы - по индексу программы базы";
            } catch (Exception) { recs.Clear(); }
        }
        if (!recs.Contains(h.RecNo)) recs.Add(h.RecNo);
        if (from.Length == 0 && ls.Length > 0)
            foreach (int y in KnownYears()) {
                NaryadIndex x = IndexOf(y);
                if (x == null) continue;
                List<int> r = x.ByAccount(ls);
                if (r.Count > 0 || y == h.Year) years.Add(y);
                foreach (int n in r) if (!recs.Contains(n)) recs.Add(n);
            }
        try {
            using (FileStream fs = new FileStream(TablePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.RandomAccess))
                foreach (int n in recs) {
                    NaryadRow row = NaryadRow.Read(fs, header, setup, n, MapValue);
                    if (row != null) lsRows.Add(row);
                }
        } catch (Exception ex) { lsHead.Text = "Наряды лицевого не прочитались: " + ex.Message; return; }
        lsRows.Sort(delegate(NaryadRow a, NaryadRow b) { int c = b.Date.CompareTo(a.Date); return c != 0 ? c : b.Number.CompareTo(a.Number); });
        years.Sort();
        lsHead.Text = (ls.Length > 0 ? "Наряды лицевого " + ls + AddressOf(ls) : "Наряд (лицевого в таблице нарядов нет)") + "   - нарядов " + lsRows.Count
            + (from.Length > 0 ? " (" + from + ")" : " (смотрим годы с индексом: " + JoinYears(KnownYears()) + ")");
        ShowObhod(ls);
        foreach (NaryadRow r in lsRows) {
            ListViewItem it = new ListViewItem(new string[] { FullNumber(r.Year, r.Number),
                r.Date == DateTime.MinValue ? "" : r.Date.ToString("dd.MM.yyyy"), r.Work, r.Done ? "выполнен" : "НЕТ" });
            it.BackColor = r.Done ? DoneColor : OpenColor;
            lsList.Items.Add(it);
            if (r.RecNo == h.RecNo) { it.Selected = true; it.EnsureVisible(); }
        }
    }

    static string JoinYears(List<int> years) {
        List<string> s = new List<string>();
        foreach (int y in years) s.Add(y.ToString());
        return string.Join(", ", s.ToArray());
    }

    // года, у которых есть индекс (файлы в папке программы и открытые)
    List<int> KnownYears() {
        List<int> r;
        lock (indexes) r = new List<int>(indexes.Keys);
        try {
            foreach (string f in Directory.GetFiles(dir, "indeks_naryady_*.txt")) {
                int y;
                if (int.TryParse(Path.GetFileNameWithoutExtension(f).Substring("indeks_naryady_".Length), out y) && !r.Contains(y)) r.Add(y);
            }
        } catch (Exception) { }
        r.Sort();
        return r;
    }

    // «Иванов И.И., Широкая ул. 6//23» - для столбца итога
    string AbonentOf(string ls) {
        string a = AddressOf(ls);
        if (a.Length == 0) return "";
        int p = a.IndexOf("  (");
        string adr = (p >= 0 ? a.Substring(0, p) : a).Replace("▶", "").Trim();
        string fio = p >= 0 ? a.Substring(p + 3).TrimEnd(')') : "";
        return (fio + (fio.Length > 0 && adr.Length > 0 ? ", " : "") + adr).Trim();
    }

    // адрес лицевого из базы абонентов (по индексу): « ▶ Широкая ул. 6//23 (Иванов И.И.)»
    string AddressOf(string ls) {
        if (live == null) return "";
        try {
            SearchResult r = live.Search(ls, SearchMode.Account, null, false);
            if (r == null || r.Rows.Count == 0) return "";
            int row = r.Rows[0];
            DbfTable t = r.Table;
            string ul = Part(r, row, t, "UL"), dom = Part(r, row, t, "DOM"), kor = Part(r, row, t, "KOR"), kv = Part(r, row, t, "KV"), fio = Part(r, row, t, "FIO");
            string adr = (ul + " " + dom + (kor.Length > 0 || kv.Length > 0 ? "/" + kor + (kv.Length > 0 ? "/" + kv : "") : "")).Trim();
            return (adr.Length > 0 ? "  ▶ " + adr : "") + (fio.Length > 0 ? "  (" + fio + ")" : "");
        } catch (Exception) { return ""; }
    }

    static string Part(SearchResult r, int row, DbfTable t, string field) {
        int j = t.FieldIndex(field);
        return j < 0 ? "" : ResultColumns.Text(r, row, j).Trim();
    }

    // все поля наряда - как справа в окне Ctrl+Z
    void ShowDetails(NaryadRow r) {
        details.Items.Clear();
        foreach (string[] d in NaryadData.DetailRows(setup, header, plan, r)) {
            ListViewItem it = new ListViewItem(new string[] { d[0], d[1] });
            if (d[2].Length > 0) it.BackColor = d[2] == "done" ? DoneColor : OpenColor;
            details.Items.Add(it);
        }
    }

    // для проверки: наряды лицевого текстом
    public string AccountText {
        get {
            StringBuilder sb = new StringBuilder(lsHead.Text);
            foreach (ListViewItem it in lsList.Items) {
                sb.Append('\n').Append(it.Selected ? " > " : "   ");
                for (int c = 0; c < it.SubItems.Count; c++) sb.Append(c > 0 ? " | " : "").Append(it.SubItems[c].Text);
            }
            foreach (ListViewItem it in details.Items) sb.Append("\n      ").Append(it.SubItems[0].Text).Append(": ").Append(it.SubItems[1].Text);
            return sb.ToString();
        }
    }
    public string ObhodText {
        get {
            StringBuilder sb = new StringBuilder(obHead.Text);
            foreach (ColumnHeader c in obList.Columns) sb.Append(c.Index == 0 ? "\n   " : " | ").Append(c.Text);
            foreach (ListViewItem it in obList.Items) {
                sb.Append("\n   ");
                for (int c = 0; c < it.SubItems.Count; c++) sb.Append(c > 0 ? " | " : "").Append(it.SubItems[c].Text);
            }
            return sb.ToString();
        }
    }
    public void SelectHit(int i) { if (i < grid.RowCount) grid.CurrentCell = grid.Rows[i].Cells[0]; }
}

// Наряды и обходы для окна «Наряды» и для карточки абонента (Ctrl+Z, Ctrl+O): таблица нарядов (как в naryady.txt),
// справочники работ и работников, график (назначено на дату), обходы. Загружается один раз (в фоне) и общее для всех окон.
public class NaryadData {
    public static string ProgramDir = "";       // папка программы: naryady.txt
    static NaryadData shared;
    static string sharedFolder = "";
    static readonly object sync = new object();

    public string Folder = "", Error = "";
    public NaryadSetup Setup = new NaryadSetup();
    public DbfTable Header;
    public AccountTable ByLs;
    public CodeNames Work, Staff;
    public Dictionary<long, string> Plan = new Dictionary<long, string>();
    public ObhodSource Obhod;

    public string TablePath { get { return Path.Combine(Folder, Setup.Table); } }
    public bool Ready { get { return Header != null && Error.Length == 0; } }

    public static void Share(string folder, NaryadData d) { lock (sync) { shared = d; sharedFolder = folder; } }
    public static void Reset() { lock (sync) shared = null; }

    // для карточки (в фоне): уже загруженное или загрузить
    public static NaryadData Get(string folder) {
        lock (sync) if (shared != null && string.Compare(sharedFolder, folder, StringComparison.OrdinalIgnoreCase) == 0) return shared;
        NaryadData d = Load(folder, null);
        if (d.Ready) Share(folder, d);
        return d;
    }

    // st == null - настройка из naryady.txt (нет или найдена прежней программой - найти таблицу, как окно «Наряды»)
    public static NaryadData Load(string folder, NaryadSetup st) {
        NaryadData d = new NaryadData();
        d.Folder = folder;
        string file = Path.Combine(ProgramDir, "naryady.txt");
        try {
            if (st == null) {
                st = NaryadSetup.Load(file);
                bool ok = st.Ready && (st.How == "вручную" || st.Version >= NaryadSetup.CurrentVersion) && File.Exists(Path.Combine(folder, st.Table));
                if (!ok) {
                    NaryadGuess g = null;
                    if (st.Ready && File.Exists(Path.Combine(folder, st.Table))) {
                        try { g = NaryadFinder.Judge(Path.Combine(folder, st.Table)); } catch (Exception) { g = null; }
                        if (g != null && g.Score < 100) g = null;
                        if (g != null) { g.Setup.WorkBook = st.WorkBook; g.Setup.StaffBook = st.StaffBook; }
                    }
                    if (g == null) {
                        List<NaryadGuess> list = NaryadFinder.Guess(folder, null);
                        if (list.Count > 0 && list[0].Usable) g = list[0];
                    }
                    if (g == null) { d.Error = "таблица нарядов не найдена - откройте окно «Наряды» и выберите её"; return d; }
                    g.Setup.Year = st.Year;
                    st = g.Setup;
                    st.Save(file);
                }
            }
            d.Setup = st;
            d.Header = DbfTable.LoadHeader(d.TablePath);
        } catch (Exception ex) { d.Error = ex.Message; return d; }
        // названия работ и Ф.И.О. по табельным: запомненный справочник, иначе найти по кодам последних нарядов
        try {
            d.Work = st.WorkBook.Length > 0 ? CodeNames.Load(folder, st.WorkBook) : null;
            d.Staff = st.StaffBook.Length > 0 ? CodeNames.Load(folder, st.StaffBook) : null;
            if (d.Work == null && st.Work.Length > 0 || d.Staff == null && (st.Taker.Length > 0 || st.Done.Length > 0)) {
                DbfTable tail = NaryadFinder.Tail(d.TablePath, d.Header, 1500);
                if (d.Work == null && st.Work.Length > 0 && tail.FieldIndex(st.Work) >= 0 && tail.Fields[tail.FieldIndex(st.Work)].Type == 'N')
                    d.Work = CodeNames.Find(folder, st.Work, NaryadForm.Codes(tail, st.Work), false, st.Table);
                if (d.Staff == null) {
                    List<string> c = new List<string>();
                    foreach (string f in new string[] { st.Taker, st.Done })
                        if (f.Length > 0 && tail.FieldIndex(f) >= 0 && tail.Fields[tail.FieldIndex(f)].Type == 'N') c.AddRange(NaryadForm.Codes(tail, f));
                    if (c.Count > 0) d.Staff = CodeNames.Find(folder, st.Done, c, true, st.Table);
                }
                if (d.Work != null) st.WorkBook = d.Work.Saved;
                if (d.Staff != null) st.StaffBook = d.Staff.Saved;
                if (d.Work != null || d.Staff != null) st.Save(file);
            }
        } catch (Exception) { }
        // «назначено на дату»: график нарядов GRAF_NZ (UNNAR -> DVIP_PLAN)
        try {
            string g = null;
            foreach (string f in Directory.GetFiles(folder)) if (string.Compare(Path.GetFileName(f), "GRAF_NZ.DBF", StringComparison.OrdinalIgnoreCase) == 0) g = f;
            if (g != null) {
                DbfTable gt = DbfTable.Load(g, null, null, 0);
                int u = gt.FieldIndex("UNNAR"), dv = gt.FieldIndex("DVIP_PLAN");
                if (u >= 0 && dv >= 0)
                    for (int r = 0; r < gt.Count; r++) {
                        long un;
                        if (long.TryParse(DbfTable.Format(gt.GetValue(r, u, null), true), out un)) d.Plan[un] = DbfTable.Format(gt.GetValue(r, dv, null), true);
                    }
            }
        } catch (Exception) { }
        try { d.ByLs = AccountTable.Open(d.TablePath); } catch (Exception) { d.ByLs = null; }
        try { d.Obhod = ObhodSource.Find(folder); } catch (Exception ex) { d.Obhod = new ObhodSource(); d.Obhod.Note = "не получилось: " + ex.Message; }
        Report.Line("Наряды: названия работ - " + (d.Work == null ? "справочник не найден" : d.Work.Note) + "; Ф.И.О. по табельным - " + (d.Staff == null ? "справочник не найден" : d.Staff.Note)
            + "; назначено на дату (GRAF_NZ): " + d.Plan.Count);
        Report.Line("Наряды лицевого: " + (d.ByLs == null ? "-" : d.ByLs.Name + " - " + d.ByLs.Note));
        ObhodSource ob = d.Obhod;
        Report.Line("Обходы (Ctrl+O): " + ob.Note + (ob.CodeField.Length > 0 ? "; код - поле " + ob.CodeField + (ob.NameField.Length > 0 ? ", название - поле " + ob.NameField
            : ob.Names != null ? ", названия: " + ob.Names.Note : ", справочник названий не найден") : "") + (ob.Reading.Length > 0 ? "; ср. сутки - считаются по " + ob.Reading + " и " + ob.DateField : ""));
        return d;
    }

    // значение для показа: код работы -> название, табельный -> Ф.И.О., 0 - пусто
    public string Map(string field, string value) {
        bool work = string.Compare(field, Setup.Work, StringComparison.OrdinalIgnoreCase) == 0;
        bool staff = string.Compare(field, Setup.Taker, StringComparison.OrdinalIgnoreCase) == 0 || string.Compare(field, Setup.Done, StringComparison.OrdinalIgnoreCase) == 0;
        if (!work && !staff) return value;
        if (value == "0") return "";
        CodeNames c = work ? Work : Staff;
        string n = c != null && value.Length > 0 ? c.Name(value) : null;
        return n != null ? n : value.Length > 0 && staff ? "таб. № " + value : value;
    }

    // все наряды лицевого - по индексу NAB программы базы (все годы), новые сверху
    public List<NaryadRow> AccountRows(string ls) {
        List<NaryadRow> rows = new List<NaryadRow>();
        if (ByLs == null || !ByLs.Indexed || ls.Length == 0) return rows;
        List<int> found;
        DbfTable part = ByLs.Find(ls, out found);
        using (FileStream fs = new FileStream(TablePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.RandomAccess))
            foreach (int row in found) {
                NaryadRow r = NaryadRow.Read(fs, Header, Setup, part.RecNos[row], Map);
                if (r != null) rows.Add(r);
            }
        rows.Sort(delegate(NaryadRow a, NaryadRow b) { int c = b.Date.CompareTo(a.Date); return c != 0 ? c : b.Number.CompareTo(a.Number); });
        return rows;
    }

    // ГодНомер как в программе базы: 202620936, 202600015
    public static string FullNumber(int year, long number) {
        return year <= 0 ? number.ToString() : number < 100000 ? (year * 100000L + number).ToString() : year.ToString() + number;
    }

    // поля наряда для правой части окна Ctrl+Z: {подпись, значение, "done"/"open"/""}
    public static List<string[]> DetailRows(NaryadSetup setup, DbfTable header, Dictionary<long, string> plan, NaryadRow r) {
        List<string[]> list = new List<string[]>();
        List<int> order = new List<int>();
        foreach (string f in new string[] { setup.Number, setup.Date, setup.Work, setup.Taker, setup.Done, setup.DoneDate, setup.Meter, "TIPCH", "TEL", "PRIM" }) {
            int j = f.Length > 0 ? header.FieldIndex(f) : -1;
            if (j >= 0 && !order.Contains(j)) order.Add(j);
        }
        for (int j = 0; j < header.Fields.Count; j++) if (!order.Contains(j)) order.Add(j);
        int un = header.FieldIndex("UNNAR"), tip = header.FieldIndex("TIPCH");
        foreach (int j in order) {
            string name = header.Fields[j].Name;
            bool done = string.Compare(name, setup.Done, StringComparison.OrdinalIgnoreCase) == 0;
            list.Add(new string[] { Label(setup, name), r.Values[j], done ? (r.Done ? "done" : "open") : "" });
            // «Назначено на дату» - из графика нарядов (GRAF_NZ), после типа счётчика
            if (j == (tip >= 0 ? tip : order[order.Count - 1]) && un >= 0) {
                long u;
                string d;
                if (long.TryParse(r.Values[un], out u) && plan.TryGetValue(u, out d)) list.Add(new string[] { "Назначено на дату", d, "" });
            }
        }
        return list;
    }

    public static string Label(NaryadSetup setup, string field) {
        string[][] roles = { new string[] { setup.Number, "№ Н-З" }, new string[] { setup.Date, "Дата оф." }, new string[] { setup.Work, "Работа" },
            new string[] { setup.Taker, "Принял Н-З" }, new string[] { setup.Done, "Выполнил Н-З" }, new string[] { setup.DoneDate, "Дата выпол." },
            new string[] { setup.Meter, "Номер сч." }, new string[] { setup.Account, "Лицевой" } };
        foreach (string[] r in roles) if (r[0].Length > 0 && string.Compare(r[0], field, StringComparison.OrdinalIgnoreCase) == 0) return r[1];
        string up = field.ToUpperInvariant();
        if (up.Contains("TIP") && up.Contains("SCH") || up == "TIPCH") return "Тип сч.";
        if (up == "UNNAR") return "Полный № наряда";
        if (up.Contains("NAZ")) return "Назначено на дату";
        if (up.StartsWith("TEL")) return "Тел.";
        if (up.StartsWith("PRIM")) return "Примечание";
        string label = FieldNames.Label(field);
        return label ?? field;
    }
}

// Окна карточки абонента в цветах программы базы: наряды лицевого (Ctrl+Z) и обходы (Ctrl+O)
public class BlueListForm : Form {
    protected static readonly Color Back = Color.FromArgb(0, 0, 160), Title = Color.FromArgb(255, 255, 85), Cyan = Color.FromArgb(85, 255, 255);
    protected static readonly Color DoneBack = Color.FromArgb(0, 120, 50), OpenBack = Color.FromArgb(170, 30, 30);
    protected readonly Label head = new Label();
    protected readonly Font mono;
    protected readonly string folder, ls;

    protected BlueListForm(string folder, string ls, string title, string headText) {
        this.folder = folder;
        this.ls = ls;
        Text = title;
        BackColor = Back;
        StartPosition = FormStartPosition.CenterParent;
        KeyPreview = true;
        mono = Pick(10f);
        Rectangle wa = Screen.PrimaryScreen.WorkingArea;
        Size = new Size(Math.Min(1100, wa.Width), Math.Min(560, wa.Height));
        head.Dock = DockStyle.Top;
        head.Height = 30;
        head.Font = new Font(mono.FontFamily, 11f, FontStyle.Bold);
        head.ForeColor = Cyan;
        head.BackColor = Back;
        head.TextAlign = ContentAlignment.MiddleLeft;
        head.Text = headText;
        KeyDown += delegate(object s, KeyEventArgs e) { if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; Close(); } };
    }

    // шрифты - после самих списков (иначе список, теряя фокус при закрытии, рисуется освобождённым шрифтом)
    protected override void Dispose(bool disposing) {
        Font h = head.Font;
        base.Dispose(disposing);
        if (disposing) { mono.Dispose(); h.Dispose(); }
    }

    static Font Pick(float size) {
        foreach (string name in new string[] { "Consolas", "Lucida Console", "Courier New" }) {
            Font f = new Font(name, size);
            if (string.Compare(f.Name, name, StringComparison.OrdinalIgnoreCase) == 0) return f;
            f.Dispose();
        }
        return new Font(FontFamily.GenericMonospace, size);
    }

    protected ListView List() {
        ListView v = new ListView();
        v.Dock = DockStyle.Fill;
        v.View = View.Details;
        v.FullRowSelect = true;
        v.HideSelection = false;
        v.MultiSelect = false;
        v.GridLines = true;
        v.BackColor = Back;
        v.ForeColor = Color.White;
        v.Font = mono;
        CopyText.List(v);
        return v;
    }

    protected void Post(MethodInvoker m) { try { if (!IsDisposed && IsHandleCreated) BeginInvoke(m); } catch (Exception) { } }

    // данные - в фоне (первый раз - открыть таблицы), потом show
    protected delegate void DataHandler(NaryadData d);
    protected void LoadData(DataHandler show) {
        // данные могут быть уже готовы - ответ придёт сразу; окно к этому времени должно быть создано
        if (!IsHandleCreated) { Shown += delegate { LoadData(show); }; return; }
        string f = folder;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            NaryadData d;
            try { d = NaryadData.Get(f); } catch (Exception ex) { d = new NaryadData(); d.Error = ex.Message; }
            Post(delegate { show(d); });
        });
        th.IsBackground = true;
        th.Start();
    }
}

// Ctrl+Z в карточке: наряды лицевого - слева № Н-З, дата оф., работа (выполненные - зелёным, нет - красным), справа поля выбранного
public class NaryadLsForm : BlueListForm {
    readonly ListView list, details;
    readonly List<NaryadRow> rows = new List<NaryadRow>();
    NaryadData data;

    public NaryadLsForm(string folder, string ls, string who) : base(folder, ls, "Наряды " + ls + " (только просмотр)", "Н-З " + ls + "  ▶ " + who) {
        list = List();
        details = List();
        list.Columns.Add("№ Н-З", 110);
        list.Columns.Add("Дата оф.", 100);
        list.Columns.Add("Работа", 270);
        list.Columns.Add("", 90);
        details.Columns.Add("", 200);
        details.Columns.Add("", 330);
        details.HeaderStyle = ColumnHeaderStyle.None;
        list.SelectedIndexChanged += delegate { if (list.SelectedIndices.Count > 0) ShowDetails(rows[list.SelectedIndices[0]]); };
        SplitContainer two = new SplitContainer();
        two.Dock = DockStyle.Fill;
        two.BackColor = Back;
        two.Panel1.Controls.Add(list);
        two.Panel2.Controls.Add(details);
        Controls.Add(two);
        Controls.Add(head);
        Shown += delegate { two.SplitterDistance = Math.Max(200, two.Width * 52 / 100); ActiveControl = list; };
        list.Items.Add(new ListViewItem(new string[] { "", "", "читаю наряды...", "" }));
        LoadData(Fill);
    }

    void Fill(NaryadData d) {
        data = d;
        list.Items.Clear();
        details.Items.Clear();
        rows.Clear();
        if (!d.Ready) { list.Items.Add(new ListViewItem(new string[] { "", "", "Наряды: " + d.Error, "" })); return; }
        if (d.ByLs == null || !d.ByLs.Indexed) { list.Items.Add(new ListViewItem(new string[] { "", "", "у таблицы нарядов " + d.Setup.Table + " нет годного индекса по лицевому", "" })); return; }
        try { rows.AddRange(d.AccountRows(ls)); }
        catch (Exception ex) { list.Items.Add(new ListViewItem(new string[] { "", "", "не прочитались: " + ex.Message, "" })); return; }
        if (rows.Count == 0) { list.Items.Add(new ListViewItem(new string[] { "", "", "нарядов у лицевого нет", "" })); return; }
        foreach (NaryadRow r in rows) {
            ListViewItem it = new ListViewItem(new string[] { NaryadData.FullNumber(r.Year, r.Number), r.Date == DateTime.MinValue ? "" : r.Date.ToString("dd.MM.yyyy"),
                r.Work, r.Done ? "выполнен" : "НЕТ" });
            it.BackColor = r.Done ? DoneBack : OpenBack;
            list.Items.Add(it);
        }
        list.Items[0].Selected = true;
        Text = "Наряды " + ls + ": " + rows.Count + " (только просмотр)";
    }

    void ShowDetails(NaryadRow r) {
        details.Items.Clear();
        if (data == null) return;
        foreach (string[] d in NaryadData.DetailRows(data.Setup, data.Header, data.Plan, r)) {
            ListViewItem it = new ListViewItem(new string[] { d[0], d[1] });
            it.ForeColor = d[2] == "done" ? Color.FromArgb(120, 255, 120) : d[2] == "open" ? Color.FromArgb(255, 140, 140) : Color.White;
            it.UseItemStyleForSubItems = true;
            details.Items.Add(it);
        }
    }

    // для проверки
    public string Dump() {
        StringBuilder sb = new StringBuilder(head.Text);
        foreach (ListViewItem it in list.Items) {
            sb.Append('\n').Append(it.Selected ? " > " : "   ");
            for (int c = 0; c < it.SubItems.Count; c++) sb.Append(c > 0 ? " | " : "").Append(it.SubItems[c].Text);
        }
        foreach (ListViewItem it in details.Items) sb.Append("\n      ").Append(it.SubItems[0].Text).Append(": ").Append(it.SubItems[1].Text);
        return sb.ToString();
    }
}

// Ctrl+O в карточке: обходы лицевого - дата проверки, показание, ср. сутки, № участка, код и название; новые сверху
public class ObhodForm : BlueListForm {
    readonly ListView list;

    public ObhodForm(string folder, string ls, string who) : base(folder, ls, "Обходы " + ls + " (только просмотр)", "АБОНЕНТ  " + ls + "  " + who) {
        list = List();
        Controls.Add(list);
        Controls.Add(head);
        Shown += delegate { ActiveControl = list; };
        list.Columns.Add("", 400);
        list.Items.Add(new ListViewItem("читаю обходы..."));
        LoadData(Fill);
    }

    void Fill(NaryadData d) {
        list.Items.Clear();
        list.Columns.Clear();
        ObhodSource o = d.Obhod;
        if (o == null || o.Tables.Count == 0) {
            list.Columns.Add("", 700);
            list.Items.Add(new ListViewItem("Обходы: " + (o == null ? d.Error : o.Note)));
            return;
        }
        for (int c = 0; c < o.Titles.Count; c++) {
            string t = o.Titles[c];
            ColumnHeader h = list.Columns.Add(t, t == "Наименование" ? 260 : t == "№ Абонента" ? 110 : t == "Таблица" ? 100 : t.Contains("Дата") ? 105 : 85);
            if (t == "Показ." || t == "Ср. сут." || t == "Код" || t == "№ Уч.") h.TextAlign = HorizontalAlignment.Right;
        }
        string err;
        List<ObhodRow> rows = o.Rows(ls, out err);
        foreach (ObhodRow r in rows) {
            string[] v = new string[r.Values.Length];
            for (int i = 0; i < v.Length; i++) v[i] = r.Values[i] ?? "";
            list.Items.Add(new ListViewItem(v));
        }
        if (rows.Count == 0) list.Items.Add(new ListViewItem(err != null ? "ошибка: " + err : "обходов у лицевого нет"));
        else list.Items[0].Selected = true;
        Text = "Обходы " + ls + ": " + rows.Count + (err != null ? " (ошибка: " + err + ")" : "") + " (только просмотр)";
    }

    public string Dump() {
        StringBuilder sb = new StringBuilder(head.Text);
        foreach (ListViewItem it in list.Items) {
            sb.Append("\n   ");
            for (int c = 0; c < it.SubItems.Count; c++) sb.Append(c > 0 ? " | " : "").Append(it.SubItems[c].Text);
        }
        return sb.ToString();
    }
}

// Оплаты лицевого (F6 в карточке, как в программе базы): все таблицы оплат папки базы - с лицевым (NAB), датой оплаты (DOPL...),
// суммой (SUMM...) и индексом NAB программы базы: новые (NOPL), текущие (OPLAKT, OPLATA, OPLRKC), архивы (AROPL, AROPRKC), по
// суду (OPFORSUD) - какие есть. Находятся один раз (в фоне) - общие для всех карточек. Только чтение
public class PaymentRow {
    public DateTime Date = DateTime.MinValue;
    public string[] Values;
    public decimal Sum, Pen;
    public int Order, RecNo;
}

public class PaymentSource {
    static PaymentSource shared;
    static string sharedFolder = "";
    static readonly object sync = new object();
    public readonly List<AccountTable> Tables = new List<AccountTable>();
    public string Note = "";

    // столбцы окна: подпись и поля таблиц (первое, что есть в таблице); дата и сумма - любые подходящие
    public static readonly string[] Titles = { "Дата опл.", "За месяц", "Сумма", "Пеня", "Показ. пред.", "Показ. тек.", "кВт·ч", "Тариф", "Касса / кассир", "№ пачки", "Таблица" };
    static readonly string[][] Fields = { null, new string[] { "MES" }, null, new string[] { "PEN" }, new string[] { "PPOK" }, new string[] { "PRPOK" },
        new string[] { "KVTALL", "RP" }, new string[] { "TAR" }, new string[] { "NKASIR", "NKA", "NRKC", "KASSIR" }, new string[] { "NPL" }, null };

    public static PaymentSource Get(string folder) {
        lock (sync) if (shared != null && string.Compare(sharedFolder, folder, StringComparison.OrdinalIgnoreCase) == 0) return shared;
        PaymentSource p = Find(folder);
        lock (sync) { shared = p; sharedFolder = folder; }
        Report.Line("Оплаты (F6): " + p.Note);
        return p;
    }

    // дата оплаты: DOPL, DATOPL...; иначе дата, в имени которой «OPL»
    public static int DateField(DbfTable h) {
        foreach (string n in new string[] { "DOPL", "DATOPL", "DATAOPL", "DPL" }) { int j = h.FieldIndex(n); if (j >= 0 && h.Fields[j].Type == 'D') return j; }
        for (int j = 0; j < h.Fields.Count; j++) if (h.Fields[j].Type == 'D' && h.Fields[j].Name.ToUpperInvariant().Contains("OPL")) return j;
        return -1;
    }

    // сумма: SUMM, SUMOPL, SUMMA; иначе число, имя которого начинается с SUM
    public static int SumField(DbfTable h) {
        foreach (string n in new string[] { "SUMM", "SUMOPL", "SUMMA", "SUM" }) { int j = h.FieldIndex(n); if (j >= 0 && (h.Fields[j].Type == 'N' || h.Fields[j].Type == 'F')) return j; }
        for (int j = 0; j < h.Fields.Count; j++) if ((h.Fields[j].Type == 'N' || h.Fields[j].Type == 'F') && h.Fields[j].Name.ToUpperInvariant().StartsWith("SUM")) return j;
        return -1;
    }

    // порядок: новые и текущие (имя без AR), потом архивы (AR...)
    static int Rank(string name) {
        string n = Path.GetFileNameWithoutExtension(name).ToUpperInvariant();
        if (n.StartsWith("NOPL")) return 0;
        if (!n.StartsWith("AR")) return 1;
        return 2;
    }

    public static PaymentSource Find(string folder) {
        PaymentSource p = new PaymentSource();
        List<string> files = new List<string>();
        foreach (string f in Directory.GetFiles(folder)) if (string.Compare(Path.GetExtension(f), ".dbf", StringComparison.OrdinalIgnoreCase) == 0) files.Add(f);
        files.Sort(delegate(string a, string b) { int c = Rank(a).CompareTo(Rank(b)); return c != 0 ? c : string.Compare(Path.GetFileName(a), Path.GetFileName(b), StringComparison.OrdinalIgnoreCase); });
        List<string> notes = new List<string>();
        foreach (string f in files) {
            DbfTable h;
            try { h = DbfTable.LoadHeader(f); } catch (Exception) { continue; }
            if (h.FieldIndex("NAB") < 0 || DateField(h) < 0 || SumField(h) < 0) continue;
            AccountTable t = AccountTable.Open(f);
            notes.Add(t.Name + " (" + h.Expected + "): " + t.Note);
            if (t.Indexed) p.Tables.Add(t);
        }
        p.Note = notes.Count > 0 ? string.Join("; ", notes.ToArray()) : "таблиц оплат (с лицевым NAB, датой оплаты и суммой) в папке нет";
        return p;
    }

    // все оплаты лицевого из всех таблиц, новые сверху; одна и та же оплата в двух таблицах (новые и текущие) - один раз
    public List<PaymentRow> Rows(string ls, out string error) {
        error = null;
        List<PaymentRow> r = new List<PaymentRow>();
        Dictionary<string, bool> seen = new Dictionary<string, bool>();
        foreach (AccountTable t in Tables) {
            List<int> rows;
            DbfTable part;
            try { part = t.Find(ls, out rows); } catch (Exception ex) { error = t.Name + ": " + ex.Message; continue; }
            int date = DateField(part), sum = SumField(part);
            int[] cols = new int[Titles.Length];
            for (int c = 0; c < Titles.Length; c++) {
                cols[c] = -1;
                if (c == 0) cols[c] = date;
                else if (c == 2) cols[c] = sum;
                else if (Fields[c] != null) foreach (string n in Fields[c]) if (cols[c] < 0) cols[c] = part.FieldIndex(n);
            }
            int pen = part.FieldIndex("PEN");
            foreach (int row in rows) {
                PaymentRow o = new PaymentRow();
                o.Order = Tables.IndexOf(t);
                o.RecNo = part.RecNos[row];
                object d = date >= 0 ? part.GetValue(row, date, null) : null;
                if (d is DateTime) o.Date = (DateTime)d;
                object sv = sum >= 0 ? part.GetValue(row, sum, null) : null;
                if (sv is decimal) o.Sum = (decimal)sv;
                object pv = pen >= 0 ? part.GetValue(row, pen, null) : null;
                if (pv is decimal) o.Pen = (decimal)pv;
                o.Values = new string[Titles.Length];
                for (int c = 0; c < Titles.Length; c++) {
                    if (cols[c] < 0) { o.Values[c] = ""; continue; }
                    object v = part.GetValue(row, cols[c], null);
                    o.Values[c] = v is decimal && (c == 2 || c == 3) ? ((decimal)v).ToString("0.00", CultureInfo.InvariantCulture) : DbfTable.Format(v, false).Trim();
                }
                o.Values[Titles.Length - 1] = t.Name;
                string key = o.Date.Ticks + "|" + o.Sum + "|" + o.Values[1] + "|" + o.Values[9];
                if (seen.ContainsKey(key)) continue;
                seen[key] = true;
                r.Add(o);
            }
        }
        r.Sort(delegate(PaymentRow a, PaymentRow b) {
            int c = b.Date.CompareTo(a.Date);
            if (c != 0) return c;
            if (a.Order != b.Order) return a.Order.CompareTo(b.Order);
            return b.RecNo.CompareTo(a.RecNo);
        });
        return r;
    }
}

// F6 в карточке: оплаты лицевого за год - сначала текущий; стрелка вверх - год назад, вниз - год вперёд; внизу - итог за год
public class OplataForm : BlueListForm {
    readonly ListView list;
    readonly Label total = new Label();
    readonly List<PaymentRow> all = new List<PaymentRow>();
    readonly string who;
    int year = DateTime.Today.Year;
    bool loaded;
    string note = "";

    public OplataForm(string folder, string ls, string who) : base(folder, ls, "Оплаты " + ls + " (только просмотр)", "ОПЛАТЫ  " + ls + "  " + who) {
        this.who = who;
        list = List();
        total.Dock = DockStyle.Bottom;
        total.Height = 28;
        total.Font = head.Font;
        total.ForeColor = Title;
        total.BackColor = Back;
        total.TextAlign = ContentAlignment.MiddleLeft;
        Controls.Add(list);
        Controls.Add(head);
        Controls.Add(total);
        for (int c = 0; c < PaymentSource.Titles.Length; c++) {
            string t = PaymentSource.Titles[c];
            ColumnHeader h = list.Columns.Add(t, t == "Таблица" ? 100 : t == "Касса / кассир" ? 120 : t == "Дата опл." ? 105 : t.StartsWith("Показ.") ? 108 : 92);
            if (c >= 2 && c <= 7) h.TextAlign = HorizontalAlignment.Right;
        }
        list.Items.Add(new ListViewItem("читаю оплаты..."));
        Shown += delegate { ActiveControl = list; };
        string f = folder, l = ls;
        System.Threading.Thread th = new System.Threading.Thread(delegate() {
            List<PaymentRow> rows = null;
            string err = null, src = "";
            try {
                PaymentSource p = PaymentSource.Get(f);
                if (p.Tables.Count == 0) err = p.Note;
                else {
                    rows = p.Rows(l, out err);
                    List<string> names = new List<string>();
                    foreach (AccountTable t in p.Tables) names.Add(t.Name);
                    src = string.Join(", ", names.ToArray());
                }
            } catch (Exception ex) { err = ex.Message; }
            Post(delegate { Loaded(rows, err, src); });
        });
        th.IsBackground = true;
        th.Start();
    }

    void Loaded(List<PaymentRow> rows, string err, string src) {
        loaded = true;
        if (rows != null) all.AddRange(rows);
        note = (err != null ? "ошибка: " + err + "; " : "") + (src.Length > 0 ? "таблицы: " + src : "");
        // нет оплат за текущий год - сразу последний год с оплатами
        if (all.Count > 0 && all[0].Date != DateTime.MinValue && all[0].Date.Year < year && !HasYear(year)) year = all[0].Date.Year;
        ShowYear();
    }

    bool HasYear(int y) { foreach (PaymentRow r in all) if (r.Date.Year == y) return true; return false; }

    // стрелки: вверх - год назад, вниз - год вперёд (не дальше первой оплаты и текущего года)
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
        if (keyData == Keys.Up || keyData == Keys.Down) {
            if (loaded) Step(keyData == Keys.Up ? -1 : 1);
            return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    public void Step(int d) {
        int first = year, last = Math.Max(DateTime.Today.Year, year);
        foreach (PaymentRow r in all) if (r.Date != DateTime.MinValue) { first = Math.Min(first, r.Date.Year); last = Math.Max(last, r.Date.Year); }
        int y = year + d;
        if (y < first || y > last) { System.Media.SystemSounds.Beep.Play(); return; }
        year = y;
        ShowYear();
    }

    void ShowYear() {
        list.BeginUpdate();
        try {
            list.Items.Clear();
            decimal sum = 0, pen = 0;
            int n = 0;
            foreach (PaymentRow r in all) {
                if (r.Date.Year != year) continue;
                list.Items.Add(new ListViewItem(r.Values));
                sum += r.Sum;
                pen += r.Pen;
                n++;
            }
            if (n == 0) {
                List<string> years = new List<string>();
                foreach (PaymentRow r in all) { string y = r.Date == DateTime.MinValue ? "без даты" : r.Date.Year.ToString(); if (!years.Contains(y)) years.Add(y); }
                list.Items.Add(new ListViewItem("за " + year + " год оплат нет" + (years.Count > 0 ? " (годы с оплатами: " + string.Join(", ", years.ToArray()) + ")" : " - у лицевого оплат нет")));
            } else list.Items[0].Selected = true;
            head.Text = "ОПЛАТЫ  " + ls + "  " + who + "   ·   " + year + " год";
            total.Text = " " + year + ": оплат " + n + ", сумма " + sum.ToString("0.00", CultureInfo.InvariantCulture) +
                (pen != 0 ? ", пеня " + pen.ToString("0.00", CultureInfo.InvariantCulture) : "") + "      ↑ - год назад, ↓ - год вперёд, Esc - закрыть";
            Text = "Оплаты " + ls + " за " + year + ": " + n + (note.Length > 0 ? " (" + note + ")" : "") + " - только просмотр";
        } finally { list.EndUpdate(); }
    }

    public bool Ready { get { return loaded; } }
    public string Dump() {
        StringBuilder sb = new StringBuilder(head.Text + "\n" + total.Text + "\n" + Text);
        foreach (ListViewItem it in list.Items) {
            sb.Append("\n   ");
            for (int c = 0; c < it.SubItems.Count; c++) sb.Append(c > 0 ? " | " : "").Append(it.SubItems[c].Text);
        }
        return sb.ToString();
    }
}

// Выбор таблицы нарядов и её полей (если программа сама не нашла или нашла не ту). Рядом с полем - пример из последней записи.
public class NaryadSetupDialog : Form {
    readonly List<NaryadGuess> list;
    readonly ComboBox table = new ComboBox();
    readonly ComboBox[] boxes = new ComboBox[8];
    static readonly string[] Labels = { "Номер наряда", "Дата оформления", "Выполнил Н-З (пусто - не выполнен)", "Дата выполнения", "Работа", "Принял Н-З", "Лицевой счёт", "Номер счётчика" };
    public NaryadSetup Result;

    public NaryadSetupDialog(List<NaryadGuess> list, NaryadSetup current) {
        Font = Look.Base;
        Look.Wear(this);
        this.list = list;
        Text = "Таблица нарядов";
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = MinimizeBox = false;
        ClientSize = new Size(720, 440);
        Label tl = new Label();
        tl.Text = "Таблица (подходящие - вверху; в скобках - записей):";
        tl.AutoSize = true;
        tl.Location = new Point(12, 12);
        table.DropDownStyle = ComboBoxStyle.DropDownList;
        table.Location = new Point(12, 32);
        table.Width = 696;
        foreach (NaryadGuess g in list) table.Items.Add(g.Setup.Table + "  (" + g.Records + ")" + (g.Usable ? "" : "  - " + g.Why));
        Controls.Add(tl);
        Controls.Add(table);
        int y = 70;
        for (int i = 0; i < boxes.Length; i++) {
            Label l = new Label();
            l.Text = Labels[i] + ":";
            l.AutoSize = false;
            l.Location = new Point(12, y + 4);
            l.Size = new Size(250, 20);
            ComboBox b = new ComboBox();
            b.DropDownStyle = ComboBoxStyle.DropDownList;
            b.Location = new Point(266, y);
            b.Width = 442;
            boxes[i] = b;
            Controls.Add(l);
            Controls.Add(b);
            y += 34;
        }
        Label hint = new Label();
        hint.Text = "Рядом с полем - что в нём у последнего наряда. Обязательны первые три.";
        hint.AutoSize = true;
        hint.ForeColor = SystemColors.GrayText;
        hint.Location = new Point(12, y + 4);
        Controls.Add(hint);
        Button ok = new Button();
        ok.Text = "OK";
        ok.Location = new Point(520, ClientSize.Height - 40);
        ok.Size = new Size(90, 28);
        ok.Click += delegate { Accept(); };
        Button cancel = new Button();
        cancel.Text = "Отмена";
        cancel.DialogResult = DialogResult.Cancel;
        cancel.Location = new Point(618, ClientSize.Height - 40);
        cancel.Size = new Size(90, 28);
        Controls.Add(ok);
        Controls.Add(cancel);
        AcceptButton = ok;
        CancelButton = cancel;
        table.SelectedIndexChanged += delegate { FillFields(null); };
        int start = 0;
        for (int i = 0; i < list.Count; i++)
            if (string.Compare(list[i].Setup.Table, current.Table, StringComparison.OrdinalIgnoreCase) == 0) start = i;
        table.SelectedIndex = list.Count > 0 ? start : -1;
        if (list.Count > 0 && string.Compare(list[start].Setup.Table, current.Table, StringComparison.OrdinalIgnoreCase) == 0 && current.Ready) FillFields(current);
    }

    // поля выбранной таблицы с примером значения из последней записи
    void FillFields(NaryadSetup pick) {
        if (table.SelectedIndex < 0) return;
        NaryadGuess g = list[table.SelectedIndex];
        NaryadSetup s = pick ?? g.Setup;
        string[] want = { s.Number, s.Date, s.Done, s.DoneDate, s.Work, s.Taker, s.Account, s.Meter };
        DbfTable t = g.Sample;
        for (int i = 0; i < boxes.Length; i++) {
            ComboBox b = boxes[i];
            b.Items.Clear();
            b.Items.Add("(нет)");
            int sel = 0;
            for (int j = 0; j < t.Fields.Count; j++) {
                string ex = "";
                for (int r = t.Count - 1; r >= 0 && ex.Length == 0; r--) ex = DbfTable.Format(t.GetValue(r, j, null), false).Trim();
                if (ex.Length > 40) ex = ex.Substring(0, 40) + "...";
                b.Items.Add(t.Fields[j].Name + (ex.Length > 0 ? "  - «" + ex + "»" : "  - пусто"));
                if (string.Compare(t.Fields[j].Name, want[i], StringComparison.OrdinalIgnoreCase) == 0) sel = j + 1;
            }
            b.SelectedIndex = sel;
        }
    }

    string Field(int i) {
        ComboBox b = boxes[i];
        if (b.SelectedIndex <= 0) return "";
        return list[table.SelectedIndex].Sample.Fields[b.SelectedIndex - 1].Name;
    }

    void Accept() {
        if (table.SelectedIndex < 0 || Field(0).Length == 0 || Field(1).Length == 0 || Field(2).Length == 0) {
            MessageBox.Show(this, "Выберите таблицу и поля: номер наряда, дата оформления, выполнил.", Text);
            return;
        }
        NaryadSetup s = new NaryadSetup();
        s.Table = list[table.SelectedIndex].Setup.Table;
        s.Number = Field(0); s.Date = Field(1); s.Done = Field(2); s.DoneDate = Field(3); s.Work = Field(4); s.Taker = Field(5); s.Account = Field(6); s.Meter = Field(7);
        s.Name = list[table.SelectedIndex].Setup.Name;
        Result = s;
        DialogResult = DialogResult.OK;
        Close();
    }
}

// Копирование из таблиц и списков: поля (ячейки) выделяются мышью (протянуть, Shift/Ctrl+щелчок),
// копируются Ctrl+C или правой кнопкой «Копировать»; в базу ничего не пишется
// История поисков: 30 последних (новые сверху) - что искали и что нашлось (строки как в списке найденного), чтобы найти
// адрес, если программу случайно закрыли. Файл istoriya.txt в папке программы (на этом компьютере; в нём данные абонентов).
// Уточнение того же поиска (дописали адрес, исправили букву) за 2 минуты - заменяет прежнюю запись, а не добавляет новую.
public static class SearchHistory {
    public const int Keep = 30;
    public const int RowsPerSearch = 15;

    public class Entry {
        public DateTime When;
        public int Mode;
        public string Query = "", Found = "";
        public string[] Titles = new string[0];
        public List<string[]> Rows = new List<string[]>();
    }

    static string Esc(string s) { return (s ?? "").Replace("\\", "\\\\").Replace("\t", "\\t").Replace("\r", " ").Replace("\n", "\\n"); }
    static string Unesc(string s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.Length; i++) {
            if (s[i] == '\\' && i + 1 < s.Length) { char c = s[++i]; sb.Append(c == 't' ? '\t' : c == 'n' ? '\n' : c); }
            else sb.Append(s[i]);
        }
        return sb.ToString();
    }

    static string[] Split(string line) {
        string[] p = line.Split('\t');
        for (int i = 0; i < p.Length; i++) p[i] = Unesc(p[i]);
        return p;
    }

    static string Join(string[] p) {
        string[] e = new string[p.Length];
        for (int i = 0; i < p.Length; i++) e[i] = Esc(p[i]);
        return string.Join("\t", e);
    }

    public static List<Entry> Load(string file) {
        List<Entry> list = new List<Entry>();
        try {
            if (!File.Exists(file)) return list;
            Entry cur = null;
            foreach (string line in File.ReadAllLines(file, Encoding.UTF8)) {
                if (line.StartsWith("П\t")) {
                    string[] p = Split(line.Substring(2));
                    cur = new Entry();
                    DateTime w;
                    if (p.Length > 0 && DateTime.TryParseExact(p[0], "dd.MM.yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out w)) cur.When = w;
                    int m;
                    if (p.Length > 1 && int.TryParse(p[1], out m)) cur.Mode = m;
                    if (p.Length > 2) cur.Query = p[2];
                    if (p.Length > 3) cur.Found = p[3];
                    list.Add(cur);
                } else if (cur != null && line.StartsWith("З\t")) cur.Titles = Split(line.Substring(2));
                else if (cur != null && line.StartsWith("С\t")) cur.Rows.Add(Split(line.Substring(2)));
            }
        } catch { }
        return list;
    }

    public static void Save(string file, List<Entry> list) {
        StringBuilder sb = new StringBuilder();
        sb.Append("# История поисков «Поиска абонента»: 30 последних (новые сверху). Можно удалить - начнётся заново.\r\n");
        foreach (Entry e in list) {
            sb.Append("П\t").Append(Join(new string[] { e.When.ToString("dd.MM.yyyy HH:mm:ss"), e.Mode.ToString(), e.Query, e.Found })).Append("\r\n");
            sb.Append("З\t").Append(Join(e.Titles)).Append("\r\n");
            foreach (string[] r in e.Rows) sb.Append("С\t").Append(Join(r)).Append("\r\n");
        }
        string tmp = file + ".tmp";
        File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(true));
        if (File.Exists(file)) File.Delete(file);
        File.Move(tmp, file);
    }

    static string Norm(string s) { return string.Join(" ", DbfTable.SplitWords((s ?? "").ToLowerInvariant())); }

    // добавить поиск: уточнение прежнего (тот же вид, одно начинается с другого, не позже 2 минут) - заменяет его
    public static void Add(string file, Entry e) {
        List<Entry> list = Load(file);
        if (list.Count > 0) {
            Entry last = list[0];
            string a = Norm(last.Query), b = Norm(e.Query);
            if (last.Mode == e.Mode && (e.When - last.When).TotalSeconds < 120 && (b.StartsWith(a) || a.StartsWith(b) || a == b)) list.RemoveAt(0);
        }
        list.Insert(0, e);
        while (list.Count > Keep) list.RemoveAt(list.Count - 1);
        Save(file, list);
    }
}

// Окно «История поисков»: новые сверху; у каждого поиска - когда, по чему, что вписано, сколько нашлось, и найденные строки
// (как в списке). Двойной щелчок (или Enter) - искать снова. Ctrl+C / правая кнопка - копировать.
public class HistoryForm : Form {
    readonly DataGridView grid = new DataGridView();
    readonly List<int> entryOf = new List<int>();
    readonly List<SearchHistory.Entry> list;
    public delegate void Repeat(int mode, string query);
    public Repeat OnRepeat;
    static readonly string[] ModeNames = { "лицевой", "адрес", "счётчик", "ФИО" };

    public HistoryForm(string file, string[] titles) {
        list = SearchHistory.Load(file);
        Text = "История поисков - " + list.Count + " последних (новые сверху)";
        Font = Look.Base;
        Look.Wear(this);
        StartPosition = FormStartPosition.CenterParent;
        Rectangle wa = Screen.PrimaryScreen.WorkingArea;
        Size = new Size(Math.Min(1300, wa.Width - 40), Math.Min(700, wa.Height - 40));
        KeyPreview = true;
        Label hint = new Label();
        hint.Dock = DockStyle.Top;
        hint.Height = 26;
        hint.Padding = new Padding(8, 6, 8, 0);
        hint.Text = "Двойной щелчок по строке (или Enter) - искать снова. Ctrl+C, правая кнопка - копировать. Esc - закрыть.";
        grid.Dock = DockStyle.Fill;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.RowHeadersVisible = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.CellSelect;
        // столбцы: когда, по чему, что вписано, найдено + столбцы списка найденного
        List<string> cols = new List<string>(new string[] { "Когда", "Искал по", "Что вписано", "Найдено" });
        cols.AddRange(titles);
        foreach (string c in cols) {
            DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
            col.HeaderText = c;
            col.SortMode = DataGridViewColumnSortMode.NotSortable;
            col.FillWeight = c == "Ф.И.О." || c == "Что вписано" || c.StartsWith("Населённый") ? 180 : c == "Когда" ? 90 : 70;
            grid.Columns.Add(col);
        }
        Look.Grid(grid);
        for (int i = 0; i < list.Count; i++) {
            SearchHistory.Entry e = list[i];
            bool odd = i % 2 == 1;
            int rows = Math.Max(1, e.Rows.Count);
            for (int k = 0; k < rows; k++) {
                object[] v = new object[cols.Count];
                for (int c = 0; c < v.Length; c++) v[c] = "";
                if (k == 0) {
                    v[0] = e.When.ToString("dd.MM HH:mm");
                    v[1] = e.Mode >= 0 && e.Mode < ModeNames.Length ? ModeNames[e.Mode] : "";
                    v[2] = e.Query;
                    v[3] = e.Found;
                }
                if (k < e.Rows.Count)
                    for (int c = 0; c < titles.Length; c++) {
                        int j = Array.IndexOf(e.Titles, titles[c]);
                        if (j >= 0 && j < e.Rows[k].Length) v[4 + c] = e.Rows[k][j];
                    }
                int r = grid.Rows.Add(v);
                if (odd) grid.Rows[r].DefaultCellStyle.BackColor = Look.RowOther;
                if (k == 0) grid.Rows[r].Cells[2].Style.Font = new Font(Look.Base, FontStyle.Bold);
                entryOf.Add(i);
            }
        }
        if (list.Count == 0) { grid.Rows.Add(new object[] { "", "", "Поисков пока не было", "" }); entryOf.Add(-1); }
        CopyText.Grid(grid);
        grid.CellDoubleClick += delegate(object s, DataGridViewCellEventArgs e) { if (e.RowIndex >= 0) Again(e.RowIndex); };
        KeyDown += delegate(object s, KeyEventArgs e) {
            if (e.KeyCode == Keys.Escape) { e.SuppressKeyPress = true; Close(); }
            else if (e.KeyCode == Keys.Enter && grid.CurrentCell != null) { e.SuppressKeyPress = true; Again(grid.CurrentCell.RowIndex); }
        };
        Controls.Add(grid);
        Controls.Add(hint);
    }

    public int Count { get { return list.Count; } }

    void Again(int row) {
        if (row < 0 || row >= entryOf.Count || entryOf[row] < 0) return;
        SearchHistory.Entry e = list[entryOf[row]];
        if (OnRepeat != null) OnRepeat(e.Mode, e.Query);
        Close();
    }
}

public static class CopyText {
    // таблица: выделяются ячейки, а не строка целиком; текущая строка - в рамке
    public static void Grid(DataGridView g) {
        g.SelectionMode = DataGridViewSelectionMode.CellSelect;
        g.MultiSelect = true;
        g.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        g.KeyDown += delegate(object s, KeyEventArgs e) {
            if (e.Control && (e.KeyCode == Keys.C || e.KeyCode == Keys.Insert)) { e.Handled = true; e.SuppressKeyPress = true; Put(Selected(g)); }
        };
        g.CellMouseDown += delegate(object s, DataGridViewCellMouseEventArgs e) {
            if (e.Button != MouseButtons.Right || e.RowIndex < 0 || e.ColumnIndex < 0) return;
            DataGridViewCell c = g[e.ColumnIndex, e.RowIndex];
            if (!c.Selected) { g.ClearSelection(); g.CurrentCell = c; c.Selected = true; }
        };
        ContextMenuStrip m = new ContextMenuStrip();
        ToolStripMenuItem cells = new ToolStripMenuItem("Копировать выделенное (Ctrl+C)");
        cells.Click += delegate { Put(Selected(g)); };
        ToolStripMenuItem row = new ToolStripMenuItem("Копировать строку целиком");
        row.Click += delegate { if (g.CurrentCell != null) Put(RowText(g, g.CurrentCell.RowIndex)); };
        m.Items.Add(cells);
        m.Items.Add(row);
        g.ContextMenuStrip = m;
        g.CurrentCellChanged += delegate { g.Invalidate(); };
        g.RowPostPaint += delegate(object s, DataGridViewRowPostPaintEventArgs e) {
            if (g.CurrentCell == null || e.RowIndex != g.CurrentCell.RowIndex) return;
            Rectangle r = e.RowBounds;
            r.Width = Math.Min(r.Width, g.Columns.GetColumnsWidth(DataGridViewElementStates.Visible) - g.HorizontalScrollingOffset) - 1;
            r.Height -= 1;
            using (Pen p = new Pen(Look.Accent, 2)) e.Graphics.DrawRectangle(p, r);
        };
    }

    // список: Ctrl+C - выбранная строка; правая кнопка - значение под мышкой или строка
    public static void List(ListView v) {
        v.KeyDown += delegate(object s, KeyEventArgs e) {
            if (e.Control && (e.KeyCode == Keys.C || e.KeyCode == Keys.Insert)) { e.Handled = true; e.SuppressKeyPress = true; Put(Items(v)); }
        };
        ContextMenuStrip m = new ContextMenuStrip();
        ToolStripMenuItem cell = new ToolStripMenuItem("Копировать значение");
        ToolStripMenuItem row = new ToolStripMenuItem("Копировать строку (Ctrl+C)");
        string[] under = new string[1];
        v.MouseDown += delegate(object s, MouseEventArgs e) {
            if (e.Button != MouseButtons.Right) return;
            ListViewHitTestInfo h = v.HitTest(e.Location);
            under[0] = h.SubItem != null ? h.SubItem.Text.Trim() : "";
            if (h.Item != null && !h.Item.Selected) {
                foreach (ListViewItem it in v.SelectedItems) it.Selected = false;
                h.Item.Selected = true;
                h.Item.Focused = true;
            }
            cell.Enabled = under[0].Length > 0;
            cell.Text = under[0].Length > 0 ? "Копировать «" + (under[0].Length > 40 ? under[0].Substring(0, 40) + "…" : under[0]) + "»" : "Копировать значение";
        };
        cell.Click += delegate { Put(under[0]); };
        row.Click += delegate { Put(Items(v)); };
        m.Items.Add(cell);
        m.Items.Add(row);
        v.ContextMenuStrip = m;
    }

    // выделенные ячейки: в строке - через табуляцию (по порядку столбцов), строки - с новой строки; одна ячейка - только значение
    public static string Selected(DataGridView g) {
        SortedDictionary<int, SortedDictionary<int, string>> rows = new SortedDictionary<int, SortedDictionary<int, string>>();
        foreach (DataGridViewCell c in g.SelectedCells) {
            if (!c.Visible || c.RowIndex < 0) continue;
            SortedDictionary<int, string> r;
            if (!rows.TryGetValue(c.RowIndex, out r)) { r = new SortedDictionary<int, string>(); rows[c.RowIndex] = r; }
            r[g.Columns[c.ColumnIndex].DisplayIndex] = Value(c);
        }
        if (rows.Count == 0 && g.CurrentCell != null) return Value(g.CurrentCell);
        StringBuilder sb = new StringBuilder();
        foreach (KeyValuePair<int, SortedDictionary<int, string>> r in rows) {
            if (sb.Length > 0) sb.Append("\r\n");
            sb.Append(string.Join("\t", new List<string>(r.Value.Values).ToArray()));
        }
        return sb.ToString();
    }

    public static string RowText(DataGridView g, int row) {
        SortedDictionary<int, string> r = new SortedDictionary<int, string>();
        foreach (DataGridViewColumn col in g.Columns) if (col.Visible) r[col.DisplayIndex] = Value(g[col.Index, row]);
        return string.Join("\t", new List<string>(r.Values).ToArray());
    }

    static string Value(DataGridViewCell c) {
        object v = c.FormattedValue;
        return v == null ? "" : v.ToString().Replace("\r", " ").Replace("\n", " ").Trim();
    }

    static string Items(ListView v) {
        StringBuilder sb = new StringBuilder();
        foreach (ListViewItem it in v.SelectedItems) {
            if (sb.Length > 0) sb.Append("\r\n");
            List<string> parts = new List<string>();
            foreach (ListViewItem.ListViewSubItem si in it.SubItems) parts.Add(si.Text.Trim());
            sb.Append(string.Join("\t", parts.ToArray()).Trim());
        }
        return sb.ToString();
    }

    public static void Put(string text) {
        if (text == null || text.Length == 0) return;
        try { Clipboard.SetText(text); } catch (Exception) { }
    }
}

// Общее оформление программ - как у «Оформления договора»: тёмная тема по умолчанию (глаза меньше устают), светлая - по выбору
// (переключатель в окне, меняется при следующем запуске). Цвета ставятся один раз при запуске (Look.Apply), до создания окон;
// Look.Dress(окно) перекрашивает окно и всё, что в нём (и что добавится потом): системное светлое - в цвета темы, кнопки -
// плоские с рамкой. Цвета, заданные программой нарочно (например, синие окна как в программе базы), не трогаются
public static class Look {
    public static bool Dark = true;
    public static System.Drawing.Color Back, Surface, Input, Header, Border, InputBorder, Text, Caption, Hint, Accent, AccentHover, Hover, Pressed,
        Link, Good, Bad, Warn, Info, Strong, RowGood, RowWarn, RowBad, RowOther, SelGood, SelBad, SelOther, RowPick;
    public static readonly System.Drawing.Font Base = new System.Drawing.Font("Segoe UI", 9f), Small = new System.Drawing.Font("Segoe UI", 8.5f),
        Bold = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Bold), Title = new System.Drawing.Font("Segoe UI", 15f, System.Drawing.FontStyle.Bold);

    static System.Drawing.Color C(int r, int g, int b) { return System.Drawing.Color.FromArgb(r, g, b); }

    static Look() { Apply(true); }

    public static void Apply(bool dark) {
        Dark = dark;
        if (dark) {
            Back = C(30, 33, 38); Surface = C(40, 44, 51); Input = C(48, 53, 61); Header = C(44, 48, 55);
            Border = C(66, 72, 82); InputBorder = C(98, 106, 118);
            Text = C(222, 226, 232); Caption = C(172, 180, 192); Hint = C(138, 146, 158);
            Accent = C(44, 98, 165); AccentHover = C(54, 114, 188); Hover = C(56, 63, 74); Pressed = C(66, 76, 92);
            Link = C(118, 172, 236); Good = C(112, 200, 142); Bad = C(240, 120, 120); Warn = C(232, 164, 72); Info = C(130, 182, 240);
            Strong = C(205, 211, 220);
            RowGood = C(38, 72, 50); RowWarn = C(84, 64, 34); RowBad = C(88, 42, 46); RowOther = C(52, 56, 62);
            SelGood = C(46, 120, 70); SelBad = C(150, 50, 56); SelOther = C(84, 90, 100); RowPick = C(38, 60, 92);
        } else {
            Back = C(242, 244, 247); Surface = System.Drawing.Color.White; Input = System.Drawing.Color.White; Header = C(232, 236, 241);
            Border = C(221, 226, 233); InputBorder = C(196, 204, 214);
            Text = C(31, 36, 43); Caption = C(58, 66, 78); Hint = C(128, 137, 150);
            Accent = C(35, 99, 178); AccentHover = C(28, 84, 153); Hover = C(236, 242, 250); Pressed = C(222, 233, 247);
            Link = C(35, 99, 178); Good = C(46, 140, 87); Bad = C(200, 55, 55); Warn = C(190, 105, 0); Info = C(0, 70, 140);
            Strong = System.Drawing.Color.Black;
            RowGood = C(214, 241, 219); RowWarn = C(255, 228, 190); RowBad = C(255, 218, 218); RowOther = C(236, 236, 236);
            SelGood = C(40, 140, 60); SelBad = C(190, 40, 40); SelOther = C(110, 110, 110); RowPick = C(226, 240, 255);
        }
    }

    public static string SwitchText { get { return Dark ? "Тема: тёмная - сделать светлой" : "Тема: светлая - сделать тёмной"; } }
    public static string SwitchedText { get { return Dark ? "будет светлая - после перезапуска" : "будет тёмная - после перезапуска"; } }

    public delegate void SaveTheme(bool dark);

    // ссылка «Тема: ...» - щелчок запоминает другую тему (save), она будет при следующем запуске
    public static System.Windows.Forms.LinkLabel Switch(SaveTheme save) {
        System.Windows.Forms.LinkLabel l = new System.Windows.Forms.LinkLabel();
        l.Text = SwitchText;
        l.Font = Small;
        l.AutoSize = true;
        l.LinkColor = l.ActiveLinkColor = Link;
        l.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
        bool next = !Dark;
        l.LinkClicked += delegate {
            save(next);
            l.Text = next == Dark ? SwitchText : SwitchedText;
            next = !next;
        };
        return l;
    }

    static bool Same(System.Drawing.Color a, System.Drawing.Color b) { return a.ToArgb() == b.ToArgb(); }

    // светлое системное (его и красим)
    static bool Plain(System.Drawing.Color c) {
        return c.A == 255 && (Same(c, System.Drawing.Color.White) || Same(c, System.Drawing.SystemColors.Window) || Same(c, System.Drawing.SystemColors.Control)
            || Same(c, System.Drawing.SystemColors.ControlLight) || Same(c, System.Drawing.SystemColors.ButtonFace) || Same(c, System.Drawing.SystemColors.AppWorkspace));
    }

    static bool PlainText(System.Drawing.Color c) {
        return Same(c, System.Drawing.Color.Black) || Same(c, System.Drawing.SystemColors.ControlText) || Same(c, System.Drawing.SystemColors.WindowText);
    }

    // главная кнопка окна (синяя): AcceptButton окна или Tag «главная»
    public static void MainButton(System.Windows.Forms.Button b) { b.Tag = "главная"; Button(b); }

    public static void Button(System.Windows.Forms.Button b) {
        System.Windows.Forms.Form f = b.FindForm();
        bool main = "главная".Equals(b.Tag) || f != null && f.AcceptButton == b;
        bool custom = !main && !Plain(b.BackColor) && b.BackColor.A == 255;     // цвет задан программой - оставить
        b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        b.UseVisualStyleBackColor = false;
        b.Cursor = System.Windows.Forms.Cursors.Hand;
        if (main) {
            b.BackColor = Accent;
            b.ForeColor = System.Drawing.Color.White;
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = b.FlatAppearance.MouseDownBackColor = AccentHover;
        } else if (!custom) {
            b.BackColor = Surface;
            b.ForeColor = Text;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.BorderColor = InputBorder;
            b.FlatAppearance.MouseOverBackColor = Hover;
            b.FlatAppearance.MouseDownBackColor = Pressed;
        }
    }

    public static void Grid(System.Windows.Forms.DataGridView g) {
        g.BackgroundColor = Surface;
        g.GridColor = Border;
        g.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        g.DefaultCellStyle.BackColor = Input;
        g.DefaultCellStyle.ForeColor = Text;
        g.DefaultCellStyle.SelectionBackColor = Accent;
        g.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
        g.EnableHeadersVisualStyles = false;
        g.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
        g.ColumnHeadersDefaultCellStyle.BackColor = Header;
        g.ColumnHeadersDefaultCellStyle.ForeColor = Text;
        g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Header;
        g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Text;
        g.RowHeadersDefaultCellStyle.BackColor = Header;
        g.RowHeadersDefaultCellStyle.ForeColor = Text;
    }

    // окно и всё в нём (и что добавится потом)
    public static void Dress(System.Windows.Forms.Control c) {
        if (c == null || "свой цвет".Equals(c.Tag)) return;
        if (c is System.Windows.Forms.Form) {
            c.BackColor = Back;
            c.ForeColor = Text;
        } else if (c is System.Windows.Forms.TextBoxBase || c is System.Windows.Forms.ComboBox || c is System.Windows.Forms.ListBox
            || c is System.Windows.Forms.ListView || c is System.Windows.Forms.NumericUpDown || c is System.Windows.Forms.TreeView) {
            if (Plain(c.BackColor)) c.BackColor = c is System.Windows.Forms.TextBoxBase && ((System.Windows.Forms.TextBoxBase)c).ReadOnly ? Surface : Input;
            if (PlainText(c.ForeColor)) c.ForeColor = Text;
            System.Windows.Forms.TextBox t = c as System.Windows.Forms.TextBox;
            if (t != null && t.BorderStyle == System.Windows.Forms.BorderStyle.Fixed3D) t.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            System.Windows.Forms.ComboBox cb = c as System.Windows.Forms.ComboBox;
            if (cb != null && Dark) cb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            System.Windows.Forms.ListView lv = c as System.Windows.Forms.ListView;
            if (lv != null && Dark) lv.GridLines = false;           // линии сетки Windows рисует светлыми - на тёмном режут глаз
        } else if (c is System.Windows.Forms.DataGridView) {
            Grid((System.Windows.Forms.DataGridView)c);
        } else if (c is System.Windows.Forms.Button) {
            Button((System.Windows.Forms.Button)c);
        } else if (c is System.Windows.Forms.LinkLabel) {
            System.Windows.Forms.LinkLabel l = (System.Windows.Forms.LinkLabel)c;
            l.LinkColor = Link;
            l.ActiveLinkColor = AccentHover;
            l.VisitedLinkColor = Link;
            if (PlainText(l.ForeColor)) l.ForeColor = Text;
        } else if (c is System.Windows.Forms.DateTimePicker) {
            System.Windows.Forms.DateTimePicker d = (System.Windows.Forms.DateTimePicker)c;
            d.CalendarMonthBackground = Input;
            d.CalendarForeColor = Text;
            d.CalendarTitleBackColor = Accent;
            d.CalendarTitleForeColor = System.Drawing.Color.White;
            d.CalendarTrailingForeColor = Hint;
        } else if (c is System.Windows.Forms.MonthCalendar) {
            System.Windows.Forms.MonthCalendar m = (System.Windows.Forms.MonthCalendar)c;
            // календарь Windows в стиле системы свои цвета не берёт - в тёмной теме рисуем его без стиля системы
            if (Dark) { if (m.IsHandleCreated) Plain(m); else m.HandleCreated += delegate { Plain(m); }; }
            m.BackColor = Input;
            m.ForeColor = Text;
            m.TitleBackColor = Accent;
            m.TitleForeColor = System.Drawing.Color.White;
            m.TrailingForeColor = Hint;
        } else if (c is System.Windows.Forms.ProgressBar) {
        } else {
            // подписи, галочки, панели, разделители
            if (!(c is System.Windows.Forms.Label) && !(c is System.Windows.Forms.CheckBox) && !(c is System.Windows.Forms.RadioButton) && Plain(c.BackColor)) c.BackColor = Back;
            if (PlainText(c.ForeColor)) c.ForeColor = Text;
            else if (Same(c.ForeColor, System.Drawing.SystemColors.GrayText)) c.ForeColor = Hint;
        }
        foreach (System.Windows.Forms.Control x in c.Controls) Dress(x);
        if (!hooked.ContainsKey(c) && (c is System.Windows.Forms.ContainerControl || c is System.Windows.Forms.Panel || c is System.Windows.Forms.GroupBox
            || c is System.Windows.Forms.SplitterPanel || c is System.Windows.Forms.TabPage)) {
            hooked[c] = true;
            System.Windows.Forms.Control me = c;
            c.ControlAdded += delegate(object s, System.Windows.Forms.ControlEventArgs e) { Dress(e.Control); };
            c.Disposed += delegate { hooked.Remove(me); };
        }
    }

    [System.Runtime.InteropServices.DllImport("uxtheme.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
    static extern int SetWindowTheme(System.IntPtr hwnd, string app, string idList);

    static void Plain(System.Windows.Forms.Control c) {
        if (System.Environment.OSVersion.Platform != System.PlatformID.Win32NT) return;
        try { SetWindowTheme(c.Handle, "", ""); } catch { }
    }

    static readonly System.Collections.Generic.Dictionary<System.Windows.Forms.Control, bool> hooked = new System.Collections.Generic.Dictionary<System.Windows.Forms.Control, bool>();

    // окно - в теме при показе (и шрифт программы)
    public static void Wear(System.Windows.Forms.Form f) {
        f.Load += delegate { Dress(f); };
    }
}
'@
# Программа собирается из этого скрипта ОДИН раз после обновления и сохраняется готовой (файл poisk_*.dll
# в папке профиля пользователя). Следующие запуски берут готовую - без сборки, за секунды.
# Изменился скрипт - у файла другое имя, программа соберётся заново.
$t0 = Get-Date
$stamp = '' + $code.Length
try {
    $sha = New-Object System.Security.Cryptography.SHA1CryptoServiceProvider
    $stamp += '_' + ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($code)), 0, 6) -replace '-', '')
} catch {
    $stamp += '_' + ($code.GetHashCode() -band 0x7FFFFFFF)
}
$name = "poisk_$stamp.dll"
$cacheDirs = @()
if ($env:LOCALAPPDATA) { $cacheDirs += (Join-Path $env:LOCALAPPDATA 'poisk-abonenta') }
if ($env:PUBLIC) { $cacheDirs += (Join-Path $env:PUBLIC 'poisk-abonenta') }
$cacheDirs += (Join-Path $here 'kesh-programmy')

function Test-Ready { return ($null -ne ('AbonentSearch' -as [type])) }

$launch = $null
foreach ($d in $cacheDirs) {
    $dll = Join-Path $d $name
    if ((-not (Test-Ready)) -and (Test-Path $dll)) {
        try {
            [void][Reflection.Assembly]::LoadFrom($dll)
            if (Test-Ready) { $launch = 'готовая программа ' + $dll + ', ' + ((Get-Date) - $t0).TotalSeconds.ToString('0.0') + ' с' }
        } catch { }
    }
}

# Предупреждения компилятора (не ошибки) не должны мешать запуску: -IgnoreWarnings, если PowerShell его знает
$quiet = @{}
try { if ((Get-Command Add-Type).Parameters.ContainsKey('IgnoreWarnings')) { $quiet['IgnoreWarnings'] = $true } } catch { }

# Окошко на время сборки: иначе несколько минут ничего не видно
$splash = $null
$splashText = $null
function Show-Splash {
    try {
        $script:splash = New-Object System.Windows.Forms.Form
        $splash.Text = 'Поиск абонента'
        $splash.FormBorderStyle = 'FixedDialog'
        $splash.ControlBox = $false
        $splash.StartPosition = 'CenterScreen'
        $splash.ClientSize = New-Object System.Drawing.Size(460, 110)
        $splash.TopMost = $true
        $script:splashText = New-Object System.Windows.Forms.Label
        $splashText.Dock = 'Fill'
        $splashText.TextAlign = 'MiddleCenter'
        $splashText.Font = New-Object System.Drawing.Font('Microsoft Sans Serif', 10)
        $splash.Controls.Add($splashText)
        Update-Splash 0
        $splash.Show()
        [System.Windows.Forms.Application]::DoEvents()
    } catch { $script:splash = $null }
}
function Update-Splash($seconds) {
    if ($splashText -eq $null) { return }
    $splashText.Text = "Программа обновилась - Windows собирает её.`nЭто только один раз после обновления.`n`nПрошло: " + [int]$seconds + ' с'
}

# Сборка. Временные файлы компилятора - в своей папке: папку TEMP Windows компилятор на некоторых
# компьютерах открыть не может ("cannot open ...\Temp\RES....tmp for writing").
# Собираем в фоне, а окошко тем временем показывает, сколько прошло.
function Build-Program($dll, $tmp) {
    if (Test-Path $tmp) { Get-ChildItem -Path $tmp -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
    else { [void](New-Item -ItemType Directory -Path $tmp) }
    $oldTmp = $env:TMP
    $oldTemp = $env:TEMP
    $env:TMP = $tmp
    $env:TEMP = $tmp
    $ps = $null
    try {
        $ps = [PowerShell]::Create()
        [void]$ps.AddScript({
            param($code, $refs, $dll, $quiet)
            $ErrorActionPreference = 'Stop'
            if ($dll) { Add-Type @quiet -ReferencedAssemblies $refs -TypeDefinition $code -OutputAssembly $dll -OutputType Library }
            else { Add-Type @quiet -ReferencedAssemblies $refs -TypeDefinition $code }
        }).AddArgument($code).AddArgument($refs).AddArgument($dll).AddArgument($quiet)
        $h = $ps.BeginInvoke()
        while (-not $h.IsCompleted) {
            if ($splash -ne $null) {
                Update-Splash ((Get-Date) - $t0).TotalSeconds
                [System.Windows.Forms.Application]::DoEvents()
            }
            Start-Sleep -Milliseconds 200
        }
        try { [void]$ps.EndInvoke($h) } catch {
            $ex = $_.Exception
            if ($ex.InnerException -ne $null) { $ex = $ex.InnerException }
            throw $ex
        }
        if ($ps.Streams.Error.Count -gt 0) { throw $ps.Streams.Error[0].Exception }
    } finally {
        if ($ps -ne $null) { $ps.Dispose() }
        $env:TMP = $oldTmp
        $env:TEMP = $oldTemp
        Get-ChildItem -Path $tmp -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($dll -and -not (Test-Ready)) { [void][Reflection.Assembly]::LoadFrom($dll) }
}

$errors = @()
if (-not (Test-Ready)) {
    Show-Splash
    foreach ($d in $cacheDirs) {
        try {
            if (-not (Test-Path $d)) { [void](New-Item -ItemType Directory -Path $d) }
            # прежние версии программы больше не нужны
            Get-ChildItem -Path $d -Filter 'poisk_*.dll' -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -ne $name } | Remove-Item -ErrorAction SilentlyContinue
            $dll = Join-Path $d $name
            # файл есть, но не загрузился (прошлая сборка прервалась) - собираем заново
            if (Test-Path $dll) { Remove-Item $dll -Force -ErrorAction SilentlyContinue }
            Build-Program $dll (Join-Path $d 'tmp')
            if (Test-Ready) { $launch = 'собрана и сохранена (' + $dll + ') за ' + ((Get-Date) - $t0).TotalSeconds.ToString('0') + ' с'; break }
        } catch {
            $errors += "$d : $_"
            if ($dll -and (Test-Path $dll)) { Remove-Item $dll -Force -ErrorAction SilentlyContinue }
            # ошибка в самом коде - другая папка не поможет
            if ("$_" -match 'error CS\d+') { break }
        }
    }
    # сохранить не получилось нигде - собираем в памяти (временные файлы - рядом со скриптом)
    if ((-not (Test-Ready)) -and -not ("$errors" -match 'error CS\d+')) {
        try {
            Build-Program $null (Join-Path $here 'tmp')
            if (Test-Ready) { $launch = 'собрана в памяти (сохранить не удалось) за ' + ((Get-Date) - $t0).TotalSeconds.ToString('0') + ' с; ' + ($errors -join '; ') }
        } catch { $errors += "в памяти: $_" }
    }
    if ($splash -ne $null) { $splash.Close(); $splash.Dispose() }
}

if (-not (Test-Ready)) {
    [void][System.Windows.Forms.MessageBox]::Show("Не удалось подготовить программу к запуску:`n`n" + ($errors -join "`n`n") + "`n`nСфотографируйте это окно и пришлите.", 'Поиск абонента - ошибка')
    exit
}

try {
    [AbonentSearch]::Run($here, $launch)
} catch {
    [void][System.Windows.Forms.MessageBox]::Show("$_", 'Поиск абонента - ошибка')
}
